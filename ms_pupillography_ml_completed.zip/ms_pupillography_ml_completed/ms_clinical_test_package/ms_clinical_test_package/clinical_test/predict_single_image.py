"""
Single Image MS Prediction Script
Simple script to predict MS from a single OCT pupillography image
"""

import sys
import os
import joblib
import numpy as np
import cv2
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'ms_pupillography_ml'))

from src.feature_extraction.extract_features import extract_features
from src.preprocessing.preprocess import preprocess_image, quality_check


def predict_ms(image_path, model_path='../ms_pupillography_ml/models/ms_detection_model.pkl',
               scaler_path='../ms_pupillography_ml/models/feature_scaler.pkl'):
    """
    Predict MS from a single image
    
    Args:
        image_path: Path to OCT pupillography image
        model_path: Path to trained model
        scaler_path: Path to feature scaler
        
    Returns:
        dict: Prediction results
    """
    
    print(f"\n{'='*60}")
    print(f"MS PUPILLOGRAPHY PREDICTION")
    print(f"{'='*60}")
    print(f"Image: {os.path.basename(image_path)}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}\n")
    
    # Step 1: Quality check
    print("Step 1/4: Quality check...")
    is_valid, reason = quality_check(image_path)
    
    if not is_valid:
        print(f"❌ Quality check FAILED: {reason}")
        return {
            'success': False,
            'error': f"Quality check failed: {reason}",
            'image_path': image_path
        }
    
    print(f"✅ Quality check PASSED: {reason}")
    
    # Step 2: Extract features
    print("\nStep 2/4: Extracting features...")
    try:
        features = extract_features(image_path)
        print(f"✅ Extracted {len(features)} features")
    except Exception as e:
        print(f"❌ Feature extraction FAILED: {e}")
        return {
            'success': False,
            'error': f"Feature extraction failed: {e}",
            'image_path': image_path
        }
    
    # Step 3: Load model and scaler
    print("\nStep 3/4: Loading model...")
    try:
        model = joblib.load(model_path)
        scaler = joblib.load(scaler_path)
        print(f"✅ Model loaded successfully")
    except Exception as e:
        print(f"❌ Model loading FAILED: {e}")
        return {
            'success': False,
            'error': f"Model loading failed: {e}",
            'image_path': image_path
        }
    
    # Step 4: Make prediction
    print("\nStep 4/4: Making prediction...")
    try:
        # Scale features
        features_scaled = scaler.transform([features])
        
        # Predict
        prediction = model.predict(features_scaled)[0]
        probabilities = model.predict_proba(features_scaled)[0]
        
        # Get confidence
        confidence = max(probabilities) * 100
        
        # Determine result
        result = "MS" if prediction == 1 else "Control"
        
        print(f"\n{'='*60}")
        print(f"PREDICTION RESULT")
        print(f"{'='*60}")
        print(f"Diagnosis: {result}")
        print(f"Confidence: {confidence:.1f}%")
        print(f"Probability (Control): {probabilities[0]:.3f}")
        print(f"Probability (MS): {probabilities[1]:.3f}")
        print(f"{'='*60}\n")
        
        return {
            'success': True,
            'image_path': image_path,
            'prediction': result,
            'prediction_code': int(prediction),
            'confidence': confidence,
            'prob_control': probabilities[0],
            'prob_ms': probabilities[1],
            'features': features,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
    except Exception as e:
        print(f"❌ Prediction FAILED: {e}")
        return {
            'success': False,
            'error': f"Prediction failed: {e}",
            'image_path': image_path
        }


def main():
    """Main function"""
    
    if len(sys.argv) < 2:
        print("Usage: python predict_single_image.py <image_path>")
        print("\nExample:")
        print("  python predict_single_image.py /path/to/oct_image.jpg")
        sys.exit(1)
    
    image_path = sys.argv[1]
    
    # Check if file exists
    if not os.path.exists(image_path):
        print(f"❌ Error: File not found: {image_path}")
        sys.exit(1)
    
    # Make prediction
    result = predict_ms(image_path)
    
    # Exit with appropriate code
    if result['success']:
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
