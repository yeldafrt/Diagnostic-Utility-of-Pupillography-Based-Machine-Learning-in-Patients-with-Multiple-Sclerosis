# MS Pupillography Clinical Test Package - Detaylı Kullanım Kılavuzu

## İçindekiler

1. [Giriş](#giriş)
2. [Sistem Gereksinimleri](#sistem-gereksinimleri)
3. [Kurulum](#kurulum)
4. [Veri Hazırlama](#veri-hazırlama)
5. [Kullanım Senaryoları](#kullanım-senaryoları)
6. [Çıktı Dosyaları](#çıktı-dosyaları)
7. [Performans Metrikleri](#performans-metrikleri)
8. [Görselleştirmeler](#görselleştirmeler)
9. [Sorun Giderme](#sorun-giderme)
10. [SSS](#sss)

## Giriş

Bu paket, Multiple Sclerosis (MS) hastalığının pupillografi görüntülerinden makine öğrenmesi ile tespiti için geliştirilmiş klinik test sistemidir. Sistem, eğitilmiş bir Random Forest modeli kullanarak görüntüleri analiz eder ve MS/Control sınıflandırması yapar.

### Temel Özellikler

- ✅ Tek görüntü veya toplu işleme desteği
- ✅ Otomatik kalite kontrolü
- ✅ Detaylı Excel raporları
- ✅ Performans metrik hesaplama
- ✅ Yayın kalitesinde görselleştirmeler (300 DPI)
- ✅ Makale için hazır tablolar (LaTeX formatında)
- ✅ Güven skorları ile tahminler

## Sistem Gereksinimleri

### Yazılım Gereksinimleri

- Python 3.8 veya üzeri
- pip (Python paket yöneticisi)

### Donanım Gereksinimleri

- **RAM**: Minimum 4 GB (8 GB önerilir)
- **Disk Alanı**: En az 500 MB boş alan
- **İşlemci**: Modern çok çekirdekli işlemci önerilir

### Gerekli Python Kütüphaneleri

```
pandas
openpyxl
scikit-learn
matplotlib
seaborn
joblib
opencv-python-headless
numpy
```

## Kurulum

### Adım 1: Paketi İndirin

Paketi bilgisayarınıza indirin ve bir klasöre çıkartın.

### Adım 2: Sanal Ortam Oluşturun (Opsiyonel ama Önerilir)

```bash
# Sanal ortam oluştur
python -m venv venv

# Sanal ortamı aktif et (Linux/Mac)
source venv/bin/activate

# Sanal ortamı aktif et (Windows)
venv\Scripts\activate
```

### Adım 3: Bağımlılıkları Yükleyin

```bash
pip install -r requirements.txt
```

### Adım 4: Model Dosyalarını Kontrol Edin

Model dosyalarının şu dizinde olduğundan emin olun:
```
../ms_pupillography_ml/models/
├── ms_detection_model.pkl
└── feature_scaler.pkl
```

## Veri Hazırlama

### Görüntü Verisi

1. Tüm pupillografi görüntülerinizi `data/` klasörüne kopyalayın
2. Desteklenen formatlar: `.jpg`, `.jpeg`, `.png`, `.bmp`, `.tif`, `.tiff`
3. Dosya adlandırma: Her görüntü için benzersiz bir ID kullanın (örn: `hasta001.png`, `hasta002.png`)

**Örnek Dizin Yapısı:**
```
data/
├── hasta001.png
├── hasta002.png
├── hasta003.png
└── ...
```

### Gerçek Etiketler (Opsiyonel)

Performans metriklerini hesaplamak için gerçek tanı etiketlerini içeren bir CSV dosyası oluşturun.

**Dosya Adı**: `data/true_labels.csv`

**Format**:
```csv
patient_id,true_label
hasta001,MS
hasta002,Control
hasta003,MS
hasta004,Control
```

**Önemli Notlar**:
- `patient_id` sütunu görüntü dosya adı ile (uzantı olmadan) **tam olarak** eşleşmelidir
- `true_label` sütunu sadece `MS` veya `Control` değerlerini içermelidir
- Başlık satırı (`patient_id,true_label`) zorunludur

## Kullanım Senaryoları

### Senaryo 1: Tam Analiz (Önerilen)

Tüm işlemleri tek komutla gerçekleştirin:

```bash
python run_analysis.py data/ results/
```

**Bu komut şunları yapar:**
1. Tüm görüntüleri işler
2. MS/Control tahminleri yapar
3. Detaylı Excel raporu oluşturur
4. Performans metrikleri hesaplar (eğer `true_labels.csv` varsa)
5. Tüm görselleştirmeleri oluşturur

**Çıktılar:**
- `results/predictions_YYYYMMDD_HHMMSS.csv`
- `results/report_YYYYMMDD_HHMMSS.xlsx`
- `results/metrics_YYYYMMDD_HHMMSS.json` (eğer gerçek etiketler varsa)
- `results/figures/` (tüm grafikler)

### Senaryo 2: Tek Görüntü Testi

Tek bir görüntüyü hızlıca test edin:

```bash
python predict_single_image.py data/hasta001.png
```

**Çıktı (Terminal):**
```
============================================================
MS PUPILLOGRAPHY PREDICTION
============================================================
Image: hasta001.png
Time: 2025-10-08 11:27:48
============================================================

Step 1/4: Quality check...
✅ Quality check PASSED: OK

Step 2/4: Extracting features...
✅ Extracted 22 features

Step 3/4: Loading model...
✅ Model loaded successfully

Step 4/4: Making prediction...

============================================================
PREDICTION RESULT
============================================================
Diagnosis: Control
Confidence: 63.8%
Probability (Control): 0.638
Probability (MS): 0.362
============================================================
```

### Senaryo 3: Sadece Toplu Tahmin

Görselleştirme olmadan sadece tahminleri oluşturun:

```bash
# Gerçek etiketler olmadan
python predict_batch.py data/ results/

# Gerçek etiketlerle
python predict_batch.py data/ results/ data/true_labels.csv
```

### Senaryo 4: Sadece Görselleştirme

Daha önce oluşturulmuş tahminler için görselleştirmeler oluşturun:

```bash
python visualize_results.py results/predictions_20251008_120000.csv
```

## Çıktı Dosyaları

### 1. CSV Raporu (`predictions_YYYYMMDD_HHMMSS.csv`)

Ham tahmin verilerini içerir.

**Sütunlar:**
- `image_file`: Görüntü dosya adı
- `image_path`: Tam dosya yolu
- `quality_check`: Kalite kontrolü sonucu (PASS/FAIL)
- `quality_reason`: Kalite kontrolü açıklaması
- `prediction`: Tahmin (MS/Control)
- `prediction_code`: Tahmin kodu (0=Control, 1=MS)
- `confidence`: Güven skoru (%)
- `prob_control`: Control olma olasılığı
- `prob_ms`: MS olma olasılığı
- `true_label`: Gerçek etiket (eğer sağlanmışsa)
- `correct`: Tahmin doğru mu? (eğer gerçek etiket varsa)

### 2. Excel Raporu (`report_YYYYMMDD_HHMMSS.xlsx`)

Çoklu sayfa içeren detaylı rapor.

**Sayfalar:**
1. **Summary**: Genel özet istatistikler
2. **Detailed Predictions**: Tüm tahminlerin detaylı listesi
3. **Performance Metrics**: Performans metrikleri (eğer gerçek etiketler varsa)

### 3. Metrik Dosyası (`metrics_YYYYMMDD_HHMMSS.json`)

Performans metriklerini JSON formatında içerir (sadece gerçek etiketler sağlandığında).

**İçerik:**
```json
{
    "accuracy": "85.71%",
    "sensitivity": "93.75%",
    "specificity": "80.77%",
    "precision": "75.00%",
    "true_positives_(tp)": 15,
    "true_negatives_(tn)": 21,
    "false_positives_(fp)": 5,
    "false_negatives_(fn)": 1
}
```

### 4. Görselleştirmeler (`results/figures/`)

Tüm grafikler 300 DPI kalitesinde PNG formatında kaydedilir.

## Performans Metrikleri

Sistem aşağıdaki performans metriklerini hesaplar (gerçek etiketler sağlandığında):

### Temel Metrikler

1. **Accuracy (Doğruluk)**: Doğru tahminlerin toplam tahminlere oranı
   - Formül: (TP + TN) / (TP + TN + FP + FN)

2. **Sensitivity (Duyarlılık/Recall)**: MS hastalarının ne kadarının doğru tespit edildiği
   - Formül: TP / (TP + FN)

3. **Specificity (Özgüllük)**: Kontrol grubunun ne kadarının doğru tespit edildiği
   - Formül: TN / (TN + FP)

4. **Precision (Kesinlik)**: MS olarak tahmin edilenlerin ne kadarının gerçekten MS olduğu
   - Formül: TP / (TP + FP)

### Confusion Matrix Terimleri

- **True Positive (TP)**: MS hastası doğru şekilde MS olarak tespit edildi
- **True Negative (TN)**: Kontrol doğru şekilde Kontrol olarak tespit edildi
- **False Positive (FP)**: Kontrol yanlışlıkla MS olarak tespit edildi
- **False Negative (FN)**: MS hastası yanlışlıkla Kontrol olarak tespit edildi

## Görselleştirmeler

### 1. Confusion Matrix (Karmaşıklık Matrisi)

**Dosya**: `confusion_matrix_clinical.png`

Modelin sınıflandırma performansını görsel olarak gösterir. Satırlar gerçek etiketleri, sütunlar tahminleri temsil eder.

### 2. ROC Curve (ROC Eğrisi)

**Dosya**: `roc_curve_clinical.png`

Receiver Operating Characteristic eğrisi. AUC (Area Under Curve) değeri modelin genel performansını gösterir.

- **AUC = 1.0**: Mükemmel sınıflandırma
- **AUC = 0.5**: Rastgele tahmin
- **AUC < 0.5**: Rastgele tahminden kötü

### 3. Precision-Recall Curve (PR Eğrisi)

**Dosya**: `pr_curve_clinical.png`

Kesinlik ve duyarlılık arasındaki dengeyi gösterir. Dengesiz veri setleri için ROC eğrisinden daha bilgilendiricidir.

### 4. Confidence Distribution (Güven Dağılımı)

**Dosya**: `confidence_distribution.png`

MS ve Control tahminlerinin güven skorlarının dağılımını gösterir. Yüksek güven skorları modelin tahminlerinden emin olduğunu gösterir.

### 5. Manuscript Table (Makale Tablosu)

**Dosya**: `clinical_test_table.txt`

Makale için hazır, LaTeX formatında tablo içerir. Doğrudan kopyalayıp makalenize yapıştırabilirsiniz.

## Sorun Giderme

### Problem: Model dosyaları bulunamıyor

**Hata Mesajı:**
```
❌ Error loading model: [Errno 2] No such file or directory: '../ms_pupillography_ml/models/ms_detection_model.pkl'
```

**Çözüm:**
1. Model dosyalarının doğru dizinde olduğundan emin olun
2. Dizin yapısını kontrol edin:
   ```
   parent_directory/
   ├── clinical_test/
   │   ├── predict_batch.py
   │   └── ...
   └── ms_pupillography_ml/
       └── models/
           ├── ms_detection_model.pkl
           └── feature_scaler.pkl
   ```

### Problem: Görüntü bulunamıyor

**Hata Mesajı:**
```
❌ No image files found in data/
```

**Çözüm:**
1. Görüntülerin `data/` klasöründe olduğundan emin olun
2. Desteklenen formatlarda olduğunu kontrol edin (`.jpg`, `.png`, vb.)
3. Dosya izinlerini kontrol edin

### Problem: Excel dosyası oluşturulamıyor

**Hata Mesajı:**
```
⚠️  Could not save Excel file (openpyxl not installed)
```

**Çözüm:**
```bash
pip install openpyxl
```

### Problem: Kalite kontrolü başarısız oluyor

**Hata Mesajı:**
```
❌ Quality check failed: Image too small
```

**Çözüm:**
1. Görüntü boyutunun yeterli olduğundan emin olun (minimum 100x100 piksel)
2. Görüntünün bozuk olmadığını kontrol edin
3. Görüntü formatının desteklendiğinden emin olun

### Problem: Düşük performans metrikleri

**Durum**: Model beklenenden düşük performans gösteriyor

**Olası Nedenler ve Çözümler:**
1. **Veri kalitesi**: Görüntülerin kaliteli ve doğru şekilde çekildiğinden emin olun
2. **Etiket hataları**: `true_labels.csv` dosyasındaki etiketlerin doğru olduğunu kontrol edin
3. **Veri dağılımı**: Test verisinin eğitim verisine benzer olduğundan emin olun
4. **Model uyumsuzluğu**: Modelin doğru versiyon ile eğitildiğinden emin olun

## SSS

### S: Kaç görüntü işleyebilirim?

**C**: Sistem binlerce görüntüyü işleyebilir. İşlem süresi görüntü sayısına ve bilgisayarınızın performansına bağlıdır. Ortalama olarak, görüntü başına 1-2 saniye işlem süresi bekleyebilirsiniz.

### S: Gerçek etiketler olmadan kullanabilir miyim?

**C**: Evet. Gerçek etiketler olmadan da sistem tahmin yapabilir. Ancak performans metrikleri hesaplanamaz ve sadece tahminler elde edilir.

### S: Güven skorları ne anlama gelir?

**C**: Güven skoru, modelin tahmininden ne kadar emin olduğunu gösterir. %90 üzeri güven skorları yüksek kesinlik gösterirken, %50-60 arası skorlar belirsizlik gösterir.

### S: Hangi görüntü formatlarını destekliyor?

**C**: Sistem şu formatları destekler: `.jpg`, `.jpeg`, `.png`, `.bmp`, `.tif`, `.tiff`

### S: Sonuçları nasıl makaleme eklerim?

**C**: 
1. Grafikleri doğrudan kullanabilirsiniz (300 DPI kalitesinde)
2. `clinical_test_table.txt` dosyasındaki LaTeX tablosunu kopyalayıp yapıştırabilirsiniz
3. Excel raporundan metrikleri kopyalayabilirsiniz

### S: Model güncellenebilir mi?

**C**: Evet. Yeni bir model eğitirseniz, `ms_detection_model.pkl` ve `feature_scaler.pkl` dosyalarını güncelleyerek yeni modeli kullanabilirsiniz.

### S: Toplu işleme sırasında hata alırsam ne olur?

**C**: Sistem her görüntüyü bağımsız olarak işler. Bir görüntüde hata olsa bile diğer görüntüler işlenmeye devam eder. Hatalı görüntüler raporda "ERROR" olarak işaretlenir.

### S: Sonuçları nasıl yorumlamalıyım?

**C**:
- **Yüksek Sensitivity**: MS hastalarını yakalamada iyi
- **Yüksek Specificity**: Sağlıklı bireyleri doğru tanımlamada iyi
- **Yüksek Accuracy**: Genel olarak doğru tahminler
- **Yüksek AUC (>0.8)**: Güçlü sınıflandırma performansı

---

**Son Güncelleme**: 8 Ekim 2025
**Versiyon**: 1.0
