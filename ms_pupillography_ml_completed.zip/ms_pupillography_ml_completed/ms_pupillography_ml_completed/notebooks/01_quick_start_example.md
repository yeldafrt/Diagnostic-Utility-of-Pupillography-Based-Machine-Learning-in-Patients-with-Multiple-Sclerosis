# Quick Start Example

This notebook demonstrates how to use the MS Pupillography ML package for feature extraction, model training, and prediction.

## 1. Setup

```python
import sys
sys.path.append('../')

from src.feature_extraction import extract_features, batch_extract_features
from src.model_training import train_model, load_model, predict
from src.visualization import create_all_figures
import pandas as pd
import numpy as np
```

## 2. Feature Extraction

### Extract features from a single image

```python
# Extract features from one image
image_path = '../data/raw/control/P001_OD_01.png'
features = extract_features(image_path)

print(f"Extracted {len(features)} features:")
for feature_name, value in features.items():
    print(f"  {feature_name}: {value:.4f}")
```

### Batch extract features from a directory

```python
# Extract features from all images in a directory
feature_df = batch_extract_features(
    image_dir='../data/raw/',
    output_csv='../data/features/all_features.csv',
    resize_shape=(400, 200)
)

print(f"Extracted features from {len(feature_df)} images")
print(feature_df.head())
```

## 3. Model Training

### Train with patient-based stratification

```python
# Load features
features_df = pd.read_csv('../data/features/all_features.csv')

# Train model
model, scaler, metrics = train_model(
    features_csv='../data/features/all_features.csv',
    patient_id_column='patient_id',
    label_column='diagnosis',
    test_size=0.25,
    random_state=42,
    save_model=True,
    model_path='../models/ms_detection_model.pkl',
    scaler_path='../models/feature_scaler.pkl'
)

# Print performance metrics
print("\\nModel Performance:")
print(f"  Accuracy: {metrics['accuracy']:.3f}")
print(f"  Sensitivity: {metrics['sensitivity']:.3f}")
print(f"  Specificity: {metrics['specificity']:.3f}")
print(f"  Precision: {metrics['precision']:.3f}")
print(f"  F1-Score: {metrics['f1_score']:.3f}")
print(f"  AUC-ROC: {metrics['auc_roc']:.3f}")
```

### 5-Fold Cross-Validation

```python
from sklearn.model_selection import cross_validate
from sklearn.ensemble import RandomForestClassifier

# Prepare data
X = features_df.drop(['patient_id', 'diagnosis', 'image_path'], axis=1)
y = (features_df['diagnosis'] == 'MS').astype(int)

# Cross-validation
cv_model = RandomForestClassifier(
    n_estimators=100,
    max_depth=10,
    min_samples_split=5,
    min_samples_leaf=3,
    class_weight='balanced',
    random_state=42
)

cv_results = cross_validate(
    cv_model, X, y, cv=5,
    scoring=['accuracy', 'precision', 'recall', 'f1', 'roc_auc'],
    return_train_score=False
)

print("\\nCross-Validation Results:")
for metric in ['accuracy', 'precision', 'recall', 'f1', 'roc_auc']:
    scores = cv_results[f'test_{metric}']
    print(f"  {metric}: {scores.mean():.3f} ± {scores.std():.3f}")
```

## 4. Making Predictions

### Load trained model

```python
# Load model and scaler
model, scaler = load_model('../models/ms_detection_model.pkl',
                          '../models/feature_scaler.pkl')
```

### Predict on a new image

```python
# Predict on a single image
new_image_path = '../data/raw/control/P050_OD_01.png'
prediction, probability = predict(model, scaler, new_image_path)

print(f"\\nPrediction for {new_image_path}:")
print(f"  Diagnosis: {prediction}")
print(f"  Probability (MS): {probability:.3f}")
```

### Batch prediction

```python
# Predict on multiple images
test_images = [
    '../data/raw/control/P050_OD_01.png',
    '../data/raw/ms/P025_OS_01.png',
    '../data/raw/control/P051_OD_01.png',
]

results = []
for img_path in test_images:
    pred, prob = predict(model, scaler, img_path)
    results.append({
        'image': img_path,
        'prediction': pred,
        'probability_ms': prob
    })

results_df = pd.DataFrame(results)
print("\\nBatch Prediction Results:")
print(results_df)
```

## 5. Generate Figures

### Create all publication figures

```python
from src.visualization import (
    create_confusion_matrix,
    create_roc_curve,
    create_pr_curve,
    create_feature_importance,
    create_cross_validation_results
)

# Assuming you have test data
X_test = ...  # Test features
y_test = ...  # Test labels
y_pred = model.predict(scaler.transform(X_test))
y_scores = model.predict_proba(scaler.transform(X_test))[:, 1]

# Confusion Matrix
create_confusion_matrix(y_test, y_pred, 
                       output_path='../figures/confusion_matrix.png')

# ROC Curve
create_roc_curve(y_test, y_scores,
                output_path='../figures/roc_curve.png')

# PR Curve
create_pr_curve(y_test, y_scores,
               output_path='../figures/pr_curve.png')

# Feature Importance
feature_names = X_test.columns.tolist()
create_feature_importance(model, feature_names,
                         output_path='../figures/feature_importance.png')

# Cross-validation results
cv_dict = {
    'accuracy': cv_results['test_accuracy'],
    'precision': cv_results['test_precision'],
    'recall': cv_results['test_recall'],
    'f1_score': cv_results['test_f1'],
    'roc_auc': cv_results['test_roc_auc']
}
create_cross_validation_results(cv_dict,
                               output_path='../figures/cv_results.png')

print("\\nAll figures generated successfully!")
```

## 6. ICC Analysis

### Compute intra-class correlation coefficients

```python
import pingouin as pg

# Prepare data for ICC analysis
# Assuming features_df has 'patient_id' and feature columns
icc_results = []

feature_cols = [col for col in features_df.columns 
                if col not in ['patient_id', 'diagnosis', 'image_path']]

for feature in feature_cols:
    # Compute ICC(2,1) - two-way random effects, single rater
    icc_data = features_df[['patient_id', feature]].copy()
    icc_data['rater'] = icc_data.groupby('patient_id').cumcount()
    
    icc = pg.intraclass_corr(data=icc_data, 
                            targets='patient_id',
                            raters='rater',
                            ratings=feature)
    
    icc_value = icc[icc['Type'] == 'ICC2']['ICC'].values[0]
    
    icc_results.append({
        'feature': feature,
        'icc': icc_value,
        'reliability': 'Excellent' if icc_value > 0.75 else
                      'Good' if icc_value > 0.60 else
                      'Moderate' if icc_value > 0.40 else 'Poor'
    })

icc_df = pd.DataFrame(icc_results)
print("\\nICC Analysis Results:")
print(icc_df.sort_values('icc', ascending=False))

# Save results
icc_df.to_csv('../data/features/icc_results.csv', index=False)
```

## 7. Model Interpretation

### Feature importance analysis

```python
import matplotlib.pyplot as plt

# Get feature importances
importances = model.feature_importances_
feature_names = X_test.columns

# Sort by importance
indices = np.argsort(importances)[::-1]

print("\\nTop 10 Most Important Features:")
for i in range(10):
    print(f"  {i+1}. {feature_names[indices[i]]}: {importances[indices[i]]:.4f}")

# Plot
plt.figure(figsize=(10, 6))
plt.bar(range(10), importances[indices[:10]])
plt.xticks(range(10), [feature_names[i] for i in indices[:10]], rotation=45, ha='right')
plt.xlabel('Feature')
plt.ylabel('Importance')
plt.title('Top 10 Feature Importances')
plt.tight_layout()
plt.savefig('../figures/feature_importance_top10.png', dpi=300)
plt.close()
```

## Summary

This notebook demonstrated:
1. ✅ Feature extraction from OCT images
2. ✅ Model training with patient-based stratification
3. ✅ Cross-validation for model evaluation
4. ✅ Making predictions on new images
5. ✅ Generating publication-quality figures
6. ✅ ICC analysis for feature reliability
7. ✅ Model interpretation via feature importance

For more details, see the documentation in the `docs/` directory.
