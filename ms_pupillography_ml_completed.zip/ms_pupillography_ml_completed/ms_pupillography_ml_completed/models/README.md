# Trained Models

This directory contains the trained machine learning models for MS detection from pupillography images.

## Files

- `ms_detection_model.pkl` - Trained Random Forest classifier (100 trees)
- `feature_scaler.pkl` - StandardScaler for feature normalization

## Model Specifications

### Random Forest Classifier
- **Algorithm:** Random Forest
- **Number of estimators:** 100
- **Max depth:** 10
- **Min samples split:** 5
- **Min samples leaf:** 3
- **Class weight:** Balanced
- **Random state:** 42

### Performance Metrics (Test Set)
- **Accuracy:** 85.7%
- **Sensitivity (Recall):** 93.8%
- **Specificity:** 80.8%
- **Precision:** 75.0%
- **F1-Score:** 83.3%
- **AUC-ROC:** 0.945
- **AUC-PR:** 0.920

### Key Clinical Finding
**15 out of 16 MS patients correctly identified** in the test set, demonstrating excellent sensitivity for minimizing missed diagnoses.

## Usage

```python
import joblib

# Load model and scaler
model = joblib.load('models/ms_detection_model.pkl')
scaler = joblib.load('models/feature_scaler.pkl')

# Make prediction
features_scaled = scaler.transform(features)
prediction = model.predict(features_scaled)
probability = model.predict_proba(features_scaled)
```

## Training Data

### Dataset Statistics
- **Total images:** 692 pupillographic images
- **Total participants:** 63 (25 MS, 38 Control)
- **MS images:** 274
- **Control images:** 418

### Train/Test Split (Patient-Based Stratification)
- **Training set:** 384 images from 35 patients (9 MS, 26 Control)
- **Test set:** 308 images from 28 patients (16 MS, 12 Control)
- **Evaluation strategy:** Patient-based stratified split (no patient overlap)
- **Cross-validation:** 5-fold stratified CV on training set (mean accuracy: 56.7%)

## Feature Input

The model expects 22 features in the following order:

### 1. Basic Statistical Features (5)
1. mean_intensity
2. std_intensity
3. min_intensity
4. max_intensity
5. intensity_range

### 2. Pupil Morphology and Positional Features (6)
6. pupil_detected (binary)
7. pupil_radius
8. pupil_x_norm (normalized X coordinate)
9. pupil_y_norm (normalized Y coordinate)
10. pupil_mean_intensity
11. pupil_std_intensity

### 3. Texture Analysis Features (4)
12. gradient_mean (Sobel operator)
13. gradient_std
14. laplacian_variance (image sharpness)
15. laplacian_mean

### 4. Histogram-Based Features (3)
16. hist_peak (peak value of pixel distribution)
17. hist_entropy (Shannon entropy)
18. hist_uniformity (uniformity index)

### 5. Regional Analysis Features (4)
19. quadrant_0_mean
20. quadrant_1_mean
21. quadrant_2_mean
22. quadrant_3_mean

## Notes

- Features must be scaled using the provided `feature_scaler.pkl` before prediction
- Model was trained with patient-based stratification to prevent data leakage
- All features should be numerical (no missing values)
- Feature extraction code is available in `src/feature_extraction/extract_features.py`

## Model Files

- **ms_detection_model.pkl** (~394 KB)
  - Trained on 384 images from 35 patients
  - Achieves 85.7% accuracy on independent test set
  
- **feature_scaler.pkl** (~978 bytes)
  - StandardScaler fitted on training data
  - Normalizes features to [0, 1] range

## Citation

If you use these models, please cite our paper:

> Neslihan Parmak Yener, Yelda Fırat, Meral Seferoğlu, Ahmet Metin Kargın, Yılmaz Kılıçaslan. "Diagnostic Utility of Pupillography-Based Machine Learning in Patients with Multiple Sclerosis." (Under review)

## Contact

For questions about the models:
- **Email:** drnparmak@yahoo.com, parmakyener@gmail.com
- **Institution:** University of Health Sciences, Bursa Yuksek Ihtisas Training and Research Hospital
