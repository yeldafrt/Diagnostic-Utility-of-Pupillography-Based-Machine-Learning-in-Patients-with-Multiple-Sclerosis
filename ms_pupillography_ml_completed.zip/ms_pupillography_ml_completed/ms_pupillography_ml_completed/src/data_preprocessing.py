#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import glob
import numpy as np
import pandas as pd
from PIL import Image
import cv2
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import tensorflow as tf

# Sabit değerler
IMG_SIZE = (224, 224)  # ResNet için standart boyut
BATCH_SIZE = 32
SEED = 42

# Veri yolları
data_path = "/home/ubuntu/ms_oct_project/data/PUPШLLOGRAFШ HASTA VERШ"
kontrol_path = os.path.join(data_path, "kontrol grubu")
ms_path = os.path.join(data_path, "ms grubu")

def load_and_preprocess_images():
    """Görüntüleri yükle ve ön işleme yap"""
    
    print("Görüntüler yükleniyor ve ön işleme yapılıyor...")
    
    images = []
    labels = []
    patient_ids = []
    
    # Kontrol grubu
    kontrol_patients = [d for d in os.listdir(kontrol_path) if os.path.isdir(os.path.join(kontrol_path, d))]
    for patient in kontrol_patients:
        patient_path = os.path.join(kontrol_path, patient)
        image_files = glob.glob(os.path.join(patient_path, "*.jpg"))
        
        for img_file in image_files:
            try:
                # Görüntüyü yükle
                img = Image.open(img_file)
                img = img.convert('RGB')
                
                # Boyutlandır
                img = img.resize(IMG_SIZE)
                
                # NumPy array'e çevir ve normalize et
                img_array = np.array(img) / 255.0
                
                images.append(img_array)
                labels.append('kontrol')
                patient_ids.append(patient)
                
            except Exception as e:
                print(f"Hata: {img_file} - {e}")
                continue
    
    # MS grubu
    ms_patients = [d for d in os.listdir(ms_path) if os.path.isdir(os.path.join(ms_path, d))]
    for patient in ms_patients:
        patient_path = os.path.join(ms_path, patient)
        image_files = glob.glob(os.path.join(patient_path, "*.jpg"))
        
        for img_file in image_files:
            try:
                # Görüntüyü yükle
                img = Image.open(img_file)
                img = img.convert('RGB')
                
                # Boyutlandır
                img = img.resize(IMG_SIZE)
                
                # NumPy array'e çevir ve normalize et
                img_array = np.array(img) / 255.0
                
                images.append(img_array)
                labels.append('ms')
                patient_ids.append(patient)
                
            except Exception as e:
                print(f"Hata: {img_file} - {e}")
                continue
    
    # NumPy array'lere çevir
    X = np.array(images)
    y = np.array(labels)
    patient_ids = np.array(patient_ids)
    
    print(f"Toplam yüklenen görüntü sayısı: {len(X)}")
    print(f"Kontrol grubu: {np.sum(y == 'kontrol')}")
    print(f"MS grubu: {np.sum(y == 'ms')}")
    
    return X, y, patient_ids

def create_patient_based_split(X, y, patient_ids, test_size=0.2, val_size=0.2):
    """Hasta bazında veri setini böl"""
    
    # Benzersiz hastaları al
    unique_patients = np.unique(patient_ids)
    patient_labels = []
    
    for patient in unique_patients:
        # Her hastanın etiketini al (ilk görüntüsünden)
        patient_mask = patient_ids == patient
        patient_label = y[patient_mask][0]
        patient_labels.append(patient_label)
    
    patient_labels = np.array(patient_labels)
    
    # Hastaları train/test olarak böl
    train_patients, test_patients = train_test_split(
        unique_patients, 
        test_size=test_size, 
        stratify=patient_labels, 
        random_state=SEED
    )
    
    # Train hastalarını train/val olarak böl
    train_patient_labels = [patient_labels[np.where(unique_patients == p)[0][0]] for p in train_patients]
    train_patients, val_patients = train_test_split(
        train_patients, 
        test_size=val_size/(1-test_size), 
        stratify=train_patient_labels, 
        random_state=SEED
    )
    
    # Görüntüleri hasta bazında böl
    train_mask = np.isin(patient_ids, train_patients)
    val_mask = np.isin(patient_ids, val_patients)
    test_mask = np.isin(patient_ids, test_patients)
    
    X_train, y_train = X[train_mask], y[train_mask]
    X_val, y_val = X[val_mask], y[val_mask]
    X_test, y_test = X[test_mask], y[test_mask]
    
    print(f"\nHasta bazında veri bölümü:")
    print(f"Train hastaları: {len(train_patients)} ({len(X_train)} görüntü)")
    print(f"Validation hastaları: {len(val_patients)} ({len(X_val)} görüntü)")
    print(f"Test hastaları: {len(test_patients)} ({len(X_test)} görüntü)")
    
    return (X_train, y_train), (X_val, y_val), (X_test, y_test)

def encode_labels(y_train, y_val, y_test):
    """Etiketleri encode et"""
    
    le = LabelEncoder()
    y_train_encoded = le.fit_transform(y_train)
    y_val_encoded = le.transform(y_val)
    y_test_encoded = le.transform(y_test)
    
    print(f"\nEtiket kodlaması:")
    for i, class_name in enumerate(le.classes_):
        print(f"{class_name}: {i}")
    
    return y_train_encoded, y_val_encoded, y_test_encoded, le

def create_data_generators():
    """Veri artırma için generator'lar oluştur"""
    
    # Eğitim için veri artırma
    train_datagen = ImageDataGenerator(
        rotation_range=10,
        width_shift_range=0.1,
        height_shift_range=0.1,
        horizontal_flip=True,
        zoom_range=0.1,
        fill_mode='nearest'
    )
    
    # Validation ve test için sadece normalizasyon
    val_test_datagen = ImageDataGenerator()
    
    return train_datagen, val_test_datagen

def visualize_data_distribution(y_train, y_val, y_test):
    """Veri dağılımını görselleştir"""
    
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    # Train dağılımı
    train_counts = pd.Series(y_train).value_counts()
    axes[0].bar(train_counts.index, train_counts.values)
    axes[0].set_title('Eğitim Seti Dağılımı')
    axes[0].set_ylabel('Görüntü Sayısı')
    
    # Validation dağılımı
    val_counts = pd.Series(y_val).value_counts()
    axes[1].bar(val_counts.index, val_counts.values)
    axes[1].set_title('Doğrulama Seti Dağılımı')
    axes[1].set_ylabel('Görüntü Sayısı')
    
    # Test dağılımı
    test_counts = pd.Series(y_test).value_counts()
    axes[2].bar(test_counts.index, test_counts.values)
    axes[2].set_title('Test Seti Dağılımı')
    axes[2].set_ylabel('Görüntü Sayısı')
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/ms_oct_project/results/data_distribution.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("Veri dağılımı grafiği kaydedildi: results/data_distribution.png")

def save_preprocessed_data(X_train, y_train, X_val, y_val, X_test, y_test, le):
    """Ön işlenmiş veriyi kaydet"""
    
    print("Ön işlenmiş veriler kaydediliyor...")
    
    # NumPy formatında kaydet
    np.save('/home/ubuntu/ms_oct_project/data/X_train.npy', X_train)
    np.save('/home/ubuntu/ms_oct_project/data/y_train.npy', y_train)
    np.save('/home/ubuntu/ms_oct_project/data/X_val.npy', X_val)
    np.save('/home/ubuntu/ms_oct_project/data/y_val.npy', y_val)
    np.save('/home/ubuntu/ms_oct_project/data/X_test.npy', X_test)
    np.save('/home/ubuntu/ms_oct_project/data/y_test.npy', y_test)
    
    # Label encoder'ı kaydet
    import pickle
    with open('/home/ubuntu/ms_oct_project/models/label_encoder.pkl', 'wb') as f:
        pickle.dump(le, f)
    
    print("Veriler başarıyla kaydedildi!")

def main():
    """Ana fonksiyon"""
    
    # Sonuçlar ve modeller klasörlerini oluştur
    os.makedirs('/home/ubuntu/ms_oct_project/results', exist_ok=True)
    os.makedirs('/home/ubuntu/ms_oct_project/models', exist_ok=True)
    
    # Görüntüleri yükle ve ön işle
    X, y, patient_ids = load_and_preprocess_images()
    
    # Hasta bazında veri setini böl
    (X_train, y_train), (X_val, y_val), (X_test, y_test) = create_patient_based_split(X, y, patient_ids)
    
    # Etiketleri encode et
    y_train_encoded, y_val_encoded, y_test_encoded, le = encode_labels(y_train, y_val, y_test)
    
    # Veri dağılımını görselleştir
    visualize_data_distribution(y_train, y_val, y_test)
    
    # Ön işlenmiş veriyi kaydet
    save_preprocessed_data(X_train, y_train_encoded, X_val, y_val_encoded, X_test, y_test_encoded, le)
    
    print("\n=== VERİ ÖN İŞLEME TAMAMLANDI ===")
    print(f"Eğitim seti: {X_train.shape}")
    print(f"Doğrulama seti: {X_val.shape}")
    print(f"Test seti: {X_test.shape}")

if __name__ == "__main__":
    main()

