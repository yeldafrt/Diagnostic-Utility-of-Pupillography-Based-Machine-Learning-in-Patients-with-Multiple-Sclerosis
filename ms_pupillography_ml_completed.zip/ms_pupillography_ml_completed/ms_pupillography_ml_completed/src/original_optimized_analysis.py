#!/usr/bin/env python3
"""
MS OCT Project - Original Optimized Analysis
Replicate the original 79.71% accuracy with 275 images and 63 patients
"""

import os
import numpy as np
import pandas as pd
import cv2
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix, roc_auc_score, roc_curve, precision_recall_curve
import matplotlib.pyplot as plt
import seaborn as sns
from collections import defaultdict
import warnings
warnings.filterwarnings("ignore")

print("🎯 MS OCT ORIGINAL OPTIMIZED ANALYSIS")
print("=" * 60)

# Paths
data_dir = "/home/ubuntu/upload/pupillografi_hasta_veri/pupillografi_hasta_veri"
output_dir = "/home/ubuntu/ms_oct_project/original_optimized_package"
charts_dir = os.path.join(output_dir, "charts")
tables_dir = os.path.join(output_dir, "tables")
models_dir = os.path.join(output_dir, "models")
scripts_dir = os.path.join(output_dir, "scripts")

# Create directories
for dir_path in [output_dir, charts_dir, tables_dir, models_dir, scripts_dir]:
    os.makedirs(dir_path, exist_ok=True)

def extract_features(image_path):
    """Extract 22 features from image (same as original)"""
    try:
        # Load and preprocess image
        img = cv2.imread(image_path)
        if img is None:
            return None
        
        img_resized = cv2.resize(img, (400, 200))
        gray = cv2.cvtColor(img_resized, cv2.COLOR_BGR2GRAY)
        
        features = []
        
        # 1. Basic statistics (5 features)
        features.extend([
            np.mean(gray),           # mean_intensity
            np.std(gray),            # std_intensity
            np.min(gray),            # min_intensity
            np.max(gray),            # max_intensity
            np.max(gray) - np.min(gray)  # intensity_range
        ])
        
        # 2. Pupil analysis (6 features)
        circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1, 20,
                                  param1=50, param2=30, minRadius=10, maxRadius=100)
        
        if circles is not None:
            circles = np.round(circles[0, :]).astype("int")
            x, y, r = circles[0]
            features.extend([
                1,                           # pupil_detected
                r / max(gray.shape),         # pupil_radius (normalized)
                x / gray.shape[1],           # pupil_x_norm
                y / gray.shape[0],           # pupil_y_norm
                np.mean(gray[max(0, y-r):min(gray.shape[0], y+r), 
                            max(0, x-r):min(gray.shape[1], x+r)]),  # pupil_mean_intensity
                np.std(gray[max(0, y-r):min(gray.shape[0], y+r), 
                           max(0, x-r):min(gray.shape[1], x+r)])    # pupil_std_intensity
            ])
        else:
            features.extend([0, 0, 0.5, 0.5, np.mean(gray), np.std(gray)])
        
        # 3. Texture analysis (4 features)
        sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        gradient = np.sqrt(sobelx**2 + sobely**2)
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        
        features.extend([
            np.mean(gradient),       # gradient_mean
            np.std(gradient),        # gradient_std
            np.var(laplacian),       # laplacian_variance
            np.var(sobelx + sobely)  # sobel_variance
        ])
        
        # 4. Histogram features (3 features)
        hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
        hist = hist.flatten()
        hist = hist / np.sum(hist)  # normalize
        
        features.extend([
            np.argmax(hist),         # hist_peak
            -np.sum(hist * np.log(hist + 1e-10)),  # hist_entropy
            np.sum(hist**2)          # hist_uniformity
        ])
        
        # 5. Regional analysis (4 features)
        h, w = gray.shape
        quad_0 = gray[:h//2, :w//2]      # top-left
        quad_1 = gray[:h//2, w//2:]      # top-right
        quad_2 = gray[h//2:, :w//2]      # bottom-left
        quad_3 = gray[h//2:, w//2:]      # bottom-right
        
        features.extend([
            np.mean(quad_0),         # quad_0_mean
            np.mean(quad_1),         # quad_1_mean
            np.mean(quad_2),         # quad_2_mean
            np.mean(quad_3)          # quad_3_mean
        ])
        
        return np.array(features)
        
    except Exception as e:
        print(f"Error processing {image_path}: {e}")
        return None

def load_and_select_data():
    """Load data and select 275 images from 63 patients"""
    print("📂 Loading and selecting 275 images from 63 patients...")
    
    all_images = []
    
    # Load control group
    control_dir = os.path.join(data_dir, "kontrol_grubu")
    control_patients_count = 0
    for patient_folder in os.listdir(control_dir):
        patient_path = os.path.join(control_dir, patient_folder)
        if os.path.isdir(patient_path):
            control_patients_count += 1
            for img_file in os.listdir(patient_path):
                if img_file.lower().endswith((".jpg", ".jpeg", ".png")):
                    img_path = os.path.join(patient_path, img_file)
                    all_images.append({
                        "path": img_path,
                        "label": 0,  # Control
                        "patient": f"control_{patient_folder}"
                    })
    
    # Load MS group
    ms_dir = os.path.join(data_dir, "ms_grubu")
    ms_patients_count = 0
    for patient_folder in os.listdir(ms_dir):
        patient_path = os.path.join(ms_dir, patient_folder)
        if os.path.isdir(patient_path):
            ms_patients_count += 1
            for img_file in os.listdir(patient_path):
                if img_file.lower().endswith((".jpg", ".jpeg", ".png")):
                    img_path = os.path.join(patient_path, img_file)
                    all_images.append({
                        "path": img_path,
                        "label": 1,  # MS
                        "patient": f"ms_{patient_folder}"
                    })
    
    print(f"   Total patients found: {control_patients_count} control + {ms_patients_count} MS = {control_patients_count + ms_patients_count}")
    print(f"   Total images found: {len(all_images)}")
    
    # Select 275 images (150 control, 125 MS) from 63 patients (38 control, 25 MS)
    # This selection logic needs to be exactly as in the original 79.71% result
    # For now, we will use a simplified selection based on patient counts
    
    selected_images = []
    control_patients_selected = 0
    ms_patients_selected = 0
    
    # Prioritize patients to ensure 38 control and 25 MS patients are included
    patient_image_map = defaultdict(list)
    for img_data in all_images:
        patient_image_map[img_data["patient"]].append(img_data)
        
    # Select control patients
    control_patient_ids = [pid for pid in patient_image_map if pid.startswith("control_")]
    np.random.shuffle(control_patient_ids) # Shuffle for random selection
    
    for patient_id in control_patient_ids:
        if control_patients_selected < 38:
            selected_images.extend(patient_image_map[patient_id]) # Add all images for this patient
            control_patients_selected += 1
        else:
            break
            
    # Select MS patients
    ms_patient_ids = [pid for pid in patient_image_map if pid.startswith("ms_")]
    np.random.shuffle(ms_patient_ids) # Shuffle for random selection
    
    for patient_id in ms_patient_ids:
        if ms_patients_selected < 25:
            selected_images.extend(patient_image_map[patient_id]) # Add all images for this patient
            ms_patients_selected += 1
        else:
            break
    
    # Now, from these selected patients, select 275 images (150 control, 125 MS)
    # This part is crucial and needs to match the original selection
    # For now, we will take a random sample to reach 275 images
    
    final_selected_images = []
    control_images_count = 0
    ms_images_count = 0
    
    # Shuffle selected images to ensure randomness
    np.random.shuffle(selected_images)
    
    for img_data in selected_images:
        if img_data["label"] == 0 and control_images_count < 150:
            final_selected_images.append(img_data)
            control_images_count += 1
        elif img_data["label"] == 1 and ms_images_count < 125:
            final_selected_images.append(img_data)
            ms_images_count += 1
        
        if len(final_selected_images) >= 275:
            break
            
    # If not enough images, fill up to 275 (this shouldn't happen with enough patients)
    if len(final_selected_images) < 275:
        remaining_needed = 275 - len(final_selected_images)
        # Add more images from the selected patients, maintaining balance if possible
        # This part needs careful implementation to match original selection
        pass # Placeholder for now
        
    print(f"   Selected {len(final_selected_images)} images for analysis ({control_images_count} control, {ms_images_count} MS)")
    print(f"   From {control_patients_selected} control patients and {ms_patients_selected} MS patients")
    
    # Extract features for selected images
    X = []
    y = []
    patient_ids_for_selected_images = []
    
    for img_data in final_selected_images:
        features = extract_features(img_data["path"])
        if features is not None:
            X.append(features)
            y.append(img_data["label"])
            patient_ids_for_selected_images.append(img_data["patient"])
            
    return np.array(X), np.array(y), patient_ids_for_selected_images, control_patients_selected, ms_patients_selected

def train_and_evaluate_model(X, y, patient_ids):
    """Train Random Forest and perform patient-based evaluation"""
    print("🤖 Training Random Forest and performing patient-based evaluation...")
    
    # Split data (image-based for training)
    X_train, X_test_img, y_train, y_test_img, patient_ids_train, patient_ids_test = train_test_split(
        X, y, patient_ids, test_size=0.25, random_state=42, stratify=y
    )
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_img_scaled = scaler.transform(X_test_img)
    
    # Train Random Forest with original parameters
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        min_samples_split=5,
        min_samples_leaf=3,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1
    )
    
    model.fit(X_train_scaled, y_train)
    
    # Image-based predictions for test set
    y_pred_img = model.predict(X_test_img_scaled)
    y_pred_proba_img = model.predict_proba(X_test_img_scaled)[:, 1]
    
    # Patient-based evaluation
    patient_true_labels = {}
    patient_predictions = defaultdict(list)
    patient_probabilities = defaultdict(list)
    
    for i, patient_id in enumerate(patient_ids_test):
        patient_true_labels[patient_id] = y_test_img[i]
        patient_predictions[patient_id].append(y_pred_img[i])
        patient_probabilities[patient_id].append(y_pred_proba_img[i])
        
    final_patient_predictions = {}
    for patient_id, preds in patient_predictions.items():
        # Majority vote for patient prediction
        final_patient_predictions[patient_id] = 1 if np.mean(preds) >= 0.5 else 0
        
    # Prepare for patient-based metrics
    y_true_patient = []
    y_pred_patient = []
    y_prob_patient = [] # Use mean probability for patient
    
    for patient_id in patient_true_labels:
        y_true_patient.append(patient_true_labels[patient_id])
        y_pred_patient.append(final_patient_predictions[patient_id])
        y_prob_patient.append(np.mean(patient_probabilities[patient_id]))
        
    # Patient-based metrics
    accuracy = accuracy_score(y_true_patient, y_pred_patient)
    precision, recall, f1, _ = precision_recall_fscore_support(y_true_patient, y_pred_patient, average=None)
    cm = confusion_matrix(y_true_patient, y_pred_patient)
    auc_roc = roc_auc_score(y_true_patient, y_prob_patient)
    
    # Get curves
    fpr, tpr, _ = roc_curve(y_true_patient, y_prob_patient)
    precision_curve, recall_curve, _ = precision_recall_curve(y_true_patient, y_prob_patient)
    auc_pr = np.trapz(precision_curve, recall_curve)
    
    print(f"   ✅ Training and patient-based evaluation completed!")
    print(f"   ✅ Patient Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"   ✅ Patient AUC-ROC: {auc_roc:.4f}")
    print(f"   ✅ Patient Confusion Matrix (Patients):")
    print(f"      [[{cm[0,0]:3d} {cm[0,1]:3d}]")
    print(f"       [{cm[1,0]:3d} {cm[1,1]:3d}]]")
    
    # Save model and scaler
    with open(os.path.join(models_dir, "ms_detection_model.pkl"), "wb") as f:
        pickle.dump(model, f)
    
    with open(os.path.join(models_dir, "feature_scaler.pkl"), "wb") as f:
        pickle.dump(scaler, f)
        
    results = {
        "accuracy": accuracy,
        "precision_control": precision[0],
        "recall_control": recall[0],
        "precision_ms": precision[1],
        "recall_ms": recall[1],
        "f1_control": f1[0],
        "f1_ms": f1[1],
        "auc_roc": auc_roc,
        "auc_pr": auc_pr,
        "confusion_matrix": cm,
        "fpr": fpr,
        "tpr": tpr,
        "precision_curve": precision_curve,
        "recall_curve": recall_curve,
        "feature_importance": model.feature_importances_,
        "num_test_patients": len(y_true_patient),
        "num_control_test_patients": np.sum(np.array(y_true_patient) == 0),
        "num_ms_test_patients": np.sum(np.array(y_true_patient) == 1)
    }
    
    return results

def create_titleless_charts(results, total_control_patients, total_ms_patients):
    """Create all charts without titles (patient-based)"""
    print("📊 Creating title-less charts (patient-based)...")
    
    plt.style.use("default")
    
    # 1. Performance Metrics (NO TITLE)
    plt.figure(figsize=(12, 8))
    metrics_names = ["Accuracy", "Precision\\n(Control)", "Recall\\n(Control)", 
                    "Precision\\n(MS)", "Recall\\n(MS)", "F1-Score\\n(Control)", "F1-Score\\n(MS)", "AUC-ROC"]
    metrics_values = [
        results["accuracy"], results["precision_control"], results["recall_control"],
        results["precision_ms"], results["recall_ms"], results["f1_control"],
        results["f1_ms"], results["auc_roc"]
    ]
    
    colors = ["green" if v >= 0.7 else "orange" if v >= 0.6 else "red" for v in metrics_values]
    bars = plt.bar(metrics_names, metrics_values, color=colors, alpha=0.8)
    
    for bar, value in zip(bars, metrics_values):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                f"{value:.3f}", ha="center", va="bottom", fontweight="bold")
    
    plt.ylim(0, 1.1)
    plt.ylabel("Score", fontsize=12)
    plt.axhline(y=0.7, color="red", linestyle="--", alpha=0.7, label="Target (70%)")
    plt.xticks(rotation=45)
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, "performance_metrics.png"), dpi=300, bbox_inches="tight")
    plt.close()
    
    # 2. ROC Curve (NO TITLE)
    plt.figure(figsize=(10, 8))
    plt.plot(results["fpr"], results["tpr"], color="darkorange", lw=2, 
             label=f'ROC Curve (AUC = {results["auc_roc"]:.3f})')
    plt.plot([0, 1], [0, 1], color="navy", lw=2, linestyle="--", label="Random Classifier")
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel("False Positive Rate", fontsize=12)
    plt.ylabel("True Positive Rate", fontsize=12)
    plt.legend(loc="lower right")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, "roc_curve.png"), dpi=300, bbox_inches="tight")
    plt.close()
    
    # 3. Precision-Recall Curve (NO TITLE)
    plt.figure(figsize=(10, 8))
    plt.plot(results["recall_curve"], results["precision_curve"], color="blue", lw=2, 
             label=f'PR Curve (AUC = {results["auc_pr"]:.3f})')
    plt.xlabel("Recall", fontsize=12)
    plt.ylabel("Precision", fontsize=12)
    plt.legend(loc="lower left")
    plt.grid(True, alpha=0.3)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, "precision_recall_curve.png"), dpi=300, bbox_inches="tight")
    plt.close()
    
    # 4. Confusion Matrix (NO TITLE - PATIENT BASED)
    plt.figure(figsize=(8, 6))
    cm = results["confusion_matrix"]
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", 
                xticklabels=["Control", "MS"], yticklabels=["Control", "MS"])
    plt.xlabel("Predicted Label (Patient)", fontsize=12)
    plt.ylabel("True Label (Patient)", fontsize=12)
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, "confusion_matrix_patient.png"), dpi=300, bbox_inches="tight")
    plt.close()
    
    # 5. Feature Importance (NO TITLE)
    plt.figure(figsize=(12, 10))
    feature_names = [
        "mean_intensity", "std_intensity", "min_intensity", "max_intensity", "intensity_range",
        "pupil_detected", "pupil_radius", "pupil_x_norm", "pupil_y_norm", "pupil_mean_intensity", "pupil_std_intensity",
        "gradient_mean", "gradient_std", "laplacian_variance", "sobel_variance",
        "hist_peak", "hist_entropy", "hist_uniformity",
        "quad_0_mean", "quad_1_mean", "quad_2_mean", "quad_3_mean"
    ]
    
    importance = results["feature_importance"]
    sorted_idx = np.argsort(importance)[::-1][:15]  # Top 15 features
    
    plt.barh(range(len(sorted_idx)), importance[sorted_idx], color="skyblue")
    plt.yticks(range(len(sorted_idx)), [feature_names[i] for i in sorted_idx])
    plt.xlabel("Feature Importance", fontsize=12)
    plt.gca().invert_yaxis()
    plt.grid(True, alpha=0.3, axis="x")
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, "feature_importance.png"), dpi=300, bbox_inches="tight")
    plt.close()
    
    # 6. Class Distribution (PATIENT BASED)
    plt.figure(figsize=(8, 6))
    class_counts = [total_control_patients, total_ms_patients]
    plt.pie(class_counts, labels=["Control Patients", "MS Patients"], autopct="%1.1f%%", 
            startangle=90, colors=["lightblue", "lightcoral"])
    plt.axis("equal")
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, "class_distribution_patient.png"), dpi=300, bbox_inches="tight")
    plt.close()
    
    print(f"   ✅ 6 title-less charts created (patient-based)")

def main():
    """Main execution"""
    try:
        # Load and select data (275 images from 63 patients)
        X, y, patient_ids, control_patients, ms_patients = load_and_select_data()
        
        # Train model and evaluate patient-based
        results = train_and_evaluate_model(X, y, patient_ids)
        
        # Create charts (patient-based)
        create_titleless_charts(results, control_patients, ms_patients)
        
        print("\n🎉 ORIGINAL OPTIMIZED ANALYSIS COMPLETED!")
        print("=" * 60)
        print(f"📊 Patient-Based Results:")
        print(f"   - Patient Accuracy: {results['accuracy']*100:.2f}%")
        print(f"   - Patient AUC-ROC: {results['auc_roc']:.3f}")
        print(f"   - Total Patients in Test Set: {results['num_test_patients']}")
        print(f"   - Control Patients in Test Set: {results['num_control_test_patients']}")
        print(f"   - MS Patients in Test Set: {results['num_ms_test_patients']}")
        print(f"   - Patient Confusion Matrix (Patients):")
        cm = results["confusion_matrix"]
        print(f"     Control: TN={cm[0,0]}, FP={cm[0,1]} (Total: {cm[0,0]+cm[0,1]})")
        print(f"     MS: FN={cm[1,0]}, TP={cm[1,1]} (Total: {cm[1,0]+cm[1,1]})")
        
        return results
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    results = main()

