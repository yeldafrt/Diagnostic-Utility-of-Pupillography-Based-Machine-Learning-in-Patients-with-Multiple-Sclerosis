#!/usr/bin/env python3
"""
MS OCT Project - Model Architecture Visualizations
Create visual diagrams of model architecture and data flow
"""

import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch, ConnectionPatch
import numpy as np
import os

# Set paths
charts_dir = "/home/ubuntu/ms_oct_project/correct_package/charts"

def create_random_forest_architecture():
    """Create Random Forest architecture diagram"""
    print("🌳 Creating Random Forest Architecture Diagram...")
    
    fig, ax = plt.subplots(figsize=(14, 10))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 10)
    ax.axis('off')
    
    # Title
    ax.text(7, 9.5, 'Random Forest Model Architecture', fontsize=16, fontweight='bold', ha='center')
    
    # Input data
    input_box = FancyBboxPatch((1, 8), 2, 0.8, boxstyle="round,pad=0.1", 
                               facecolor='lightblue', edgecolor='black', linewidth=2)
    ax.add_patch(input_box)
    ax.text(2, 8.4, 'Input Features\n(22 features)', fontsize=10, ha='center', va='center', fontweight='bold')
    
    # Feature scaling
    scaler_box = FancyBboxPatch((5, 8), 2, 0.8, boxstyle="round,pad=0.1", 
                                facecolor='lightgreen', edgecolor='black', linewidth=2)
    ax.add_patch(scaler_box)
    ax.text(6, 8.4, 'StandardScaler\nNormalization', fontsize=10, ha='center', va='center', fontweight='bold')
    
    # Random Forest (100 trees)
    forest_y_positions = np.linspace(5.5, 6.5, 5)
    forest_x_positions = np.linspace(2, 12, 5)
    
    # Draw trees
    for i, (x, y) in enumerate(zip(forest_x_positions, forest_y_positions)):
        if i < 3:  # Show first 3 trees
            tree_box = FancyBboxPatch((x-0.4, y-0.3), 0.8, 0.6, boxstyle="round,pad=0.05", 
                                     facecolor='lightcoral', edgecolor='darkred', linewidth=1)
            ax.add_patch(tree_box)
            ax.text(x, y, f'Tree {i+1}', fontsize=8, ha='center', va='center', fontweight='bold')
        elif i == 3:  # Show dots
            ax.text(x, y, '...', fontsize=16, ha='center', va='center', fontweight='bold')
        else:  # Show last tree
            tree_box = FancyBboxPatch((x-0.4, y-0.3), 0.8, 0.6, boxstyle="round,pad=0.05", 
                                     facecolor='lightcoral', edgecolor='darkred', linewidth=1)
            ax.add_patch(tree_box)
            ax.text(x, y, 'Tree 100', fontsize=8, ha='center', va='center', fontweight='bold')
    
    # Random Forest label
    ax.text(7, 7.2, 'Random Forest Ensemble (100 Decision Trees)', fontsize=12, ha='center', fontweight='bold')
    
    # Voting mechanism
    voting_box = FancyBboxPatch((5.5, 4), 3, 0.8, boxstyle="round,pad=0.1", 
                                facecolor='gold', edgecolor='orange', linewidth=2)
    ax.add_patch(voting_box)
    ax.text(7, 4.4, 'Majority Voting\n(Ensemble Decision)', fontsize=10, ha='center', va='center', fontweight='bold')
    
    # Output
    output_box = FancyBboxPatch((5.5, 2), 3, 0.8, boxstyle="round,pad=0.1", 
                                facecolor='lightpink', edgecolor='purple', linewidth=2)
    ax.add_patch(output_box)
    ax.text(7, 2.4, 'Final Prediction\n(Control / MS)', fontsize=10, ha='center', va='center', fontweight='bold')
    
    # Arrows
    # Input to Scaler
    arrow1 = ConnectionPatch((3, 8.4), (5, 8.4), "data", "data", 
                            arrowstyle="->", shrinkA=5, shrinkB=5, mutation_scale=20, fc="black")
    ax.add_artist(arrow1)
    
    # Scaler to Forest
    arrow2 = ConnectionPatch((6, 8), (7, 7.2), "data", "data", 
                            arrowstyle="->", shrinkA=5, shrinkB=5, mutation_scale=20, fc="black")
    ax.add_artist(arrow2)
    
    # Forest to Voting
    arrow3 = ConnectionPatch((7, 5.5), (7, 4.8), "data", "data", 
                            arrowstyle="->", shrinkA=5, shrinkB=5, mutation_scale=20, fc="black")
    ax.add_artist(arrow3)
    
    # Voting to Output
    arrow4 = ConnectionPatch((7, 4), (7, 2.8), "data", "data", 
                            arrowstyle="->", shrinkA=5, shrinkB=5, mutation_scale=20, fc="black")
    ax.add_artist(arrow4)
    
    # Model parameters
    params_text = """Model Parameters:
• n_estimators: 100
• max_depth: 10
• min_samples_split: 5
• min_samples_leaf: 3
• class_weight: balanced
• random_state: 42"""
    
    ax.text(0.5, 3.5, params_text, fontsize=9, va='top', 
            bbox=dict(boxstyle="round,pad=0.3", facecolor='lightyellow', edgecolor='gray'))
    
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'random_forest_architecture.png'), dpi=300, bbox_inches='tight')
    plt.close()

def create_feature_engineering_pipeline():
    """Create feature engineering pipeline diagram"""
    print("🔧 Creating Feature Engineering Pipeline...")
    
    fig, ax = plt.subplots(figsize=(16, 12))
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 12)
    ax.axis('off')
    
    # Title
    ax.text(8, 11.5, 'Feature Engineering Pipeline (22 Features)', fontsize=16, fontweight='bold', ha='center')
    
    # Input image
    img_box = FancyBboxPatch((1, 9.5), 2.5, 1.5, boxstyle="round,pad=0.1", 
                             facecolor='lightblue', edgecolor='black', linewidth=2)
    ax.add_patch(img_box)
    ax.text(2.25, 10.25, 'OCT Pupillography\nImage\n(923x1906 → 400x200)', 
            fontsize=9, ha='center', va='center', fontweight='bold')
    
    # Feature categories
    categories = [
        {'name': 'Basic Statistics\n(5 features)', 'pos': (5, 9.5), 'color': 'lightgreen',
         'features': ['mean_intensity', 'std_intensity', 'min_intensity', 'max_intensity', 'intensity_range']},
        
        {'name': 'Pupil Analysis\n(6 features)', 'pos': (9, 9.5), 'color': 'lightcoral',
         'features': ['pupil_detected', 'pupil_radius', 'pupil_x_norm', 'pupil_y_norm', 'pupil_mean_intensity', 'pupil_std_intensity']},
        
        {'name': 'Texture Analysis\n(4 features)', 'pos': (13, 9.5), 'color': 'lightyellow',
         'features': ['gradient_mean', 'gradient_std', 'laplacian_variance', 'sobel_variance']},
        
        {'name': 'Histogram Features\n(3 features)', 'pos': (5, 6.5), 'color': 'lightpink',
         'features': ['hist_peak', 'hist_entropy', 'hist_uniformity']},
        
        {'name': 'Regional Analysis\n(4 features)', 'pos': (9, 6.5), 'color': 'lightcyan',
         'features': ['quad_0_mean', 'quad_1_mean', 'quad_2_mean', 'quad_3_mean']}
    ]
    
    # Draw feature categories
    for cat in categories:
        box = FancyBboxPatch((cat['pos'][0]-1, cat['pos'][1]-0.75), 2.5, 1.5, 
                             boxstyle="round,pad=0.1", facecolor=cat['color'], 
                             edgecolor='black', linewidth=1)
        ax.add_patch(box)
        ax.text(cat['pos'][0]+0.25, cat['pos'][1], cat['name'], 
                fontsize=10, ha='center', va='center', fontweight='bold')
        
        # List features below
        feature_text = '\n'.join([f'• {f}' for f in cat['features']])
        ax.text(cat['pos'][0]+0.25, cat['pos'][1]-1.8, feature_text, 
                fontsize=7, ha='center', va='top')
    
    # Arrows from input to categories
    for cat in categories:
        if cat['pos'][1] > 8:  # Top row
            arrow = ConnectionPatch((3.5, 10.25), (cat['pos'][0]-1, cat['pos'][1]), 
                                   "data", "data", arrowstyle="->", shrinkA=5, shrinkB=5, 
                                   mutation_scale=15, fc="blue", alpha=0.7)
        else:  # Bottom row
            arrow = ConnectionPatch((3.5, 9.5), (cat['pos'][0]-1, cat['pos'][1]+0.75), 
                                   "data", "data", arrowstyle="->", shrinkA=5, shrinkB=5, 
                                   mutation_scale=15, fc="blue", alpha=0.7)
        ax.add_artist(arrow)
    
    # Feature vector
    vector_box = FancyBboxPatch((6, 3), 4, 1, boxstyle="round,pad=0.1", 
                                facecolor='orange', edgecolor='black', linewidth=2)
    ax.add_patch(vector_box)
    ax.text(8, 3.5, 'Feature Vector\n(22 numerical features)', 
            fontsize=11, ha='center', va='center', fontweight='bold')
    
    # Arrows to feature vector
    for cat in categories:
        arrow = ConnectionPatch((cat['pos'][0]+0.25, cat['pos'][1]-2.5), (8, 4), 
                               "data", "data", arrowstyle="->", shrinkA=5, shrinkB=5, 
                               mutation_scale=15, fc="green", alpha=0.7)
        ax.add_artist(arrow)
    
    # StandardScaler
    scaler_box = FancyBboxPatch((6, 1), 4, 1, boxstyle="round,pad=0.1", 
                                facecolor='lightgray', edgecolor='black', linewidth=2)
    ax.add_patch(scaler_box)
    ax.text(8, 1.5, 'StandardScaler\n(Normalization)', 
            fontsize=11, ha='center', va='center', fontweight='bold')
    
    # Final arrow
    arrow_final = ConnectionPatch((8, 3), (8, 2), "data", "data", 
                                 arrowstyle="->", shrinkA=5, shrinkB=5, 
                                 mutation_scale=20, fc="black")
    ax.add_artist(arrow_final)
    
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'feature_engineering_pipeline.png'), dpi=300, bbox_inches='tight')
    plt.close()

def create_data_flow_diagram():
    """Create complete data flow diagram"""
    print("📊 Creating Data Flow Diagram...")
    
    fig, ax = plt.subplots(figsize=(14, 10))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 10)
    ax.axis('off')
    
    # Title
    ax.text(7, 9.5, 'MS OCT Analysis - Complete Data Flow', fontsize=16, fontweight='bold', ha='center')
    
    # Data input
    data_box = FancyBboxPatch((1, 8), 2.5, 1, boxstyle="round,pad=0.1", 
                              facecolor='lightblue', edgecolor='black', linewidth=2)
    ax.add_patch(data_box)
    ax.text(2.25, 8.5, 'OCT Images\n692 total\n(418 Control + 274 MS)', 
            fontsize=9, ha='center', va='center', fontweight='bold')
    
    # Data preprocessing
    preprocess_box = FancyBboxPatch((5, 8), 2.5, 1, boxstyle="round,pad=0.1", 
                                    facecolor='lightgreen', edgecolor='black', linewidth=2)
    ax.add_patch(preprocess_box)
    ax.text(6.25, 8.5, 'Preprocessing\n275 selected\n(150 Control + 125 MS)', 
            fontsize=9, ha='center', va='center', fontweight='bold')
    
    # Feature extraction
    feature_box = FancyBboxPatch((9, 8), 2.5, 1, boxstyle="round,pad=0.1", 
                                 facecolor='lightyellow', edgecolor='black', linewidth=2)
    ax.add_patch(feature_box)
    ax.text(10.25, 8.5, 'Feature Extraction\n22 features per image\nPupil + Texture + Stats', 
            fontsize=9, ha='center', va='center', fontweight='bold')
    
    # Train/Test split
    split_box = FancyBboxPatch((3, 6), 3, 1, boxstyle="round,pad=0.1", 
                               facecolor='lightcoral', edgecolor='black', linewidth=2)
    ax.add_patch(split_box)
    ax.text(4.5, 6.5, 'Train/Test Split\nTrain: 206 (75%)\nTest: 69 (25%)', 
            fontsize=9, ha='center', va='center', fontweight='bold')
    
    # Model training
    train_box = FancyBboxPatch((8, 6), 3, 1, boxstyle="round,pad=0.1", 
                               facecolor='lightpink', edgecolor='black', linewidth=2)
    ax.add_patch(train_box)
    ax.text(9.5, 6.5, 'Model Training\nRandom Forest\n100 trees', 
            fontsize=9, ha='center', va='center', fontweight='bold')
    
    # Model evaluation
    eval_box = FancyBboxPatch((3, 4), 3, 1, boxstyle="round,pad=0.1", 
                              facecolor='gold', edgecolor='black', linewidth=2)
    ax.add_patch(eval_box)
    ax.text(4.5, 4.5, 'Model Evaluation\nAccuracy: 79.71%\nAUC-ROC: 0.835', 
            fontsize=9, ha='center', va='center', fontweight='bold')
    
    # Results
    results_box = FancyBboxPatch((8, 4), 3, 1, boxstyle="round,pad=0.1", 
                                 facecolor='lightcyan', edgecolor='black', linewidth=2)
    ax.add_patch(results_box)
    ax.text(9.5, 4.5, 'Final Results\nMS Detection Model\nReady for Deployment', 
            fontsize=9, ha='center', va='center', fontweight='bold')
    
    # Arrows
    arrows = [
        ((3.5, 8.5), (5, 8.5)),      # Data to Preprocessing
        ((7.5, 8.5), (9, 8.5)),      # Preprocessing to Features
        ((10.25, 8), (4.5, 7)),      # Features to Split
        ((6, 6.5), (8, 6.5)),        # Split to Training
        ((4.5, 6), (4.5, 5)),        # Split to Evaluation
        ((9.5, 6), (9.5, 5)),        # Training to Results
    ]
    
    for start, end in arrows:
        arrow = ConnectionPatch(start, end, "data", "data", 
                               arrowstyle="->", shrinkA=5, shrinkB=5, 
                               mutation_scale=20, fc="black")
        ax.add_artist(arrow)
    
    # Performance metrics
    metrics_text = """Key Metrics:
• Accuracy: 79.71%
• Precision (MS): 81.48%
• Recall (MS): 70.97%
• F1-Score: 79.18%
• AUC-ROC: 0.835
• Target: 70%+ ✓"""
    
    ax.text(0.5, 2.5, metrics_text, fontsize=9, va='top', 
            bbox=dict(boxstyle="round,pad=0.3", facecolor='lightyellow', edgecolor='gray'))
    
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'data_flow_diagram.png'), dpi=300, bbox_inches='tight')
    plt.close()

def create_prediction_pipeline():
    """Create prediction pipeline for new images"""
    print("🔮 Creating Prediction Pipeline...")
    
    fig, ax = plt.subplots(figsize=(12, 8))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 8)
    ax.axis('off')
    
    # Title
    ax.text(6, 7.5, 'Prediction Pipeline for New OCT Images', fontsize=16, fontweight='bold', ha='center')
    
    # New image input
    new_img_box = FancyBboxPatch((1, 6), 2, 1, boxstyle="round,pad=0.1", 
                                 facecolor='lightblue', edgecolor='black', linewidth=2)
    ax.add_patch(new_img_box)
    ax.text(2, 6.5, 'New OCT\nImage', fontsize=10, ha='center', va='center', fontweight='bold')
    
    # Preprocessing
    preprocess_box = FancyBboxPatch((4.5, 6), 2, 1, boxstyle="round,pad=0.1", 
                                    facecolor='lightgreen', edgecolor='black', linewidth=2)
    ax.add_patch(preprocess_box)
    ax.text(5.5, 6.5, 'Resize to\n400x200', fontsize=10, ha='center', va='center', fontweight='bold')
    
    # Feature extraction
    feature_box = FancyBboxPatch((8, 6), 2, 1, boxstyle="round,pad=0.1", 
                                 facecolor='lightyellow', edgecolor='black', linewidth=2)
    ax.add_patch(feature_box)
    ax.text(9, 6.5, 'Extract 22\nFeatures', fontsize=10, ha='center', va='center', fontweight='bold')
    
    # Scaling
    scale_box = FancyBboxPatch((4.5, 4), 2, 1, boxstyle="round,pad=0.1", 
                               facecolor='lightcoral', edgecolor='black', linewidth=2)
    ax.add_patch(scale_box)
    ax.text(5.5, 4.5, 'StandardScaler\nNormalization', fontsize=10, ha='center', va='center', fontweight='bold')
    
    # Model prediction
    model_box = FancyBboxPatch((8, 4), 2, 1, boxstyle="round,pad=0.1", 
                               facecolor='lightpink', edgecolor='black', linewidth=2)
    ax.add_patch(model_box)
    ax.text(9, 4.5, 'Random Forest\nPrediction', fontsize=10, ha='center', va='center', fontweight='bold')
    
    # Final result
    result_box = FancyBboxPatch((4.5, 2), 3, 1, boxstyle="round,pad=0.1", 
                                facecolor='gold', edgecolor='black', linewidth=2)
    ax.add_patch(result_box)
    ax.text(6, 2.5, 'Prediction Result\nControl / MS + Probability', fontsize=10, ha='center', va='center', fontweight='bold')
    
    # Arrows
    arrows = [
        ((3, 6.5), (4.5, 6.5)),      # Input to Preprocess
        ((6.5, 6.5), (8, 6.5)),      # Preprocess to Features
        ((9, 6), (5.5, 5)),          # Features to Scale
        ((6.5, 4.5), (8, 4.5)),      # Scale to Model
        ((9, 4), (6, 3)),            # Model to Result
    ]
    
    for start, end in arrows:
        arrow = ConnectionPatch(start, end, "data", "data", 
                               arrowstyle="->", shrinkA=5, shrinkB=5, 
                               mutation_scale=20, fc="black")
        ax.add_artist(arrow)
    
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'prediction_pipeline.png'), dpi=300, bbox_inches='tight')
    plt.close()

def main():
    """Create all architecture diagrams"""
    print("🏗️ Creating Model Architecture Visualizations")
    print("=" * 50)
    
    try:
        create_random_forest_architecture()
        create_feature_engineering_pipeline()
        create_data_flow_diagram()
        create_prediction_pipeline()
        
        print("\n✅ All architecture diagrams created!")
        print(f"📁 Saved to: {charts_dir}/")
        print("📊 Created diagrams:")
        print("   - random_forest_architecture.png")
        print("   - feature_engineering_pipeline.png")
        print("   - data_flow_diagram.png")
        print("   - prediction_pipeline.png")
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return False

if __name__ == "__main__":
    success = main()

