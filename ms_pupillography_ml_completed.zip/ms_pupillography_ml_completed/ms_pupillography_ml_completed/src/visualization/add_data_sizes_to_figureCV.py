#!/usr/bin/env python3
"""
Add Data Sizes to Figure 4 (Cross-Validation Results)
Addresses reviewer's request: "Same point for Figure 4"
"""

import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import os

print("📊 ADDING DATA SIZES TO FIGURE 4")
print("=" * 70)

# Load original Figure 4
original_fig = "/home/ubuntu/analysis/figure4_original.png"
output_dir = "/home/ubuntu/analysis/figure4_final"
os.makedirs(output_dir, exist_ok=True)

# Read the image
img = mpimg.imread(original_fig)

# Create figure
fig, ax = plt.subplots(figsize=(14, 6))
ax.imshow(img)
ax.axis('off')

# Add data sizes annotation at the bottom
# Cross-validation uses the training set: 384 images (98 MS + 286 Control)
# 5-fold CV means each fold has ~307 training, ~77 validation
data_sizes_text = ('Data sizes: 5-fold cross-validation on training set | '
                  'Training set: 384 images (98 MS + 286 Control) | '
                  'Each fold: ~307 training, ~77 validation')

fig.text(0.5, 0.02, data_sizes_text, ha='center', fontsize=11, 
         bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.5, 
                  edgecolor='navy', linewidth=1.5))

plt.tight_layout(rect=[0, 0.04, 1, 1])

# Save
output_file = os.path.join(output_dir, 'Figure4_CrossValidation_with_DataSizes.png')
plt.savefig(output_file, dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
plt.close()

print(f"✅ Figure 4 with data sizes saved: {output_file}")

# Save information file
info_file = os.path.join(output_dir, 'figure4_information.txt')
with open(info_file, 'w') as f:
    f.write("FIGURE 4: CROSS-VALIDATION RESULTS WITH DATA SIZES\n")
    f.write("=" * 70 + "\n\n")
    f.write("Graph Type: Cross-Validation Performance Analysis\n")
    f.write("Left Panel: Box plots of performance metrics\n")
    f.write("Right Panel: Fold-by-fold performance breakdown\n\n")
    f.write("Performance Metrics (5-Fold CV):\n")
    f.write("-" * 70 + "\n")
    f.write("Accuracy: 0.567 ± 0.066\n")
    f.write("Precision: 0.534 ± 0.087\n")
    f.write("Recall: 0.432 ± 0.064\n")
    f.write("F1-Score: 0.477 ± 0.070\n")
    f.write("ROC-AUC: 0.560 ± 0.075\n\n")
    f.write("Data Sizes (Added per Reviewer Request):\n")
    f.write("-" * 70 + "\n")
    f.write("Cross-Validation Type: 5-fold stratified\n")
    f.write("Training Set: 384 images (98 MS + 286 Control)\n")
    f.write("Each Fold Training: ~307 images\n")
    f.write("Each Fold Validation: ~77 images\n")
    f.write("Total Patients in Training: 35 (9 MS + 26 Control)\n\n")
    f.write("Reviewer Response:\n")
    f.write("-" * 70 + "\n")
    f.write("Reviewer Comment: 'Same point for Figure 4'\n")
    f.write("Response: Data sizes annotation added at bottom of figure\n")
    f.write("Information Provided:\n")
    f.write("  - Cross-validation configuration (5-fold)\n")
    f.write("  - Training set size (384 images)\n")
    f.write("  - Training set composition (98 MS + 286 Control)\n")
    f.write("  - Fold-level data split (~307 train, ~77 val per fold)\n")

print(f"✅ Information file saved: {info_file}")

print("\n" + "=" * 70)
print("🎉 SUCCESS - FIGURE 4 UPDATED WITH DATA SIZES")
print("=" * 70)
print(f"📊 Figure 4: Cross-validation results with data sizes")
print(f"📁 Location: {output_dir}/")
print(f"📄 File: Figure4_CrossValidation_with_DataSizes.png")
print(f"✅ Reviewer request: ADDRESSED")
print("=" * 70)
