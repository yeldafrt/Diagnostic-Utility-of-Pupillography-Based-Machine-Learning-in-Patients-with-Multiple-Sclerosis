#!/usr/bin/env python3
"""
Create Improved ROC Curve - WITHOUT MAIN TITLE
Higher readability with larger fonts and better layout
"""

import matplotlib.pyplot as plt
import numpy as np

print("📊 CREATING IMPROVED ROC CURVE (NO TITLE)")
print("=" * 80)

# ROC curve data extracted from the original figure
# AUC = 0.945 (excellent performance)
# Approximate FPR and TPR values from the figure
fpr = np.array([0.0, 0.0, 0.04, 0.08, 0.12, 0.15, 0.15, 0.15, 1.0])
tpr = np.array([0.0, 0.38, 0.56, 0.81, 0.88, 0.94, 0.94, 1.0, 1.0])

auc_value = 0.945

# Create figure with improved size and quality
fig, ax = plt.subplots(figsize=(10, 8), dpi=300)
fig.patch.set_facecolor('white')

# Plot ROC curve with thicker line
ax.plot(fpr, tpr, color='darkorange', linewidth=3, 
        label=f'ROC Curve (AUC = {auc_value:.3f})', zorder=3)

# Plot random classifier line (diagonal)
ax.plot([0, 1], [0, 1], color='navy', linewidth=2.5, 
        linestyle='--', label='Random Classifier', zorder=2)

# Styling - NO TITLE
ax.set_xlim([0.0, 1.0])
ax.set_ylim([0.0, 1.05])
ax.set_xlabel('False Positive Rate', fontsize=16, fontweight='bold', labelpad=10)
ax.set_ylabel('True Positive Rate', fontsize=16, fontweight='bold', labelpad=10)

# Legend with larger font
ax.legend(loc="lower right", fontsize=13, framealpha=0.95, 
          edgecolor='black', fancybox=True, shadow=True)

# Grid with better visibility
ax.grid(True, alpha=0.4, linestyle='-', linewidth=0.8, zorder=1)
ax.set_axisbelow(True)

# Tick parameters
ax.tick_params(axis='both', which='major', labelsize=14, width=1.5, length=6)

# Thicker spines
for spine in ax.spines.values():
    spine.set_linewidth(1.5)

plt.tight_layout()

# Save with high quality
output_file = '/home/ubuntu/analysis/roc_curve_improved.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight', 
            facecolor='white', edgecolor='none')
plt.close()

print(f"✅ Improved ROC curve saved: {output_file}")

# Print statistics
print("\n📊 ROC Curve Statistics:")
print("=" * 80)
print(f"AUC (Area Under Curve): {auc_value:.3f}")
print(f"Performance: Excellent (AUC > 0.9)")
print(f"Interpretation:")
print(f"  - The model has {auc_value*100:.1f}% probability of correctly")
print(f"    distinguishing between MS and Control patients")
print(f"  - This is significantly better than random (AUC = 0.5)")
print(f"  - The curve is close to the top-left corner (ideal)")

print("\n" + "=" * 80)
print("🎉 SUCCESS - IMPROVED ROC CURVE CREATED (NO TITLE)")
print("=" * 80)
print("Features:")
print("  ✅ Resolution: 300 DPI")
print("  ✅ Figure size: 10x8 inches")
print("  ✅ Font sizes: 13-16pt (large)")
print("  ✅ ROC line: 3pt (thick, orange)")
print("  ✅ Random line: 2.5pt (thick, dashed)")
print("  ✅ Better grid visibility")
print("  ✅ Enhanced legend with shadow")
print("  ✅ NO main title (for figure caption)")
print("  ✅ Professional appearance")
print("=" * 80)
