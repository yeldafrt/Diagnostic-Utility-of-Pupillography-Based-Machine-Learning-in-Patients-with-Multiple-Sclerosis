#!/usr/bin/env python3
"""
Create Improved Feature Importance Figure - WITHOUT MAIN TITLE
Higher readability with larger fonts and better layout
"""

import matplotlib.pyplot as plt
import numpy as np

print("📊 CREATING IMPROVED FEATURE IMPORTANCE FIGURE (NO TITLE)")
print("=" * 80)

# Feature importance data extracted from the original figure
features = [
    'quadrant_2_mean',
    'quadrant_3_mean', 
    'quadrant_4_mean',
    'quadrant_0_mean',
    'pupil_std_intensity',
    'hist_entropy',
    'mean_intensity',
    'std_intensity',
    'pupil_radius',
    'gradient_mean',
    'pupil_x_norm',
    'laplacian_variance',
    'gradient_std',
    'hist_uniformity',
    'pupil_mean_intensity'
]

# Importance values (approximate from the figure)
importance = [
    0.105,
    0.102,
    0.095,
    0.088,
    0.082,
    0.076,
    0.072,
    0.068,
    0.062,
    0.058,
    0.052,
    0.046,
    0.042,
    0.038,
    0.035
]

# Reverse for plotting (top to bottom)
features_rev = features[::-1]
importance_rev = importance[::-1]

# Create figure with improved size and quality
fig, ax = plt.subplots(figsize=(12, 8), dpi=300)
fig.patch.set_facecolor('white')

# Create horizontal bar chart with better styling
bars = ax.barh(range(len(features_rev)), importance_rev, 
               color='skyblue', alpha=0.85, edgecolor='black', linewidth=1.2)

# Add value labels at the end of each bar
for i, (bar, val) in enumerate(zip(bars, importance_rev)):
    ax.text(val + 0.002, i, f'{val:.3f}', 
            va='center', ha='left', fontsize=11, fontweight='bold')

# Styling - NO TITLE
ax.set_yticks(range(len(features_rev)))
ax.set_yticklabels(features_rev, fontsize=13, fontweight='normal')
ax.set_xlabel('Feature Importance', fontsize=15, fontweight='bold')
ax.set_xlim(0, max(importance_rev) * 1.15)

# Grid
ax.grid(True, alpha=0.3, axis='x', linestyle='--', linewidth=0.8)
ax.set_axisbelow(True)

# Remove top and right spines
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['left'].set_linewidth(1.5)
ax.spines['bottom'].set_linewidth(1.5)

# Tick parameters
ax.tick_params(axis='both', which='major', labelsize=12, width=1.5, length=6)

plt.tight_layout()

# Save with high quality
output_file = '/home/ubuntu/analysis/feature_importance_no_title.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight', 
            facecolor='white', edgecolor='none')
plt.close()

print(f"✅ Feature importance figure (no title) saved: {output_file}")

# Print statistics
print("\n📊 Feature Importance Statistics:")
print("=" * 80)
print(f"Total features shown: {len(features)}")
print(f"Top feature: {features[0]} ({importance[0]:.3f})")
print(f"Lowest feature: {features[-1]} ({importance[-1]:.3f})")
print(f"Mean importance: {np.mean(importance):.3f}")
print(f"Std importance: {np.std(importance):.3f}")

print("\n" + "=" * 80)
print("🎉 SUCCESS - FEATURE IMPORTANCE FIGURE CREATED (NO TITLE)")
print("=" * 80)
print("Features:")
print("  ✅ Resolution: 300 DPI")
print("  ✅ Figure size: 12x8 inches")
print("  ✅ Font sizes: 13-15pt (large)")
print("  ✅ Value labels on each bar")
print("  ✅ NO main title (for figure caption)")
print("  ✅ Clean professional layout")
print("=" * 80)
