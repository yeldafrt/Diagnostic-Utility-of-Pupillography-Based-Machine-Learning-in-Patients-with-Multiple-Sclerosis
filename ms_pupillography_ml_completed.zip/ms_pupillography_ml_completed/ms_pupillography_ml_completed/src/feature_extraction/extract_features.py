"""
Feature Extraction Module for MS Pupillography ML
Extracts 22 quantitative features from OCT pupillography images
"""

import cv2
import numpy as np


def extract_features(image_path):
    """
    Extract 22 features from OCT pupillography image
    
    Args:
        image_path: Path to the image file
        
    Returns:
        list: 22 feature values in the following order:
            1-5: Basic statistics (mean, std, min, max, range)
            6-11: Pupil analysis (detected, radius, x, y, mean, std)
            12-15: Texture analysis (gradient_mean, gradient_std, laplacian_var, laplacian_mean)
            16-18: Histogram features (entropy, uniformity, peak)
            19-22: Regional analysis (quadrant means)
    """
    try:
        # Load and preprocess image
        img = cv2.imread(image_path)
        if img is None:
            return None
        
        img_resized = cv2.resize(img, (400, 200))
        gray = cv2.cvtColor(img_resized, cv2.COLOR_BGR2GRAY)
        
        features = []
        
        # 1. Basic statistics (5 features)
        features.extend([
            np.mean(gray),                    # mean_intensity
            np.std(gray),                     # std_intensity
            np.min(gray),                     # min_intensity
            np.max(gray),                     # max_intensity
            np.max(gray) - np.min(gray)       # intensity_range
        ])
        
        # 2. Pupil analysis (6 features)
        circles = cv2.HoughCircles(
            gray, cv2.HOUGH_GRADIENT, 1, 20,
            param1=50, param2=30, minRadius=10, maxRadius=100
        )
        
        if circles is not None:
            circles = np.round(circles[0, :]).astype("int")
            x, y, r = circles[0]
            
            # Extract pupil region
            y_min, y_max = max(0, y-r), min(gray.shape[0], y+r)
            x_min, x_max = max(0, x-r), min(gray.shape[1], x+r)
            pupil_region = gray[y_min:y_max, x_min:x_max]
            
            features.extend([
                1,                              # pupil_detected
                r / max(gray.shape),            # pupil_radius (normalized)
                x / gray.shape[1],              # pupil_x_norm
                y / gray.shape[0],              # pupil_y_norm
                np.mean(pupil_region),          # pupil_mean_intensity
                np.std(pupil_region)            # pupil_std_intensity
            ])
        else:
            # Default values when pupil not detected
            features.extend([0, 0, 0.5, 0.5, np.mean(gray), np.std(gray)])
        
        # 3. Texture analysis (4 features)
        sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        gradient_mag = np.sqrt(sobelx**2 + sobely**2)
        
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        
        features.extend([
            np.mean(gradient_mag),            # gradient_mean
            np.std(gradient_mag),             # gradient_std
            np.var(laplacian),                # laplacian_var
            np.mean(np.abs(laplacian))        # laplacian_mean
        ])
        
        # 4. Histogram features (3 features)
        hist = cv2.calcHist([gray], [0], None, [64], [0, 256])
        hist_norm = hist.flatten() / (hist.sum() + 1e-8)
        
        features.extend([
            -np.sum(hist_norm * np.log(hist_norm + 1e-8)),  # hist_entropy
            np.sum(hist_norm ** 2),                          # hist_uniformity
            np.argmax(hist_norm)                             # hist_peak
        ])
        
        # 5. Regional analysis - quadrant means (4 features)
        h, w = gray.shape
        quadrants = [
            gray[:h//2, :w//2],      # quadrant_0_mean (top-left)
            gray[:h//2, w//2:],      # quadrant_1_mean (top-right)
            gray[h//2:, :w//2],      # quadrant_2_mean (bottom-left)
            gray[h//2:, w//2:]       # quadrant_3_mean (bottom-right)
        ]
        
        for quad in quadrants:
            features.append(np.mean(quad))
        
        return features
        
    except Exception as e:
        print(f"Error processing {image_path}: {e}")
        return None


def batch_extract_features(image_paths, verbose=True):
    """
    Extract features from multiple images
    
    Args:
        image_paths: List of image file paths
        verbose: Print progress
        
    Returns:
        numpy.ndarray: Array of shape (n_images, 22) with extracted features
    """
    features_list = []
    
    for i, img_path in enumerate(image_paths):
        if verbose and (i + 1) % 50 == 0:
            print(f"Processed {i + 1}/{len(image_paths)} images...")
        
        features = extract_features(img_path)
        if features is not None:
            features_list.append(features)
    
    if verbose:
        print(f"Successfully extracted features from {len(features_list)}/{len(image_paths)} images")
    
    return np.array(features_list)


def get_feature_names():
    """
    Get the names of all 22 features
    
    Returns:
        list: Feature names in order
    """
    return [
        # Basic statistics (5)
        'mean_intensity', 'std_intensity', 'min_intensity', 'max_intensity', 'intensity_range',
        # Pupil analysis (6)
        'pupil_detected', 'pupil_radius', 'pupil_x_norm', 'pupil_y_norm', 
        'pupil_mean_intensity', 'pupil_std_intensity',
        # Texture analysis (4)
        'gradient_mean', 'gradient_std', 'laplacian_var', 'laplacian_mean',
        # Histogram features (3)
        'hist_entropy', 'hist_uniformity', 'hist_peak',
        # Regional analysis (4)
        'quadrant_0_mean', 'quadrant_1_mean', 'quadrant_2_mean', 'quadrant_3_mean'
    ]


if __name__ == "__main__":
    # Example usage
    import sys
    
    if len(sys.argv) > 1:
        img_path = sys.argv[1]
        features = extract_features(img_path)
        
        if features is not None:
            feature_names = get_feature_names()
            print("\nExtracted Features:")
            print("-" * 50)
            for name, value in zip(feature_names, features):
                print(f"{name:25s}: {value:.4f}")
        else:
            print(f"Failed to extract features from {img_path}")
    else:
        print("Usage: python extract_features.py <image_path>")
