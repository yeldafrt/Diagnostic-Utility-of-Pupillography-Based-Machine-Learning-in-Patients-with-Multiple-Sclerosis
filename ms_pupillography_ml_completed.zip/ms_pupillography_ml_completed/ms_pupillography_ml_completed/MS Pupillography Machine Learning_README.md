# MS Pupillography Machine Learning

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)


A comprehensive machine learning system for **Multiple Sclerosis (MS) detection** using OCT pupillography images. This repository contains the complete implementation of a Random Forest classifier achieving **85.7% accuracy** with **93.8% sensitivity** on patient-based evaluation, validated on an independent cohort of 32 patients with **88.9% sensitivity maintained**, plus a **clinical testing package** for real-world validation.

## 📄 Publication

This code accompanies our manuscript:

> **"Diagnostic Utility of Pupillography-Based Machine Learning in Patients with Multiple Sclerosis"**

All results, figures, and models from the manuscript are fully reproducible using this repository.

## 🌟 Highlights

- 🎯 **High Performance**: 85.7% accuracy, 93.8% sensitivity, 80.8% specificity
- ✅ **Independent Validation**: 88.9% sensitivity maintained on external cohort (32 patients)
- 🔬 **Patient-Based Evaluation**: Rigorous stratification - no patient overlap between training and test sets
- 📊 **22 Quantitative Features**: Comprehensive feature extraction from pupillography images
- 🌲 **Random Forest Classifier**: 100 decision trees with optimized hyperparameters
- 🏥 **Clinical Testing Package**: Ready-to-use tools for real-world validation
- 📈 **Publication-Quality Figures**: All visualizations at 300 DPI
- 🔄 **Fully Reproducible**: Complete source code, trained models, and analysis scripts
- 🚀 **Production Ready**: Clean, modular code with comprehensive documentation

## 📊 Performance Metrics

### Training Set Performance

| Metric | Value |
|--------|-------|
| **Accuracy** | 85.7% |
| **Sensitivity (Recall)** | 93.8% |
| **Specificity** | 80.8% |
| **Precision** | 75.0% |
| **F1-Score** | 83.3% |
| **AUC-ROC** | 0.945 |
| **AUC-PR** | 0.920 |

*Evaluated on 28 patients (16 MS, 12 Control) using patient-based stratified evaluation with 308 test images*

### Independent Validation Performance

| Metric | Value |
|--------|-------|
| **Accuracy** | 75.0% |
| **Sensitivity (Recall)** | 88.9% |
| **Specificity** | 57.1% |
| **AUC-ROC** | 0.627 |
| **MS Detected** | 16 of 18 (88.9%) |
| **False Positives** | 6 of 14 controls |

*Evaluated on 32 independent patients (18 MS, 14 Control) with 384 validation images*

**Key Finding**: High sensitivity (88.9%) was maintained on independent validation cohort, demonstrating the model's ability to generalize to unseen patients and minimize missed MS diagnoses.

## 📚 Dataset Information

**Note**: Patient data is not included in this repository due to privacy regulations. The repository contains the complete code, trained models, and methodology to work with your own OCT pupillography images.

### Dataset Specifications (from manuscript)

- **Total Images**: 692 pupillographic images
- **Participants**: 63 total (25 RRMS patients without ON, 38 healthy controls)
- **Training Set**: 384 images from 35 patients (9 MS, 26 controls)
- **Test Set**: 308 images from 28 patients (16 MS, 12 controls)
- **Validation Set**: 384 images from 32 patients (18 MS, 14 controls)
- **Image Resolution**: 923 × 1906 pixels (original), resized to 400 × 200 pixels
- **Format**: JPEG, grayscale conversion applied

##  Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/yeldafrt/Diagnostic-Utility-of-Pupillography-Based-Machine-Learning-in-Patients-with-Multiple-Sclerosis


# Install dependencies
pip install -r requirements.txt
```

### Basic Usage

#### 1. Extract Features from an Image

```python
from src.feature_extraction import extract_features

# Extract 22 features from a pupillography image
features = extract_features('path/to/image.jpg')
print(f"Extracted {len(features)} features: {features}")
```

#### 2. Make Predictions with Pre-trained Model

```python
import joblib
from src.feature_extraction import extract_features

# Load pre-trained model and scaler
model = joblib.load('models/ms_detection_model.pkl')
scaler = joblib.load('models/feature_scaler.pkl')

# Extract features and make prediction
features = extract_features('path/to/image.jpg')
features_scaled = scaler.transform([features])
prediction = model.predict(features_scaled)[0]
probability = model.predict_proba(features_scaled)[0]

print(f"Prediction: {'MS' if prediction == 1 else 'Control'}")
print(f"Confidence: {max(probability)*100:.1f}%")
```

#### 3. Batch Processing

```python
import pandas as pd
from src.feature_extraction import extract_features

# Process multiple images
image_paths = ['image1.jpg', 'image2.jpg', 'image3.jpg']
results = []

for img_path in image_paths:
    features = extract_features(img_path)
    features_scaled = scaler.transform([features])
    prediction = model.predict(features_scaled)[0]
    
    results.append({
        'image': img_path,
        'prediction': 'MS' if prediction == 1 else 'Control',
        'confidence': max(model.predict_proba(features_scaled)[0]) * 100
    })

df = pd.DataFrame(results)
print(df)
```

## 🏥 Clinical Testing Package

This repository includes a **comprehensive clinical testing package** designed for real-world validation of the MS detection model. Perfect for independent validation studies and clinical trials.

### Key Features

- ✅ **Single Image Testing**: Quick prediction for individual patients
- ✅ **Batch Processing**: Process hundreds of images automatically
- ✅ **Automatic Quality Control**: Built-in image quality checks
- ✅ **Comprehensive Reports**: Excel, CSV, and JSON outputs
- ✅ **Performance Metrics**: Accuracy, sensitivity, specificity, precision
- ✅ **Publication-Ready Visualizations**: Confusion matrix, ROC curve, PR curve (300 DPI)
-

### Quick Start - Clinical Testing

```bash
# Navigate to clinical test package
cd clinical_test

# Install dependencies
pip install -r requirements.txt

# Run complete analysis (single command)
python run_analysis.py data/ results/
```

### Clinical Testing Workflow

#### Step 1: Prepare Your Data

Place your pupillography images in the `clinical_test/data/` directory:

```
clinical_test/data/
├── patient001.png
├── patient002.png
├── patient003.png
└── ...
```

#### Step 2: Add True Labels (Optional)

Create `clinical_test/data/true_labels.csv` for performance evaluation:

```csv
patient_id,true_label
patient001,MS
patient002,Control
patient003,MS
```

#### Step 3: Run Analysis

```bash
# Complete analysis (recommended)
python run_analysis.py data/ results/

# Or test single image
python predict_single_image.py data/patient001.png

# Or batch process only
python predict_batch.py data/ results/ data/true_labels.csv
```

### Clinical Testing Outputs

The system generates comprehensive outputs in the `results/` directory:

#### Reports
- **Excel Report** (`report_YYYYMMDD_HHMMSS.xlsx`): Multi-sheet report with:
  - Summary statistics
  - Detailed predictions for each image
  - Performance metrics (if true labels provided)
- **CSV Report** (`predictions_YYYYMMDD_HHMMSS.csv`): Raw prediction data
- **JSON Metrics** (`metrics_YYYYMMDD_HHMMSS.json`): Performance metrics in JSON format

#### Visualizations (300 DPI)
- **Confusion Matrix**: Classification performance visualization
- **ROC Curve**: With AUC value
- **Precision-Recall Curve**: With AUC value
- **Confidence Distribution**: Prediction confidence analysis


### Clinical Testing Documentation

The clinical test package includes comprehensive documentation:

- **`README.md`**: Overview and basic usage
- **`QUICKSTART.md`**: 3-step quick start guide
- **`USER_GUIDE.md`**: Detailed user manual (10+ pages) with:
  - Installation instructions
  - Data preparation guidelines
  - Usage scenarios
  - Output file descriptions
  - Performance metrics explanation
  - Troubleshooting guide
  - FAQ (15+ questions)

## 📁 Repository Structure

```
ms_pupillography_ml/
├── src/                          # Source code
│   ├── preprocessing/            # Image preprocessing
│   │   └── preprocess.py        # Resize, normalize, quality check
│   ├── feature_extraction/      # Feature extraction
│   │   └── extract_features.py  # Extract 22 features
│   ├── model_training/          # Model training utilities
│   ├── evaluation/              # Evaluation metrics
│   ├── visualization/           # Figure generation (11 scripts)
│   ├── patient_based_analysis.py    # Main analysis (manuscript)
│   ├── comprehensive_analysis.py    # Full analysis pipeline
│   └── apply_saved_model.py         # Apply model to new data
├── models/                      # Trained models
│   ├── ms_detection_model.pkl   # Random Forest classifier
│   └── feature_scaler.pkl       # StandardScaler
├── figures/                     # Publication figures (300 DPI)
│   ├── 1.png                   # Confusion matrix
│   ├── 2.png                   # ROC curve
│   ├── 3.png                   # Learning curve
│   ├── 4.png                   # Cross-validation results
│   ├── 5.png                   # Feature importance
│   ├── 13.png                  # Validation results
│   └── ...                     # Additional figures (13 total)
├── clinical_test/               # 🏥 Clinical Testing Package
│   ├── predict_single_image.py  # Single image prediction
│   ├── predict_batch.py         # Batch processing
│   ├── visualize_results.py     # Generate visualizations
│   ├── run_analysis.py          # Complete analysis pipeline
│   ├── requirements.txt         # Dependencies
│   ├── README.md                # Clinical testing guide
│   ├── QUICKSTART.md            # Quick start guide
│   ├── USER_GUIDE.md            # Detailed user manual
│   └── results/                 # Output directory
├── notebooks/                   # Example notebooks
├── tests/                       # Unit tests
├── README.md                    # This file
├── requirements.txt             # Python dependencies
├── setup.py                     # Package setup


## 🔬 Methodology

### Feature Extraction (22 Features)

Our system extracts 22 quantitative features from OCT pupillography images, organized into 5 main groups:

1. **Basic Statistical Features (5 features)**
   - Mean intensity
   - Standard deviation
   - Minimum intensity
   - Maximum intensity
   - Intensity range

2. **Pupil Morphology and Positional Features (6 features)**
   - Pupil detection status (binary)
   - Pupil radius
   - Normalized X-Y coordinates
   - Mean intensity of pupil region
   - Standard deviation of pupil region

3. **Texture Analysis Features (4 features)**
   - Gradient mean (Sobel operator)
   - Gradient standard deviation
   - Laplacian variance (image sharpness)
   - Laplacian mean

4. **Histogram-Based Features (3 features)**
   - Shannon entropy
   - Uniformity index
   - Histogram peak value

5. **Regional Analysis Features (4 features)**
   - Mean pixel intensity per quadrant (4 quadrants)
   - Characterizes spatial distribution of pupillary response

### Model Architecture

- **Algorithm**: Random Forest Classifier
- **Number of Trees**: 100
- **Max Depth**: 10 levels
- **Min Samples Split**: 5
- **Min Samples Leaf**: 3
- **Feature Normalization**: StandardScaler (z-score normalization to [0, 1] range)

### Evaluation Strategy

- **Patient-Based Stratification**: All images from a patient are assigned exclusively to either training or test set
- **Training Set**: 384 images from 35 patients (9 MS, 26 controls)
- **Test Set**: 308 images from 28 patients (16 MS, 12 controls)
- **Cross-Validation**: 5-fold stratified cross-validation on training set (mean accuracy: 56.7%)
- **Metrics**: Accuracy, Sensitivity, Specificity, Precision, F1-Score, AUC-ROC, AUC-PR

### Key Clinical Finding

**15 out of 16 MS patients correctly identified** in the test set, demonstrating the model's ability to minimize missed diagnoses - a critical requirement for clinical screening applications.

## 📦 Pre-trained Models

The repository includes two pre-trained models:

1. **`ms_detection_model.pkl`** (394 KB)
   - Random Forest classifier with 100 trees
   - Trained on 384 images from 35 patients (9 MS, 26 controls)
   - Achieves 85.7% accuracy on independent test set

2. **`feature_scaler.pkl`** (978 bytes)
   - StandardScaler for feature normalization
   - Fitted on training data

## 🖼️ Publication Figures

All figures from the manuscript are included at **300 DPI** resolution:

- **Figure 1**: Participant Workflow and Data Partitioning Strategy
- **Figure 2**: Pupillography Images from MS Patients and Healthy Controls
- **Figure 3**: Random Forest Model Architecture
- **Figure 4**: Training and Validation Learning Curves
- **Figure 5**: Cross-Validation Results
- **Figure 6**: Confusion Matrix (Training Set)
- **Figure 7**: ROC Curve (Training Set, AUC = 0.945)
- **Figure 8**: Precision-Recall Curve (Training Set, AUC = 0.920)
- **Figure 9**: Feature Importance Analysis
- **Figure 10**: Specificity-Sensitivity Analysis
- **Figure 11**: Threshold Analysis
- **Figure 12**: ICC Analysis
- **Figure 13**: Independent Validation Results (Confusion Matrix, ROC Curve, Performance Comparison)

## 🔧 Dependencies

### Core Requirements

- Python >= 3.8
- numpy >= 1.21.0
- pandas >= 1.3.0
- scikit-learn >= 1.0.0
- opencv-python >= 4.5.0
- matplotlib >= 3.4.0
- seaborn >= 0.11.0
- scipy >= 1.7.0
- joblib >= 1.1.0

### Clinical Testing Package Requirements

- openpyxl >= 3.0.0 (for Excel reports)
- All core requirements above

See `requirements.txt` for complete list.

## 📚 Documentation

### API Documentation

All functions are documented with comprehensive docstrings:

```python
from src.feature_extraction import extract_features
help(extract_features)
```

### Example Notebooks

Check the `notebooks/` directory for detailed tutorials:

- `01_quick_start_example.md` - Quick start guide
- More examples coming soon!

### Clinical Testing Documentation

See `clinical_test/` directory for comprehensive clinical testing guides:
- `README.md` - Overview
- `QUICKSTART.md` - 3-step guide
- `USER_GUIDE.md` - Complete manual

## 🧪 Testing

Run unit tests to verify installation:

```bash
# Run all tests
python -m pytest tests/

# Run specific test
python -m pytest tests/test_feature_extraction.py
```

## 🎯 Use Cases

### 1. Research & Development
- Train new models with your own data
- Experiment with different features
- Compare with other algorithms

### 2. Clinical Validation
- Validate model on independent datasets
- Generate performance reports
- Create publication-ready figures

### 3. Real-World Deployment
- Integrate into clinical workflows
- Process patient images in real-time
- Generate clinical reports

### 4. Educational Purposes
- Learn medical image analysis
- Understand ML in healthcare
- Study feature engineering

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

### How to Contribute

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📊 Reproducing Manuscript Results

To reproduce all results from the manuscript:

```bash
# Run complete analysis
python src/patient_based_analysis.py

# Generate all figures
python src/visualization/create_confusion_matrix_improved.py
python src/visualization/create_roc_curve_improved.py
# ... (see src/visualization/ for all scripts)
```

## 🔐 Data Privacy

**Note**: This repository does not include patient data due to privacy regulations. The code is designed to work with your own OCT pupillography images.

### Expected Data Format

For using this code with your own data:

- **Format**: JPG, PNG, BMP, or TIFF
- **Original Resolution**: 923 × 1906 pixels (as used in manuscript)
- **Processing Resolution**: 400 × 200 pixels (automatic resizing)
- **Color**: Grayscale or RGB (will be converted to grayscale)
- **Normalization**: [0, 1] range

## 🎓 Citation

If you use this code in your research, please cite our paper:

```bibtex
@article{parmak_yener_2025,
  title={Diagnostic Utility of Pupillography-Based Machine Learning in Patients with Multiple Sclerosis},
  author={Parmak Yener, Neslihan and Fırat, Yelda and Seferoğlu, Meral and Kargın, Ahmet Metin and Kılıçaslan, Yılmaz},
  journal={Journal Name},
  year={2025},
  note={Under review}
}
```

## 👥 Authors

- **Neslihan Parmak Yener, MD** - *Principal Investigator* - Department of Ophthalmology, University of Health Sciences, Bursa Yuksek Ihtisas Training and Research Hospital
- **Yelda Fırat** - *Machine Learning Development* - Mudanya University Faculty of engineering, Department of Computer Engineering
- **Meral Seferoğlu** - *Clinical Data Collection* - Department of Ophthalmology
- **Ahmet Metin Kargın** - *Clinical Validation* - Department of Ophthalmology
- **Yılmaz Kılıçaslan** - *Technical Supervision* - Mudanya University Faculty of engineering, Department of Computer Engineering

## 📧 Contact

For questions, suggestions, or collaborations:

- **Corresponding Author**: Neslihan Parmak Yener, MD
- **Email**: drnparmak@yahoo.com, parmakyener@gmail.com
- **GitHub Issues**: [Create an issue](https://github.com/yeldafrt/Diagnostic-Utility-of-Pupillography-Based-Machine-Learning-in-Patients-with-Multiple-Sclerosis)
- **Institution**: University of Health Sciences, Bursa Yuksek Ihtisas Training and Research Hospital, Bursa, Turkey

## 🙏 Acknowledgments

- Thanks to all patients who participated in this study
- Department of Neurology and Ophthalmology, University of Health Sciences Bursa Yüksek İhtisas Training and Research Hospital
- Ethics Committee approval: 2011-KAEK-25 2019/03–28

## 📈 Project Status

- ✅ **Manuscript**: Under review
- ✅ **Code**: Complete and tested
- ✅ **Models**: Trained and validated
- ✅ **Clinical Testing Package**: Ready for real-world validation
- ✅ **Documentation**: Comprehensive
- 🔄 **Future Work**: Large-scale clinical validation with multicenter studies

## 🔗 Related Projects

- [OCT Analysis Tools](https://github.com/yeldafrt/Diagnostic-Utility-of-Pupillography-Based-Machine-Learning-in-Patients-with-Multiple-Sclerosis)
- 

## 📝 Changelog

### Version 1.0.0 (2025-10-08)
- Initial release
- Complete source code
- Pre-trained models (85.7% accuracy, 93.8% sensitivity)
- Independent validation results (88.9% sensitivity on 32 patients)
- Publication figures (13 figures at 300 DPI)
- Comprehensive documentation
- Clinical testing package

---

