# MS Pupillography Clinical Test - Quick Start Guide

Bu kılavuz, MS pupillografi klinik test paketini hızlıca kullanmaya başlamanız için hazırlanmıştır.

## 🚀 Hızlı Başlangıç (3 Adım)

### 1. Kurulum

```bash
# Gerekli kütüphaneleri yükleyin
pip install -r requirements.txt
```

### 2. Verilerinizi Hazırlayın

**Görüntüler**: Pupillografi görüntülerinizi `data/` klasörüne kopyalayın.

**Gerçek Etiketler (Opsiyonel)**: Performans metriklerini hesaplamak için `data/true_labels.csv` dosyası oluşturun:

```csv
patient_id,true_label
hasta001,MS
hasta002,Control
hasta003,MS
```

> **Not**: `patient_id` görüntü dosya adı ile (uzantı olmadan) eşleşmelidir.

### 3. Analizi Çalıştırın

```bash
# Tüm analizi tek komutla çalıştırın
python run_analysis.py data/ results/
```

Bu komut:
- ✅ Tüm görüntüleri işler
- ✅ MS/Control tahminleri yapar
- ✅ Excel raporu oluşturur
- ✅ Performans metrikleri hesaplar (eğer gerçek etiketler varsa)
- ✅ Yayın kalitesinde grafikler üretir (300 DPI)

## 📊 Çıktılar

Tüm sonuçlar `results/` klasöründe oluşturulur:

### Ana Raporlar
- **`report_YYYYMMDD_HHMMSS.xlsx`**: Detaylı Excel raporu (çoklu sayfa)
  - Özet sayfa
  - Detaylı tahminler
  - Performans metrikleri (eğer gerçek etiketler varsa)

- **`predictions_YYYYMMDD_HHMMSS.csv`**: Ham tahmin verileri

- **`metrics_YYYYMMDD_HHMMSS.json`**: Performans metrikleri (JSON formatında)

### Grafikler (`results/figures/`)
- **`confusion_matrix_clinical.png`**: Karmaşıklık matrisi
- **`roc_curve_clinical.png`**: ROC eğrisi
- **`pr_curve_clinical.png`**: Precision-Recall eğrisi
- **`confidence_distribution.png`**: Güven dağılımı
- **`clinical_test_table.txt`**: Makale için hazır tablo (LaTeX formatında)

## 🔧 Alternatif Kullanım

### Tek Görüntü Testi

```bash
python predict_single_image.py data/hasta001.png
```

### Sadece Toplu Tahmin (Görselleştirme Olmadan)

```bash
python predict_batch.py data/ results/
```

### Sadece Görselleştirme (Daha Önce Oluşturulmuş Tahminler İçin)

```bash
python visualize_results.py results/predictions_20251008_120000.csv
```

## 📝 Önemli Notlar

1. **Model Dosyaları**: Model dosyaları (`ms_detection_model.pkl` ve `feature_scaler.pkl`) `../ms_pupillography_ml/models/` dizininde olmalıdır.

2. **Görüntü Formatları**: Desteklenen formatlar: `.jpg`, `.jpeg`, `.png`, `.bmp`, `.tif`, `.tiff`

3. **Kalite Kontrolü**: Sistem otomatik olarak görüntü kalitesini kontrol eder ve düşük kaliteli görüntüleri işaretler.

4. **Güven Skorları**: Her tahmin için bir güven skoru (0-100%) hesaplanır.

## 🆘 Sorun Giderme

### Model yüklenemiyor
- Model dosyalarının doğru dizinde olduğundan emin olun
- Yol: `../ms_pupillography_ml/models/`

### Görüntü bulunamadı
- Görüntülerin `data/` klasöründe olduğundan emin olun
- Desteklenen formatlarda olduğunu kontrol edin

### Excel dosyası oluşturulamıyor
- `openpyxl` kütüphanesinin yüklü olduğundan emin olun: `pip install openpyxl`

## 📧 Destek

Sorunlarınız için lütfen detaylı hata mesajlarını ve kullandığınız komutları paylaşın.
