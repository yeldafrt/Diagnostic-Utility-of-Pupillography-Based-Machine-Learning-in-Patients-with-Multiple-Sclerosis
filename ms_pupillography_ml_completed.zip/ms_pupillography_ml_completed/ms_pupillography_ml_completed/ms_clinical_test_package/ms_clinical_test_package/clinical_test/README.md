# MS Pupillography Clinical Test Package

This package provides a complete clinical testing environment for the Multiple Sclerosis (MS) detection model based on pupillography images. It allows for single image prediction, batch processing, and the generation of comprehensive reports and visualizations.

## 1. Installation

Before running the scripts, you need to install the required Python libraries. It is recommended to use a virtual environment.

```bash
# Create and activate a virtual environment (optional but recommended)
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

## 2. Package Contents

- `predict_single_image.py`: Script to predict MS from a single pupillography image.
- `predict_batch.py`: Script to process a batch of images, generate predictions, and calculate performance metrics.
- `visualize_results.py`: Script to generate publication-quality visualizations from the batch prediction results.
- `run_analysis.py`: A wrapper script that runs the complete analysis pipeline (batch prediction + visualization).
- `requirements.txt`: A list of required Python packages.
- `models/`: This directory should contain the trained model (`ms_detection_model.pkl`) and the feature scaler (`feature_scaler.pkl`).
- `data/`: This directory is for your input images.
- `results/`: This directory will be created to store the output files (CSV, Excel, figures).

## 3. Data Preparation

1.  **Image Data**: Place your pupillography images (e.g., in `.png`, `.jpg` format) into the `data/` directory. The filename of each image (without the extension) will be used as the `patient_id`.

2.  **True Labels (Optional)**: If you have the true diagnostic labels for your images, create a CSV file named `true_labels.csv` in the `data/` directory. This file is required for calculating performance metrics (accuracy, sensitivity, etc.). The format should be:

    ```csv
    patient_id,true_label
    patient001,MS
    patient002,Control
    patient003,MS
    ...
    ```

    - `patient_id`: Must match the image filename (without extension).
    - `true_label`: Must be either `MS` or `Control`.

## 4. How to Run

### 4.1. Complete Analysis (Recommended)

To run the entire pipeline (batch prediction and visualization), use the `run_analysis.py` script. This is the easiest way to get all results.

```bash
python run_analysis.py data/ results/
```

This will:
1.  Process all images in the `data/` directory.
2.  Generate a `predictions_YYYYMMDD_HHMMSS.csv` and `predictions_YYYYMMDD_HHMMSS.xlsx` file in the `results/` directory.
3.  If `true_labels.csv` is present, it will calculate performance metrics and save them to `metrics_YYYYMMDD_HHMMSS.json`.
4.  Generate all visualizations (confusion matrix, ROC curve, etc.) in the `results/figures/` directory.

### 4.2. Single Image Prediction

To test a single image:

```bash
python predict_single_image.py /path/to/your/image.png
```

### 4.3. Batch Prediction Only

To run only the batch prediction and generate the CSV/Excel report:

```bash
# Without true labels
python predict_batch.py data/ results/

# With true labels for performance analysis
python predict_batch.py data/ results/ data/true_labels.csv
```

### 4.4. Visualization Only

If you have already run a batch prediction and have a `predictions_..._csv` file, you can generate the visualizations separately:

```bash
python visualize_results.py results/predictions_YYYYMMDD_HHMMSS.csv
```

## 5. Outputs

All output files are saved in the `results/` directory.

- **`predictions_YYYYMMDD_HHMMSS.csv`**: Detailed prediction results for each image in CSV format.
- **`predictions_YYYYMMDD_HHMMSS.xlsx`**: A more detailed and formatted Excel report with multiple sheets:
    - `Summary`: An overview of the results.
    - `Detailed Predictions`: The full prediction data for each image.
    - `Performance Metrics`: If true labels were provided, this sheet contains accuracy, sensitivity, specificity, etc.
- **`metrics_YYYYMMDD_HHMMSS.json`**: Performance metrics in JSON format.
- **`results/figures/`**: This sub-directory contains all the generated plots:
    - `confusion_matrix_clinical.png`
    - `roc_curve_clinical.png`
    - `pr_curve_clinical.png`
    - `confidence_distribution.png`
- **`clinical_test_table.txt`**: A formatted table of the results, ready to be included in a manuscript.

