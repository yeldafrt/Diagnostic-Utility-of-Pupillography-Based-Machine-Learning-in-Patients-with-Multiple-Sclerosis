"""
Clinical Test Results Visualization
Generate publication-quality figures for manuscript
"""

import sys
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import roc_curve, auc, precision_recall_curve, confusion_matrix
import json


def create_confusion_matrix(results_df, output_path='confusion_matrix_clinical.png'):
    """Create confusion matrix visualization"""
    
    # Filter valid predictions with true labels
    valid = results_df[results_df['true_label'].notna() & 
                      results_df['prediction'].isin(['MS', 'Control'])]
    
    if len(valid) == 0:
        print("⚠️  No valid predictions with true labels for confusion matrix")
        return
    
    # Create confusion matrix
    y_true = (valid['true_label'] == 'MS').astype(int)
    y_pred = (valid['prediction'] == 'MS').astype(int)
    
    cm = confusion_matrix(y_true, y_pred)
    
    # Plot
    fig, ax = plt.subplots(figsize=(9, 7), dpi=300)
    
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                square=True, linewidths=2, linecolor='black',
                cbar_kws={'label': 'Count'},
                annot_kws={'size': 18, 'weight': 'bold', 'color': 'white'},
                ax=ax)
    
    ax.set_xlabel('Predicted Label (Patient)', fontsize=15, fontweight='bold')
    ax.set_ylabel('True Label (Patient)', fontsize=15, fontweight='bold')
    ax.set_xticklabels(['Control', 'MS'], fontsize=14)
    ax.set_yticklabels(['Control', 'MS'], fontsize=14, rotation=0)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    
    print(f"✅ Confusion matrix saved to: {output_path}")


def create_roc_curve(results_df, output_path='roc_curve_clinical.png'):
    """Create ROC curve visualization"""
    
    # Filter valid predictions with true labels
    valid = results_df[results_df['true_label'].notna() & 
                      results_df['prediction'].isin(['MS', 'Control'])]
    
    if len(valid) == 0:
        print("⚠️  No valid predictions with true labels for ROC curve")
        return
    
    # Prepare data
    y_true = (valid['true_label'] == 'MS').astype(int)
    y_score = valid['prob_ms']
    
    # Calculate ROC curve
    fpr, tpr, thresholds = roc_curve(y_true, y_score)
    roc_auc = auc(fpr, tpr)
    
    # Plot
    fig, ax = plt.subplots(figsize=(10, 8), dpi=300)
    
    ax.plot(fpr, tpr, color='darkorange', lw=3, 
            label=f'ROC Curve (AUC = {roc_auc:.3f})')
    ax.plot([0, 1], [0, 1], color='navy', lw=2.5, linestyle='--', 
            label='Random Classifier')
    
    ax.set_xlim([0.0, 1.0])
    ax.set_ylim([0.0, 1.05])
    ax.set_xlabel('False Positive Rate', fontsize=16, fontweight='bold')
    ax.set_ylabel('True Positive Rate', fontsize=16, fontweight='bold')
    ax.tick_params(labelsize=14)
    ax.legend(loc="lower right", fontsize=13, frameon=True, shadow=True)
    ax.grid(True, alpha=0.4, linestyle='--', linewidth=0.8)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)
    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    
    print(f"✅ ROC curve saved to: {output_path}")
    print(f"   AUC = {roc_auc:.3f}")


def create_pr_curve(results_df, output_path='pr_curve_clinical.png'):
    """Create Precision-Recall curve visualization"""
    
    # Filter valid predictions with true labels
    valid = results_df[results_df['true_label'].notna() & 
                      results_df['prediction'].isin(['MS', 'Control'])]
    
    if len(valid) == 0:
        print("⚠️  No valid predictions with true labels for PR curve")
        return
    
    # Prepare data
    y_true = (valid['true_label'] == 'MS').astype(int)
    y_score = valid['prob_ms']
    
    # Calculate PR curve
    precision, recall, thresholds = precision_recall_curve(y_true, y_score)
    pr_auc = auc(recall, precision)
    
    # Plot
    fig, ax = plt.subplots(figsize=(10, 8), dpi=300)
    
    ax.plot(recall, precision, color='blue', lw=3, 
            label=f'PR Curve (AUC = {pr_auc:.3f})')
    
    ax.set_xlim([0.0, 1.0])
    ax.set_ylim([0.0, 1.05])
    ax.set_xlabel('Recall', fontsize=16, fontweight='bold')
    ax.set_ylabel('Precision', fontsize=16, fontweight='bold')
    ax.tick_params(labelsize=14)
    ax.legend(loc="lower left", fontsize=13, frameon=True, shadow=True)
    ax.grid(True, alpha=0.4, linestyle='--', linewidth=0.8)
    ax.spines['top'].set_linewidth(1.5)
    ax.spines['right'].set_linewidth(1.5)
    ax.spines['bottom'].set_linewidth(1.5)
    ax.spines['left'].set_linewidth(1.5)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    
    print(f"✅ PR curve saved to: {output_path}")
    print(f"   AUC = {pr_auc:.3f}")


def create_confidence_distribution(results_df, output_path='confidence_distribution.png'):
    """Create confidence distribution plot"""
    
    valid = results_df[results_df['prediction'].isin(['MS', 'Control'])]
    
    if len(valid) == 0:
        print("⚠️  No valid predictions for confidence distribution")
        return
    
    fig, ax = plt.subplots(figsize=(10, 6), dpi=300)
    
    # Separate by prediction
    ms_conf = valid[valid['prediction'] == 'MS']['confidence']
    control_conf = valid[valid['prediction'] == 'Control']['confidence']
    
    ax.hist(ms_conf, bins=20, alpha=0.7, label='MS', color='red', edgecolor='black')
    ax.hist(control_conf, bins=20, alpha=0.7, label='Control', color='blue', edgecolor='black')
    
    ax.set_xlabel('Confidence (%)', fontsize=14, fontweight='bold')
    ax.set_ylabel('Frequency', fontsize=14, fontweight='bold')
    ax.tick_params(labelsize=12)
    ax.legend(fontsize=12, frameon=True)
    ax.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    
    print(f"✅ Confidence distribution saved to: {output_path}")


def generate_manuscript_table(results_df, metrics_file, output_path='clinical_test_table.txt'):
    """Generate formatted table for manuscript"""
    
    # Load metrics
    with open(metrics_file, 'r') as f:
        metrics = json.load(f)
    
    # Extract values from metrics (handle both string and numeric formats)
    tp = metrics.get('true_positives_(tp)', 0)
    tn = metrics.get('true_negatives_(tn)', 0)
    fp = metrics.get('false_positives_(fp)', 0)
    fn = metrics.get('false_negatives_(fn)', 0)
    total_samples = tp + tn + fp + fn
    
    # Create table
    table = f"""
Clinical Test Results Table (for Manuscript)
{'='*60}

Performance Metrics on Independent Clinical Dataset
---------------------------------------------------
Total Samples: {total_samples}
Accuracy: {metrics['accuracy']}
Sensitivity (Recall): {metrics['sensitivity']}
Specificity: {metrics['specificity']}
Precision: {metrics['precision']}

Confusion Matrix
----------------
                    Predicted
                Control    MS
Actual  Control     {tn}      {fp}
        MS          {fn}      {tp}

Classification Report
---------------------
True Positive (TP): {tp}
True Negative (TN): {tn}
False Positive (FP): {fp}
False Negative (FN): {fn}

{'='*60}

LaTeX Table Format:
-------------------
\\begin{{table}}[h]
\\centering
\\caption{{Performance on Independent Clinical Dataset}}
\\begin{{tabular}}{{lc}}
\\hline
\\textbf{{Metric}} & \\textbf{{Value}} \\\\
\\hline
Samples & {total_samples} \\\\
Accuracy & {metrics['accuracy']} \\\\
Sensitivity & {metrics['sensitivity']} \\\\
Specificity & {metrics['specificity']} \\\\
Precision & {metrics['precision']} \\\\
\\hline
\\end{{tabular}}
\\end{{table}}

"""
    
    with open(output_path, 'w') as f:
        f.write(table)
    
    print(f"✅ Manuscript table saved to: {output_path}")
    print(table)


def main():
    """Main function"""
    
    if len(sys.argv) < 2:
        print("Usage: python visualize_results.py <predictions.csv>")
        print("\nExample:")
        print("  python visualize_results.py results/predictions_20250108_120000.csv")
        sys.exit(1)
    
    csv_path = sys.argv[1]
    
    if not os.path.exists(csv_path):
        print(f"❌ Error: File not found: {csv_path}")
        sys.exit(1)
    
    # Load results
    print(f"\nLoading results from: {csv_path}\n")
    results_df = pd.read_csv(csv_path)
    
    # Create output folder
    output_folder = os.path.join(os.path.dirname(csv_path), 'figures')
    os.makedirs(output_folder, exist_ok=True)
    
    print(f"{'='*60}")
    print("GENERATING VISUALIZATIONS")
    print(f"{'='*60}\n")
    
    # Create visualizations
    create_confusion_matrix(results_df, os.path.join(output_folder, 'confusion_matrix_clinical.png'))
    create_roc_curve(results_df, os.path.join(output_folder, 'roc_curve_clinical.png'))
    create_pr_curve(results_df, os.path.join(output_folder, 'pr_curve_clinical.png'))
    create_confidence_distribution(results_df, os.path.join(output_folder, 'confidence_distribution.png'))
    
    # Generate manuscript table if metrics file exists
    metrics_file = csv_path.replace('predictions_', 'metrics_').replace('.csv', '.json')
    if os.path.exists(metrics_file):
        generate_manuscript_table(results_df, metrics_file, 
                                 os.path.join(output_folder, 'clinical_test_table.txt'))
    
    print(f"\n{'='*60}")
    print(f"All visualizations saved to: {output_folder}")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
