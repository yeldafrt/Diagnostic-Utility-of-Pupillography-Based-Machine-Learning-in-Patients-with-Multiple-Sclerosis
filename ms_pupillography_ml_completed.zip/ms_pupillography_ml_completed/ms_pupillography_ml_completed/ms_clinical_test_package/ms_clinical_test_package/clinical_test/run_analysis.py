#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Main Analysis Script for Clinical Test Package

This script orchestrates the entire clinical testing workflow:
1. Runs batch prediction on a folder of images.
2. Generates a comprehensive Excel report.
3. Creates publication-quality visualizations.

Usage:
  python run_analysis.py <input_image_folder> <output_folder>

Example:
  python run_analysis.py data/ results/
"""

import sys
import os
from datetime import datetime

from predict_batch import predict_batch
from visualize_results import (
    create_confusion_matrix,
    create_roc_curve,
    create_pr_curve,
    create_confidence_distribution,
    generate_manuscript_table
)

def run_complete_analysis(image_folder, output_folder):
    """
    Run the complete analysis pipeline.
    """
    print(f"\n{'='*80}")
    print(f"STARTING COMPLETE CLINICAL ANALYSIS")
    print(f"{'='*80}")
    
    # Define paths
    true_labels_path = os.path.join(image_folder, 'true_labels.csv')
    if not os.path.exists(true_labels_path):
        print(f"\n[INFO] True labels file not found at '{true_labels_path}'. Performance metrics will not be calculated.")
        true_labels_path = None

    # --- Step 1: Run Batch Prediction ---
    print("\n--- Step 1: Running Batch Prediction ---")
    results_df, csv_path, excel_path, metrics_path = predict_batch(
        image_folder=image_folder,
        output_folder=output_folder,
        true_labels_file=true_labels_path
    )
    
    if results_df is None:
        print("\n[ERROR] Batch prediction failed. Exiting analysis.")
        return

    # --- Step 2: Generate Visualizations ---
    print("\n--- Step 2: Generating Visualizations ---")
    figures_folder = os.path.join(output_folder, 'figures')
    os.makedirs(figures_folder, exist_ok=True)
    
    if metrics_path:
        print("\nGenerating performance-based visualizations...")
        create_confusion_matrix(results_df, os.path.join(figures_folder, 'confusion_matrix_clinical.png'))
        create_roc_curve(results_df, os.path.join(figures_folder, 'roc_curve_clinical.png'))
        create_pr_curve(results_df, os.path.join(figures_folder, 'pr_curve_clinical.png'))
        generate_manuscript_table(results_df, metrics_path, os.path.join(figures_folder, 'clinical_test_table.txt'))
    else:
        print("\n[INFO] Skipping performance-based visualizations as no true labels were provided.")

    print("\nGenerating general visualizations...")
    create_confidence_distribution(results_df, os.path.join(figures_folder, 'confidence_distribution.png'))
    
    print(f"\nAll visualizations saved to: {figures_folder}")
    
    print(f"\n{'='*80}")
    print(f"COMPLETE CLINICAL ANALYSIS FINISHED")
    print(f"All results are in the '{output_folder}' directory.")
    print(f"  - CSV Report: {csv_path}")
    print(f"  - Excel Report: {excel_path}")
    if metrics_path:
        print(f"  - Metrics File: {metrics_path}")
    print(f"  - Figures: {figures_folder}")
    print(f"{'='*80}\n")

def main():
    """Main function"""
    if len(sys.argv) != 3:
        print("Usage: python run_analysis.py <input_image_folder> <output_folder>")
        print("\nExample:")
        print("  python run_analysis.py data/ results/")
        sys.exit(1)
        
    image_folder = sys.argv[1]
    output_folder = sys.argv[2]
    
    if not os.path.isdir(image_folder):
        print(f"[ERROR] Input directory not found: {image_folder}")
        sys.exit(1)
        
    run_complete_analysis(image_folder, output_folder)

if __name__ == "__main__":
    main()

