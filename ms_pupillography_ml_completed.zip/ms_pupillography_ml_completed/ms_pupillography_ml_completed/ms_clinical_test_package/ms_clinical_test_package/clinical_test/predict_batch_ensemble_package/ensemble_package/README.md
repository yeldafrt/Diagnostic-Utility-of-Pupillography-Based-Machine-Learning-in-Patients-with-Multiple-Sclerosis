# Patient-Based Ensemble Prediction - Kullanım Kılavuzu

## 📋 Genel Bakış

`predict_batch_ensemble.py` dosyası, **hasta bazında** MS tahmini yapmak için **ensemble aggregation stratejisi** kullanır.

### Strateji:
```
Final Score = 0.7 × Maximum Probability + 0.3 × Mean of Top-5 Probabilities
Threshold = 0.465
```

---

## 📁 Dosya Yapısı

```
clinical_test/
├── predict_single_image.py          # Tek görüntü tahmini
├── predict_batch.py                 # Görüntü bazında batch tahmin
├── predict_batch_ensemble.py        # Hasta bazında ensemble tahmin ← YENİ
├── run_analysis.py                  # Ana analiz scripti
└── visualize_results.py             # Görselleştirme
```

---

## 🚀 Kurulum

### 1. Dosyayı Kopyalayın
```bash
cp predict_batch_ensemble.py clinical_test/
```

### 2. Gerekli Kütüphaneler
```bash
pip install numpy pandas scikit-learn joblib openpyxl
```

---

## 💻 Kullanım

### Temel Kullanım

```bash
python predict_batch_ensemble.py /path/to/images
```

### Tüm Parametrelerle

```bash
python predict_batch_ensemble.py /path/to/images \
    --output results \
    --model ../ms_pupillography_ml/models/ms_detection_model.pkl \
    --scaler ../ms_pupillography_ml/models/feature_scaler.pkl \
    --labels true_labels.csv \
    --threshold 0.465
```

### Parametreler

| Parametre | Kısa | Açıklama | Varsayılan |
|-----------|------|----------|------------|
| `image_folder` | - | Görüntülerin bulunduğu klasör | *Zorunlu* |
| `--output` | `-o` | Sonuçların kaydedileceği klasör | `results` |
| `--model` | `-m` | Eğitilmiş model dosyası | `../ms_pupillography_ml/models/ms_detection_model.pkl` |
| `--scaler` | `-s` | Feature scaler dosyası | `../ms_pupillography_ml/models/feature_scaler.pkl` |
| `--labels` | `-l` | Gerçek etiketlerin bulunduğu CSV | `None` |
| `--threshold` | `-t` | Karar eşiği | `0.465` |

---

## 📊 Görüntü İsimlendirme

Script, hasta ID'sini dosya adından otomatik çıkarır:

### Desteklenen Formatlar:
```
Patient001_image1.jpg  → Patient ID: Patient001
Patient001_image2.jpg  → Patient ID: Patient001
MS_01-img1.png         → Patient ID: MS_01
Control_05-img2.png    → Patient ID: Control_05
```

### Kural:
- İlk `_` veya `-` karakterinden önceki kısım hasta ID'si olarak alınır
- Aynı hasta ID'sine sahip tüm görüntüler gruplanır

---

## 📄 True Labels Dosyası (Opsiyonel)

Performans metriklerini hesaplamak için gerçek etiketleri içeren CSV dosyası:

### Format:
```csv
patient_id,true_label
Patient001,MS
Patient002,Control
Patient003,MS
```

### Sütunlar:
- `patient_id`: Hasta ID'si (dosya adından çıkarılan ile eşleşmeli)
- `true_label`: `MS` veya `Control`

---

## 📤 Çıktı Dosyaları

Script 4 dosya oluşturur:

### 1. Patient Predictions (CSV)
`patient_predictions_ensemble_YYYYMMDD_HHMMSS.csv`

| Sütun | Açıklama |
|-------|----------|
| `patient_id` | Hasta ID'si |
| `num_images` | Toplam görüntü sayısı |
| `num_valid` | Geçerli (quality check geçen) görüntü sayısı |
| `prediction` | Tahmin (MS / Control) |
| `ensemble_score` | Final ensemble skoru |
| `max_probability` | En yüksek MS olasılığı |
| `top5_mean` | İlk 5'in ortalaması |
| `true_label` | Gerçek etiket (varsa) |
| `correct` | Doğru tahmin mi? (varsa) |

### 2. Image Details (CSV)
`image_predictions_YYYYMMDD_HHMMSS.csv`

Her görüntü için detaylı bilgi:
- Hasta ID
- Dosya adı
- Quality check sonucu
- MS olasılığı

### 3. Performance Metrics (JSON)
`metrics_ensemble_YYYYMMDD_HHMMSS.json`

```json
{
    "accuracy": 0.750,
    "sensitivity": 0.889,
    "specificity": 0.571,
    "precision": 0.727,
    "f1_score": 0.800,
    "auc_roc": 0.627,
    "true_positive": 16,
    "true_negative": 8,
    "false_positive": 6,
    "false_negative": 2,
    "total_patients": 32,
    "threshold": 0.465
}
```

### 4. Excel Report
`report_ensemble_YYYYMMDD_HHMMSS.xlsx`

3 sheet içerir:
- **Patient Predictions**: Hasta bazında sonuçlar
- **Image Details**: Görüntü bazında detaylar
- **Performance Metrics**: Performans metrikleri

---

## 🎯 Örnek Kullanım

### Senaryo 1: Sadece Tahmin
```bash
python predict_batch_ensemble.py data/test_images/
```

### Senaryo 2: Performans Değerlendirmesi
```bash
python predict_batch_ensemble.py data/validation_images/ \
    --labels data/true_labels.csv \
    --output validation_results/
```

### Senaryo 3: Farklı Threshold
```bash
python predict_batch_ensemble.py data/images/ \
    --threshold 0.5 \
    --output results_threshold_0.5/
```

---

## 🔧 Ensemble Stratejisi Detayları

### Adımlar:

1. **Görüntüleri Grupla**: Aynı hasta ID'sine sahip görüntüler gruplanır
2. **Olasılıkları Hesapla**: Her görüntü için MS olasılığı hesaplanır
3. **Ensemble Uygula**:
   ```
   max_prob = max(probabilities)
   top5_mean = mean(top_5_probabilities)
   final_score = 0.7 × max_prob + 0.3 × top5_mean
   ```
4. **Karar Ver**:
   ```
   if final_score > 0.465:
       prediction = "MS"
   else:
       prediction = "Control"
   ```

### Örnek:
```
Hasta_001 görüntüleri:
  Probabilities: [0.92, 0.88, 0.85, 0.91, 0.87, 0.89, 0.86, 0.90, 0.84, 0.88, 0.93]

Hesaplama:
  max_prob = 0.93
  top5 = [0.93, 0.92, 0.91, 0.90, 0.89]
  top5_mean = 0.91
  
  final_score = 0.7 × 0.93 + 0.3 × 0.91 = 0.924
  
  0.924 > 0.465 → MS ✅
```

---

## 📊 Performans Metrikleri

Script aşağıdaki metrikleri hesaplar (true labels varsa):

- **Accuracy**: Genel doğruluk
- **Sensitivity (Recall)**: MS hastalarını doğru tespit etme oranı
- **Specificity**: Kontrolleri doğru tespit etme oranı
- **Precision**: MS tahmini yapılanların doğru olma oranı
- **F1-Score**: Precision ve Recall'un harmonik ortalaması
- **AUC-ROC**: ROC eğrisi altında kalan alan
- **Confusion Matrix**: TP, TN, FP, FN

---

## ⚠️ Önemli Notlar

1. **Hasta ID Çıkarımı**: `extract_patient_id()` fonksiyonunu kendi dosya isimlendirme kuralınıza göre düzenleyin
2. **Minimum Görüntü**: Her hasta için en az 1 geçerli görüntü olmalı
3. **Quality Check**: Düşük kaliteli görüntüler otomatik olarak filtrelenir
4. **Threshold**: 0.465 optimal değerdir, değiştirmek performansı etkileyebilir

---

## 🆚 predict_batch.py ile Farkı

| Özellik | predict_batch.py | predict_batch_ensemble.py |
|---------|------------------|---------------------------|
| **Tahmin Seviyesi** | Görüntü bazında | Hasta bazında |
| **Ensemble** | Yok | Var (0.7×max + 0.3×top5) |
| **Threshold** | Model varsayılanı | 0.465 (optimize edilmiş) |
| **Çıktı** | Her görüntü için ayrı | Her hasta için tek |
| **Klinik Kullanım** | Araştırma | Klinik karar |

---

## 📞 Destek

Sorularınız için:
- GitHub Issues
- Email: drnparmak@yahoo.com

---

## 📝 Lisans

MIT License

