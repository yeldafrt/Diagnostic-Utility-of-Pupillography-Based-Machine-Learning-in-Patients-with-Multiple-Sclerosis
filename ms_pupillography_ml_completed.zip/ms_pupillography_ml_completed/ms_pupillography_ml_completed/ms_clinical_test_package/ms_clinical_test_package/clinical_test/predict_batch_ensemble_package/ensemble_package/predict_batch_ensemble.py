#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Patient-Based Ensemble MS Prediction Script
Uses ensemble aggregation strategy for patient-level predictions.

This script groups multiple images by patient ID and applies the ensemble
aggregation strategy: 0.7 × maximum probability + 0.3 × mean of top-5 probabilities
with a decision threshold of 0.465.
"""

import sys
import os
import joblib
import numpy as np
import pandas as pd
from datetime import datetime
from pathlib import Path
import json
from sklearn.metrics import confusion_matrix, roc_auc_score, accuracy_score, precision_score, recall_score, f1_score

# Add parent directory to path for local imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'ms_pupillography_ml'))

from src.feature_extraction.extract_features import extract_features
from src.preprocessing.preprocess import quality_check


def ensemble_aggregation(probabilities, threshold=0.465):
    """
    Apply ensemble aggregation strategy to multiple probability estimates.
    
    Strategy: 0.7 × maximum probability + 0.3 × mean of top-5 probabilities
    
    Args:
        probabilities (list or np.array): MS probabilities from multiple images
        threshold (float): Decision threshold (default: 0.465)
    
    Returns:
        tuple: (prediction, final_score)
            - prediction (str): 'MS' or 'Control'
            - final_score (float): Final ensemble score
    """
    probabilities = np.array(probabilities)
    
    if len(probabilities) == 0:
        return 'N/A', 0.0
    
    # Sort probabilities in descending order
    sorted_probs = np.sort(probabilities)[::-1]
    
    # Maximum probability
    max_prob = sorted_probs[0]
    
    # Mean of top-5 probabilities (or all if less than 5)
    top_k = min(5, len(sorted_probs))
    top_k_mean = np.mean(sorted_probs[:top_k])
    
    # Ensemble score: 0.7 × max + 0.3 × top-k mean
    final_score = 0.7 * max_prob + 0.3 * top_k_mean
    
    # Decision based on threshold
    prediction = 'MS' if final_score > threshold else 'Control'
    
    return prediction, final_score


def extract_patient_id(filename):
    """
    Extract patient ID from filename.
    
    Assumes filename format: PatientID_xxx.jpg or PatientID.jpg
    Modify this function based on your naming convention.
    
    Args:
        filename (str): Image filename
    
    Returns:
        str: Patient ID
    """
    # Remove extension
    name = Path(filename).stem
    
    # Try to extract patient ID (before first underscore or dash)
    if '_' in name:
        patient_id = name.split('_')[0]
    elif '-' in name:
        patient_id = name.split('-')[0]
    else:
        patient_id = name
    
    return patient_id


def predict_batch_ensemble(image_folder, output_folder='results', 
                           model_path='../ms_pupillography_ml/models/ms_detection_model.pkl',
                           scaler_path='../ms_pupillography_ml/models/feature_scaler.pkl',
                           true_labels_file=None,
                           threshold=0.465):
    """
    Predict MS for multiple patients using ensemble aggregation strategy.
    
    Args:
        image_folder (str): Folder containing OCT images.
        output_folder (str): Folder to save results.
        model_path (str): Path to the trained model.
        scaler_path (str): Path to the feature scaler.
        true_labels_file (str, optional): Path to CSV with true labels (patient_id, true_label).
        threshold (float): Decision threshold for ensemble prediction (default: 0.465).
        
    Returns:
        tuple: (patient_results_df, image_results_df, metrics_dict)
    """
    
    print(f"\n{'='*80}")
    print(f"MS PUPILLOGRAPHY PATIENT-BASED ENSEMBLE PREDICTION")
    print(f"{'='*80}")
    print(f"Input folder: {image_folder}")
    print(f"Output folder: {output_folder}")
    print(f"Ensemble threshold: {threshold}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*80}\n")
    
    os.makedirs(output_folder, exist_ok=True)
    
    # Load model and scaler
    print("Loading model...")
    try:
        model = joblib.load(model_path)
        scaler = joblib.load(scaler_path)
        print("✅ Model loaded successfully\n")
    except Exception as e:
        print(f"❌ Error loading model: {e}")
        return None, None, None
    
    # Find image files
    image_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff']
    image_files = sorted([p for p in Path(image_folder).rglob('*') if p.suffix.lower() in image_extensions])
    
    if not image_files:
        print(f"❌ No image files found in {image_folder}")
        return None, None, None
    
    print(f"Found {len(image_files)} images\n")
    
    # Load true labels
    true_labels_dict = {}
    if true_labels_file and os.path.exists(true_labels_file):
        try:
            true_labels_df = pd.read_csv(true_labels_file)
            true_labels_dict = dict(zip(true_labels_df['patient_id'].astype(str), true_labels_df['true_label']))
            print(f"✅ Loaded true labels for {len(true_labels_dict)} patients\n")
        except Exception as e:
            print(f"⚠️  Warning: Could not load true labels: {e}\n")
    
    # Process each image and group by patient
    print("Processing images...")
    patient_data = {}  # {patient_id: {'images': [...], 'probabilities': [...]}}
    image_results = []
    
    for i, img_path in enumerate(image_files, 1):
        print(f"[{i}/{len(image_files)}] Processing: {img_path.name}")
        
        patient_id = extract_patient_id(img_path.name)
        
        if patient_id not in patient_data:
            patient_data[patient_id] = {'images': [], 'probabilities': [], 'quality_passed': 0, 'quality_failed': 0}
        
        image_result = {
            'patient_id': patient_id,
            'image_file': img_path.name,
            'image_path': str(img_path)
        }
        
        # Quality check
        is_valid, reason = quality_check(str(img_path))
        image_result['quality_check'] = 'PASS' if is_valid else 'FAIL'
        image_result['quality_reason'] = reason
        
        if not is_valid:
            print(f"  ❌ Quality check failed: {reason}")
            patient_data[patient_id]['quality_failed'] += 1
            image_result['ms_probability'] = np.nan
            image_results.append(image_result)
            continue
        
        try:
            # Extract features and predict
            features = extract_features(str(img_path))
            features_scaled = scaler.transform([features])
            probabilities = model.predict_proba(features_scaled)[0]
            ms_prob = probabilities[1]
            
            # Store probability for ensemble
            patient_data[patient_id]['probabilities'].append(ms_prob)
            patient_data[patient_id]['images'].append(img_path.name)
            patient_data[patient_id]['quality_passed'] += 1
            
            image_result['ms_probability'] = ms_prob
            image_result['control_probability'] = probabilities[0]
            
            print(f"  ✅ MS probability: {ms_prob:.3f}")
            
        except Exception as e:
            print(f"  ❌ Processing failed: {e}")
            image_result['ms_probability'] = np.nan
            image_result['error'] = str(e)
        
        image_results.append(image_result)
    
    # Apply ensemble aggregation for each patient
    print(f"\n{'='*80}")
    print("Applying ensemble aggregation strategy...")
    print(f"{'='*80}\n")
    
    patient_results = []
    
    for patient_id, data in patient_data.items():
        print(f"Patient: {patient_id}")
        print(f"  Images: {len(data['images'])} (quality passed: {data['quality_passed']})")
        
        if len(data['probabilities']) == 0:
            print(f"  ⚠️  No valid probabilities - skipping")
            patient_results.append({
                'patient_id': patient_id,
                'num_images': len(data['images']),
                'num_valid': 0,
                'prediction': 'N/A',
                'ensemble_score': 0.0,
                'max_probability': np.nan,
                'top5_mean': np.nan
            })
            continue
        
        # Calculate ensemble prediction
        prediction, ensemble_score = ensemble_aggregation(data['probabilities'], threshold)
        
        # Calculate components
        sorted_probs = np.sort(data['probabilities'])[::-1]
        max_prob = sorted_probs[0]
        top_k = min(5, len(sorted_probs))
        top_k_mean = np.mean(sorted_probs[:top_k])
        
        patient_result = {
            'patient_id': patient_id,
            'num_images': len(data['images']),
            'num_valid': len(data['probabilities']),
            'prediction': prediction,
            'ensemble_score': ensemble_score,
            'max_probability': max_prob,
            'top5_mean': top_k_mean,
            'all_probabilities': data['probabilities']
        }
        
        # Add true label if available
        if patient_id in true_labels_dict:
            true_label = true_labels_dict[patient_id]
            patient_result['true_label'] = true_label
            patient_result['correct'] = (prediction == true_label)
            print(f"  True: {true_label}, Predicted: {prediction} {'✅' if prediction == true_label else '❌'}")
        
        print(f"  Ensemble score: {ensemble_score:.3f} (max: {max_prob:.3f}, top-5 mean: {top_k_mean:.3f})")
        print(f"  Prediction: {prediction}\n")
        
        patient_results.append(patient_result)
    
    # Create DataFrames
    patient_results_df = pd.DataFrame(patient_results)
    image_results_df = pd.DataFrame(image_results)
    
    # Calculate metrics if true labels are available
    metrics_dict = None
    if 'true_label' in patient_results_df.columns:
        print(f"\n{'='*80}")
        print("PERFORMANCE METRICS")
        print(f"{'='*80}\n")
        
        valid_results = patient_results_df[patient_results_df['prediction'] != 'N/A'].copy()
        
        if len(valid_results) > 0:
            y_true = (valid_results['true_label'] == 'MS').astype(int)
            y_pred = (valid_results['prediction'] == 'MS').astype(int)
            y_score = valid_results['ensemble_score'].values
            
            accuracy = accuracy_score(y_true, y_pred)
            sensitivity = recall_score(y_true, y_pred, pos_label=1)
            specificity = recall_score(y_true, y_pred, pos_label=0)
            precision = precision_score(y_true, y_pred, zero_division=0)
            f1 = f1_score(y_true, y_pred, zero_division=0)
            
            try:
                auc_roc = roc_auc_score(y_true, y_score)
            except:
                auc_roc = np.nan
            
            # Confusion matrix
            cm = confusion_matrix(y_true, y_pred)
            tn, fp, fn, tp = cm.ravel()
            
            metrics_dict = {
                'accuracy': accuracy,
                'sensitivity': sensitivity,
                'specificity': specificity,
                'precision': precision,
                'f1_score': f1,
                'auc_roc': auc_roc,
                'true_positive': int(tp),
                'true_negative': int(tn),
                'false_positive': int(fp),
                'false_negative': int(fn),
                'total_patients': len(valid_results),
                'threshold': threshold
            }
            
            print(f"Accuracy:    {accuracy:.3f} ({accuracy*100:.1f}%)")
            print(f"Sensitivity: {sensitivity:.3f} ({sensitivity*100:.1f}%)")
            print(f"Specificity: {specificity:.3f} ({specificity*100:.1f}%)")
            print(f"Precision:   {precision:.3f} ({precision*100:.1f}%)")
            print(f"F1-Score:    {f1:.3f} ({f1*100:.1f}%)")
            print(f"AUC-ROC:     {auc_roc:.3f}")
            print(f"\nConfusion Matrix:")
            print(f"  TP: {tp}, TN: {tn}, FP: {fp}, FN: {fn}\n")
    
    # Save results
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # 1. Patient-level results
    patient_csv = os.path.join(output_folder, f'patient_predictions_ensemble_{timestamp}.csv')
    patient_results_df.to_csv(patient_csv, index=False)
    print(f"✅ Patient predictions saved to: {patient_csv}")
    
    # 2. Image-level results
    image_csv = os.path.join(output_folder, f'image_predictions_{timestamp}.csv')
    image_results_df.to_csv(image_csv, index=False)
    print(f"✅ Image predictions saved to: {image_csv}")
    
    # 3. Metrics JSON
    if metrics_dict:
        metrics_json = os.path.join(output_folder, f'metrics_ensemble_{timestamp}.json')
        with open(metrics_json, 'w') as f:
            json.dump(metrics_dict, f, indent=4)
        print(f"✅ Metrics saved to: {metrics_json}")
    
    # 4. Excel report
    excel_path = os.path.join(output_folder, f'report_ensemble_{timestamp}.xlsx')
    with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
        patient_results_df.to_excel(writer, sheet_name='Patient Predictions', index=False)
        image_results_df.to_excel(writer, sheet_name='Image Details', index=False)
        
        if metrics_dict:
            metrics_df = pd.DataFrame([metrics_dict])
            metrics_df.to_excel(writer, sheet_name='Performance Metrics', index=False)
    
    print(f"✅ Excel report saved to: {excel_path}\n")
    
    return patient_results_df, image_results_df, metrics_dict


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Patient-based ensemble MS prediction')
    parser.add_argument('image_folder', help='Folder containing OCT images')
    parser.add_argument('--output', '-o', default='results', help='Output folder (default: results)')
    parser.add_argument('--model', '-m', default='../ms_pupillography_ml/models/ms_detection_model.pkl', 
                       help='Path to trained model')
    parser.add_argument('--scaler', '-s', default='../ms_pupillography_ml/models/feature_scaler.pkl',
                       help='Path to feature scaler')
    parser.add_argument('--labels', '-l', help='CSV file with true labels (patient_id, true_label)')
    parser.add_argument('--threshold', '-t', type=float, default=0.465,
                       help='Decision threshold (default: 0.465)')
    
    args = parser.parse_args()
    
    predict_batch_ensemble(
        image_folder=args.image_folder,
        output_folder=args.output,
        model_path=args.model,
        scaler_path=args.scaler,
        true_labels_file=args.labels,
        threshold=args.threshold
    )

