# Veri Klasörü

Bu klasöre pupillografi görüntülerinizi yerleştirin.

## Görüntü Formatları

Desteklenen formatlar:
- `.jpg`, `.jpeg`
- `.png`
- `.bmp`
- `.tif`, `.tiff`

## Dosya Adlandırma

Her görüntü için benzersiz bir ID kullanın:
```
patient001.png
patient002.png
patient003.png
...
```

## Gerçek Etiketler (Opsiyonel)

Performans metriklerini hesaplamak için `true_labels.csv` dosyası oluşturun:

```csv
patient_id,true_label
patient001,MS
patient002,Control
patient003,MS
```

**Önemli**: `patient_id` görüntü dosya adı ile (uzantı olmadan) tam olarak eşleşmelidir.

Örnek bir şablon için `true_labels_template.csv` dosyasına bakın.
