#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Batch MS Prediction Script
Test multiple OCT pupillography images and generate a comprehensive, multi-sheet Excel report.
"""

import sys
import os
import joblib
import numpy as np
import pandas as pd
from datetime import datetime
from pathlib import Path
import json
from sklearn.metrics import confusion_matrix

# Add parent directory to path for local imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'ms_pupillography_ml'))

from src.feature_extraction.extract_features import extract_features
from src.preprocessing.preprocess import quality_check

def predict_batch(image_folder, output_folder='results', 
                 model_path='../ms_pupillography_ml/models/ms_detection_model.pkl',
                 scaler_path='../ms_pupillography_ml/models/feature_scaler.pkl',
                 true_labels_file=None):
    """
    Predict MS for multiple images and generate a comprehensive report.
    
    Args:
        image_folder (str): Folder containing OCT images.
        output_folder (str): Folder to save results.
        model_path (str): Path to the trained model.
        scaler_path (str): Path to the feature scaler.
        true_labels_file (str, optional): Path to a CSV file with true labels.
        
    Returns:
        tuple: (pd.DataFrame, str, str, str) containing the results dataframe,
               path to the CSV report, path to the Excel report, and path to the metrics JSON file.
               Returns (None, None, None, None) on failure.
    """
    
    print(f"\n{'='*80}")
    print(f"MS PUPILLOGRAPHY BATCH PREDICTION")
    print(f"{'='*80}")
    print(f"Input folder: {image_folder}")
    print(f"Output folder: {output_folder}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*80}\n")
    
    os.makedirs(output_folder, exist_ok=True)
    
    # Load model and scaler
    print("Loading model...")
    try:
        model = joblib.load(model_path)
        scaler = joblib.load(scaler_path)
        print("✅ Model loaded successfully\n")
    except Exception as e:
        print(f"❌ Error loading model: {e}")
        return None, None, None, None
    
    # Find image files
    image_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff']
    image_files = sorted([p for p in Path(image_folder).rglob('*') if p.suffix.lower() in image_extensions])
    
    if not image_files:
        print(f"❌ No image files found in {image_folder}")
        return None, None, None, None
    
    print(f"Found {len(image_files)} images\n")
    
    # Load true labels
    true_labels_dict = {}
    if true_labels_file and os.path.exists(true_labels_file):
        try:
            true_labels_df = pd.read_csv(true_labels_file)
            true_labels_dict = dict(zip(true_labels_df['patient_id'].astype(str), true_labels_df['true_label']))
            print(f"✅ Loaded true labels for {len(true_labels_dict)} patients\n")
        except Exception as e:
            print(f"⚠️  Warning: Could not load true labels: {e}\n")

    # Process each image
    results = []
    for i, img_path in enumerate(image_files, 1):
        print(f"[{i}/{len(image_files)}] Processing: {img_path.name}")
        
        result = {'image_file': img_path.name, 'image_path': str(img_path)}
        
        is_valid, reason = quality_check(str(img_path))
        result.update({'quality_check': 'PASS' if is_valid else 'FAIL', 'quality_reason': reason})
        
        if not is_valid:
            print(f"  ❌ Quality check failed: {reason}")
            results.append({**result, 'prediction': 'N/A', 'confidence': 0.0})
            continue
        
        try:
            features = extract_features(str(img_path))
            features_scaled = scaler.transform([features])
            prediction = model.predict(features_scaled)[0]
            probabilities = model.predict_proba(features_scaled)[0]
            
            result.update({
                'prediction': 'MS' if prediction == 1 else 'Control',
                'prediction_code': int(prediction),
                'confidence': max(probabilities) * 100,
                'prob_control': probabilities[0],
                'prob_ms': probabilities[1],
            })

            patient_id = img_path.stem
            if patient_id in true_labels_dict:
                true_label = true_labels_dict[patient_id]
                result['true_label'] = true_label
                result['correct'] = (result['prediction'] == true_label)
            
            print(f"  ✅ Prediction: {result['prediction']} (confidence: {result['confidence']:.1f}%)")

        except Exception as e:
            print(f"  ❌ Processing failed: {e}")
            result.update({'prediction': 'ERROR', 'error': str(e)})
        
        results.append(result)
    
    results_df = pd.DataFrame(results)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # Save raw results to CSV
    csv_path = os.path.join(output_folder, f'predictions_{timestamp}.csv')
    results_df.to_csv(csv_path, index=False)
    print(f"\n✅ Raw results saved to: {csv_path}")

    # --- Generate Comprehensive Excel Report ---
    excel_path = os.path.join(output_folder, f'report_{timestamp}.xlsx')
    metrics_data = None
    metrics_path = None

    with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
        # 1. Detailed Predictions Sheet
        results_df.to_excel(writer, sheet_name='Detailed Predictions', index=False)

        # 2. Summary and Metrics Sheets
        summary_data = {
            'Metric': ['Total Images Processed', 'Quality Check Passed', 'Quality Check Failed', 'Predictions (MS)', 'Predictions (Control)', 'Errors'],
            'Value': [
                len(results_df),
                (results_df['quality_check'] == 'PASS').sum(),
                (results_df['quality_check'] == 'FAIL').sum(),
                (results_df['prediction'] == 'MS').sum(),
                (results_df['prediction'] == 'Control').sum(),
                (results_df['prediction'] == 'ERROR').sum()
            ]
        }
        pd.DataFrame(summary_data).to_excel(writer, sheet_name='Summary', index=False)

        if 'true_label' in results_df.columns and results_df['true_label'].notna().any():
            valid_df = results_df[results_df['true_label'].notna() & results_df['prediction'].isin(['MS', 'Control'])].copy()
            y_true = (valid_df['true_label'] == 'MS')
            y_pred = (valid_df['prediction'] == 'MS')
            
            tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
            accuracy = (tp + tn) / (tp + tn + fp + fn) * 100
            sensitivity = tp / (tp + fn) * 100 if (tp + fn) > 0 else 0
            specificity = tn / (tn + fp) * 100 if (tn + fp) > 0 else 0
            precision = tp / (tp + fp) * 100 if (tp + fp) > 0 else 0

            metrics_data = {
                'Metric': ['Accuracy', 'Sensitivity (Recall)', 'Specificity', 'Precision', 'True Positives (TP)', 'True Negatives (TN)', 'False Positives (FP)', 'False Negatives (FN)'],
                'Value': [f"{accuracy:.2f}%", f"{sensitivity:.2f}%", f"{specificity:.2f}%", f"{precision:.2f}%", tp, tn, fp, fn]
            }
            pd.DataFrame(metrics_data).to_excel(writer, sheet_name='Performance Metrics', index=False)
            
            # Save metrics to JSON file as well
            metrics_path = os.path.join(output_folder, f'metrics_{timestamp}.json')
            json_metrics = {}
            for k, v in zip(metrics_data['Metric'], metrics_data['Value']):
                key = k.replace(' (Recall)', '').replace(' ', '_').lower()
                # Convert numpy int64 to Python int
                if isinstance(v, (np.integer, np.int64)):
                    v = int(v)
                json_metrics[key] = v
            with open(metrics_path, 'w') as f:
                json.dump(json_metrics, f, indent=4)
            print(f"✅ Performance metrics saved to: {metrics_path}")

    print(f"✅ Comprehensive Excel report saved to: {excel_path}")
    
    return results_df, csv_path, excel_path, metrics_path

def main():
    """Main function for direct script execution."""
    if len(sys.argv) < 2:
        print("Usage: python predict_batch.py <image_folder> [output_folder] [true_labels.csv]")
        sys.exit(1)
    
    image_folder = sys.argv[1]
    output_folder = sys.argv[2] if len(sys.argv) > 2 else 'results'
    true_labels_file = sys.argv[3] if len(sys.argv) > 3 else None
    
    if not os.path.isdir(image_folder):
        print(f"❌ Error: Folder not found: {image_folder}")
        sys.exit(1)

    predict_batch(image_folder, output_folder, true_labels_file=true_labels_file)

if __name__ == "__main__":
    main()

