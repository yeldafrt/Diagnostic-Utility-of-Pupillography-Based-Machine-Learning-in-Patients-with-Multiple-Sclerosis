# Contributing to MS Pupillography ML

Thank you for your interest in contributing to this project! This document provides guidelines for contributing.

## How to Contribute

### Reporting Bugs

If you find a bug, please open an issue on GitHub with:
- A clear description of the bug
- Steps to reproduce the issue
- Expected vs. actual behavior
- Your environment (OS, Python version, package versions)
- Any relevant error messages or logs

### Suggesting Enhancements

We welcome suggestions for new features or improvements! Please open an issue with:
- A clear description of the enhancement
- Use cases and benefits
- Any implementation ideas you have

### Pull Requests

1. **Fork the repository** and create your branch from `main`
2. **Make your changes** following the code style guidelines below
3. **Add tests** if you're adding new functionality
4. **Update documentation** as needed
5. **Ensure all tests pass** before submitting
6. **Submit a pull request** with a clear description of your changes

## Development Setup

1. Clone your fork:
```bash
git clone https://github.com/yourusername/ms_pupillography_ml.git
cd ms_pupillography_ml
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install development dependencies:
```bash
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

4. Install the package in editable mode:
```bash
pip install -e .
```

## Code Style

### Python Style Guide

- Follow [PEP 8](https://www.python.org/dev/peps/pep-0008/) style guide
- Use [Black](https://github.com/psf/black) for code formatting
- Use [flake8](https://flake8.pycqa.org/) for linting
- Use type hints where appropriate

### Formatting Code

Before committing, format your code:
```bash
black src/
flake8 src/
```

### Docstrings

Use Google-style docstrings:

```python
def function_name(param1: int, param2: str) -> bool:
    """
    Brief description of function.
    
    Longer description if needed.
    
    Args:
        param1: Description of param1
        param2: Description of param2
        
    Returns:
        Description of return value
        
    Raises:
        ValueError: When param1 is negative
        
    Example:
        >>> result = function_name(5, "test")
        >>> print(result)
        True
    """
    pass
```

## Testing

### Running Tests

```bash
# Run all tests
pytest tests/

# Run with coverage
pytest --cov=src tests/

# Run specific test file
pytest tests/test_feature_extraction.py
```

### Writing Tests

- Place tests in the `tests/` directory
- Name test files as `test_*.py`
- Name test functions as `test_*`
- Use descriptive test names

Example:
```python
def test_extract_features_returns_correct_number():
    """Test that extract_features returns 22 features"""
    features = extract_features('test_image.png')
    assert len(features) == 22
```

## Documentation

### Updating Documentation

- Update README.md for major changes
- Add docstrings to new functions and classes
- Update relevant files in `docs/` directory
- Include examples in docstrings

### Building Documentation

```bash
cd docs/
make html
```

## Commit Messages

Write clear, concise commit messages:

```
Add feature extraction for texture analysis

- Implement gradient-based features
- Add Laplacian variance calculation
- Update tests for new features
```

Format:
- First line: Brief summary (50 chars or less)
- Blank line
- Detailed description if needed (wrap at 72 chars)

## Branch Naming

Use descriptive branch names:
- `feature/add-new-feature`
- `bugfix/fix-issue-123`
- `docs/update-readme`
- `refactor/improve-performance`

## Code Review Process

1. All submissions require review before merging
2. Address reviewer comments promptly
3. Keep pull requests focused and reasonably sized
4. Ensure CI/CD checks pass

## Questions?

If you have questions about contributing, feel free to:
- Open an issue on GitHub
- Contact the maintainers at [your.email@institution.edu]

## Code of Conduct

### Our Pledge

We pledge to make participation in our project a harassment-free experience for everyone, regardless of age, body size, disability, ethnicity, gender identity and expression, level of experience, nationality, personal appearance, race, religion, or sexual identity and orientation.

### Our Standards

**Positive behavior includes:**
- Using welcoming and inclusive language
- Being respectful of differing viewpoints
- Gracefully accepting constructive criticism
- Focusing on what is best for the community

**Unacceptable behavior includes:**
- Harassment, trolling, or derogatory comments
- Publishing others' private information
- Other conduct which could reasonably be considered inappropriate

### Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to the project maintainers. All complaints will be reviewed and investigated promptly and fairly.

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

## Thank You!

Your contributions help make this project better for everyone. We appreciate your time and effort!
