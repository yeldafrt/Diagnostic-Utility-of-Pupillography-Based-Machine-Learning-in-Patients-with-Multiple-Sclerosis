#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, roc_curve, accuracy_score, precision_score, recall_score, f1_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
import tensorflow as tf
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, GlobalAveragePooling2D, Dense, Dropout, BatchNormalization, Concatenate
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import cv2
from skimage import filters, measure, morphology, segmentation
from skimage.feature import graycomatrix, graycoprops
import pickle
import warnings
warnings.filterwarnings('ignore')

# Parametreler
IMG_SIZE = (128, 128)
BATCH_SIZE = 8
EPOCHS = 15

def calculate_image_quality_score(img_path):
    """Görüntü kalite skoru hesaplama"""
    try:
        img = cv2.imread(img_path)
        if img is None:
            return 0
        
        # Gri tonlamaya çevir
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Laplacian variance (blur detection)
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        
        # Brightness
        brightness = np.mean(gray)
        
        # Contrast
        contrast = gray.std()
        
        # Histogram uniformity
        hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
        hist_uniformity = -np.sum((hist / hist.sum()) * np.log2((hist / hist.sum()) + 1e-7))
        
        # Quality score (0-100)
        quality_score = (
            min(laplacian_var / 100, 1.0) * 30 +  # Sharpness
            (1 - abs(brightness - 128) / 128) * 25 +  # Optimal brightness
            min(contrast / 50, 1.0) * 25 +  # Good contrast
            min(hist_uniformity / 8, 1.0) * 20  # Histogram diversity
        )
        
        return quality_score
        
    except Exception as e:
        return 0

def detect_pupil_features(img_path):
    """Pupil özelliklerini tespit et"""
    try:
        img = cv2.imread(img_path)
        if img is None:
            return {}
        
        # Gri tonlamaya çevir
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Gaussian blur
        blurred = cv2.GaussianBlur(gray, (15, 15), 0)
        
        # Threshold ile pupil bölgesini bul
        _, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        # Morfolojik işlemler
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        opened = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
        closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, kernel)
        
        # Konturları bul
        contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        features = {
            'pupil_area': 0,
            'pupil_perimeter': 0,
            'pupil_circularity': 0,
            'pupil_aspect_ratio': 1,
            'pupil_center_x': 0.5,
            'pupil_center_y': 0.5,
            'avg_intensity': np.mean(gray),
            'std_intensity': np.std(gray),
            'min_intensity': np.min(gray),
            'max_intensity': np.max(gray)
        }
        
        if contours:
            # En büyük konturu pupil olarak kabul et
            largest_contour = max(contours, key=cv2.contourArea)
            
            # Alan ve çevre
            area = cv2.contourArea(largest_contour)
            perimeter = cv2.arcLength(largest_contour, True)
            
            # Dairesellik (4π*area/perimeter²)
            if perimeter > 0:
                circularity = 4 * np.pi * area / (perimeter * perimeter)
            else:
                circularity = 0
            
            # Bounding rectangle
            x, y, w, h = cv2.boundingRect(largest_contour)
            aspect_ratio = float(w) / h if h > 0 else 1
            
            # Merkez koordinatları (normalize edilmiş)
            center_x = (x + w/2) / img.shape[1]
            center_y = (y + h/2) / img.shape[0]
            
            features.update({
                'pupil_area': area,
                'pupil_perimeter': perimeter,
                'pupil_circularity': circularity,
                'pupil_aspect_ratio': aspect_ratio,
                'pupil_center_x': center_x,
                'pupil_center_y': center_y
            })
        
        return features
        
    except Exception as e:
        return {
            'pupil_area': 0,
            'pupil_perimeter': 0,
            'pupil_circularity': 0,
            'pupil_aspect_ratio': 1,
            'pupil_center_x': 0.5,
            'pupil_center_y': 0.5,
            'avg_intensity': 128,
            'std_intensity': 50,
            'min_intensity': 0,
            'max_intensity': 255
        }

def extract_texture_features(img_path):
    """Doku özelliklerini çıkar"""
    try:
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            return {}
        
        # Resize for faster processing
        img_resized = cv2.resize(img, (64, 64))
        
        # GLCM (Gray Level Co-occurrence Matrix)
        distances = [1, 2, 3]
        angles = [0, 45, 90, 135]
        
        glcm_features = {}
        
        try:
            glcm = graycomatrix(img_resized, distances=distances, angles=angles, 
                            levels=256, symmetric=True, normed=True)
            
            # GLCM properties
            contrast = graycoprops(glcm, 'contrast').mean()
            dissimilarity = graycoprops(glcm, 'dissimilarity').mean()
            homogeneity = graycoprops(glcm, 'homogeneity').mean()
            energy = graycoprops(glcm, 'energy').mean()
            correlation = graycoprops(glcm, 'correlation').mean()
            
            glcm_features = {
                'glcm_contrast': contrast,
                'glcm_dissimilarity': dissimilarity,
                'glcm_homogeneity': homogeneity,
                'glcm_energy': energy,
                'glcm_correlation': correlation
            }
        except:
            glcm_features = {
                'glcm_contrast': 0,
                'glcm_dissimilarity': 0,
                'glcm_homogeneity': 0,
                'glcm_energy': 0,
                'glcm_correlation': 0
            }
        
        return glcm_features
        
    except Exception as e:
        return {
            'glcm_contrast': 0,
            'glcm_dissimilarity': 0,
            'glcm_homogeneity': 0,
            'glcm_energy': 0,
            'glcm_correlation': 0
        }

def load_and_clean_data():
    """Veri yükleme ve temizleme"""
    
    print("="*60)
    print("VERİ YÜKLEME VE TEMİZLEME")
    print("="*60)
    
    data_path = "/home/ubuntu/ms_oct_project/data/PUPШLLOGRAFШ HASTA VERШ"
    
    all_data = []
    
    # Kontrol grubu
    print("Kontrol grubu işleniyor...")
    kontrol_path = os.path.join(data_path, "kontrol grubu")
    kontrol_patients = [d for d in os.listdir(kontrol_path) if os.path.isdir(os.path.join(kontrol_path, d))]
    
    for i, patient in enumerate(kontrol_patients):
        print(f"Kontrol hasta {i+1}/{len(kontrol_patients)}: {patient}")
        patient_path = os.path.join(kontrol_path, patient)
        image_files = [f for f in os.listdir(patient_path) if f.endswith('.jpg')]
        
        for img_file in image_files:
            img_path = os.path.join(patient_path, img_file)
            
            # Kalite kontrolü
            quality_score = calculate_image_quality_score(img_path)
            
            # Düşük kaliteli görüntüleri filtrele
            if quality_score < 30:  # Threshold
                continue
            
            # Özellik çıkarımı
            pupil_features = detect_pupil_features(img_path)
            texture_features = extract_texture_features(img_path)
            
            # Veri kaydı
            data_entry = {
                'image_path': img_path,
                'patient': patient,
                'label': 0,  # Kontrol
                'quality_score': quality_score,
                **pupil_features,
                **texture_features
            }
            
            all_data.append(data_entry)
    
    # MS grubu
    print("MS grubu işleniyor...")
    ms_path = os.path.join(data_path, "ms grubu")
    ms_patients = [d for d in os.listdir(ms_path) if os.path.isdir(os.path.join(ms_path, d))]
    
    for i, patient in enumerate(ms_patients):
        print(f"MS hasta {i+1}/{len(ms_patients)}: {patient}")
        patient_path = os.path.join(ms_path, patient)
        image_files = [f for f in os.listdir(patient_path) if f.endswith('.jpg')]
        
        for img_file in image_files:
            img_path = os.path.join(patient_path, img_file)
            
            # Kalite kontrolü
            quality_score = calculate_image_quality_score(img_path)
            
            # Düşük kaliteli görüntüleri filtrele
            if quality_score < 30:  # Threshold
                continue
            
            # Özellik çıkarımı
            pupil_features = detect_pupil_features(img_path)
            texture_features = extract_texture_features(img_path)
            
            # Veri kaydı
            data_entry = {
                'image_path': img_path,
                'patient': patient,
                'label': 1,  # MS
                'quality_score': quality_score,
                **pupil_features,
                **texture_features
            }
            
            all_data.append(data_entry)
    
    # DataFrame oluştur
    df = pd.DataFrame(all_data)
    
    print(f"\nToplam temizlenmiş veri: {len(df)}")
    print(f"Kontrol grubu: {len(df[df['label'] == 0])}")
    print(f"MS grubu: {len(df[df['label'] == 1])}")
    
    # Outlier detection
    print("\nOutlier detection...")
    feature_columns = [col for col in df.columns if col not in ['image_path', 'patient', 'label']]
    
    # IQR method for outlier detection
    Q1 = df[feature_columns].quantile(0.25)
    Q3 = df[feature_columns].quantile(0.75)
    IQR = Q3 - Q1
    
    outlier_condition = ((df[feature_columns] < (Q1 - 1.5 * IQR)) | 
                        (df[feature_columns] > (Q3 + 1.5 * IQR))).any(axis=1)
    
    print(f"Outlier sayısı: {outlier_condition.sum()}")
    
    # Outlier'ları çıkar
    df_clean = df[~outlier_condition].copy()
    
    print(f"Outlier temizleme sonrası: {len(df_clean)}")
    print(f"Kontrol grubu: {len(df_clean[df_clean['label'] == 0])}")
    print(f"MS grubu: {len(df_clean[df_clean['label'] == 1])}")
    
    return df_clean

def create_hybrid_model(input_shape, feature_dim):
    """CNN + Traditional ML Hybrid Model"""
    
    # CNN branch
    cnn_input = Input(shape=input_shape, name='image_input')
    
    x = Conv2D(32, 3, activation='relu', padding='same')(cnn_input)
    x = BatchNormalization()(x)
    x = MaxPooling2D(2)(x)
    x = Dropout(0.25)(x)
    
    x = Conv2D(64, 3, activation='relu', padding='same')(x)
    x = BatchNormalization()(x)
    x = MaxPooling2D(2)(x)
    x = Dropout(0.25)(x)
    
    x = Conv2D(128, 3, activation='relu', padding='same')(x)
    x = BatchNormalization()(x)
    x = MaxPooling2D(2)(x)
    x = Dropout(0.25)(x)
    
    x = GlobalAveragePooling2D()(x)
    cnn_features = Dense(128, activation='relu')(x)
    cnn_features = Dropout(0.5)(cnn_features)
    
    # Feature branch
    feature_input = Input(shape=(feature_dim,), name='feature_input')
    feature_dense = Dense(64, activation='relu')(feature_input)
    feature_dense = Dropout(0.3)(feature_dense)
    feature_dense = Dense(32, activation='relu')(feature_dense)
    feature_dense = Dropout(0.2)(feature_dense)
    
    # Combine branches
    combined = Concatenate()([cnn_features, feature_dense])
    combined = Dense(128, activation='relu')(combined)
    combined = Dropout(0.5)(combined)
    combined = Dense(64, activation='relu')(combined)
    combined = Dropout(0.3)(combined)
    output = Dense(1, activation='sigmoid')(combined)
    
    model = Model(inputs=[cnn_input, feature_input], outputs=output)
    
    return model

def prepare_hybrid_data(df):
    """Hybrid model için veri hazırlama"""
    
    print("Hybrid model için veri hazırlanıyor...")
    
    # Görüntüleri yükle
    images = []
    for img_path in df['image_path']:
        try:
            img = load_img(img_path, target_size=IMG_SIZE)
            img_array = img_to_array(img) / 255.0
            images.append(img_array)
        except:
            # Hatalı görüntü için siyah görüntü
            images.append(np.zeros((IMG_SIZE[0], IMG_SIZE[1], 3)))
    
    X_images = np.array(images)
    
    # Özellik matrisi
    feature_columns = [col for col in df.columns if col not in ['image_path', 'patient', 'label']]
    X_features = df[feature_columns].values
    
    # Özellik normalizasyonu
    scaler = StandardScaler()
    X_features_scaled = scaler.fit_transform(X_features)
    
    # Etiketler
    y = df['label'].values
    
    print(f"Görüntü shape: {X_images.shape}")
    print(f"Özellik shape: {X_features_scaled.shape}")
    print(f"Etiket shape: {y.shape}")
    
    return X_images, X_features_scaled, y, scaler, feature_columns

def train_traditional_ml_models(X_features, y):
    """Geleneksel ML modelleri eğit"""
    
    print("\n" + "="*60)
    print("GELENEKSEL ML MODELLERİ")
    print("="*60)
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(
        X_features, y, test_size=0.2, random_state=42, stratify=y
    )
    
    models = {
        'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
        'Gradient Boosting': GradientBoostingClassifier(n_estimators=100, random_state=42),
        'SVM': SVC(probability=True, random_state=42),
        'Logistic Regression': LogisticRegression(random_state=42, max_iter=1000)
    }
    
    results = {}
    
    for name, model in models.items():
        print(f"\n{name} eğitiliyor...")
        
        # Cross-validation
        cv_scores = cross_val_score(model, X_train, y_train, cv=5, scoring='accuracy')
        
        # Final training
        model.fit(X_train, y_train)
        
        # Predictions
        y_pred = model.predict(X_test)
        y_pred_proba = model.predict_proba(X_test)[:, 1]
        
        # Metrics
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, zero_division=0)
        recall = recall_score(y_test, y_pred, zero_division=0)
        f1 = f1_score(y_test, y_pred, zero_division=0)
        auc = roc_auc_score(y_test, y_pred_proba)
        
        results[name] = {
            'model': model,
            'cv_mean': cv_scores.mean(),
            'cv_std': cv_scores.std(),
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'auc_score': auc
        }
        
        print(f"CV Accuracy: {cv_scores.mean():.4f} (±{cv_scores.std():.4f})")
        print(f"Test Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
        print(f"Precision: {precision:.4f} ({precision*100:.2f}%)")
        print(f"Recall: {recall:.4f} ({recall*100:.2f}%)")
        print(f"F1-Score: {f1:.4f} ({f1*100:.2f}%)")
        print(f"AUC: {auc:.4f} ({auc*100:.2f}%)")
    
    return results, X_test, y_test

def main():
    """Ana fonksiyon"""
    
    print("="*70)
    print("VERİ TEMİZLEME + FEATURE ENGİNEERİNG - %70+ HEDEF")
    print("="*70)
    
    # Klasörleri oluştur
    os.makedirs('/home/ubuntu/ms_oct_project/models', exist_ok=True)
    os.makedirs('/home/ubuntu/ms_oct_project/results', exist_ok=True)
    
    # Veri yükleme ve temizleme
    df_clean = load_and_clean_data()
    
    # Veri analizi
    print("\n" + "="*60)
    print("TEMİZLENMİŞ VERİ ANALİZİ")
    print("="*60)
    
    feature_columns = [col for col in df_clean.columns if col not in ['image_path', 'patient', 'label']]
    
    print(f"Toplam özellik sayısı: {len(feature_columns)}")
    print(f"Özellikler: {feature_columns}")
    
    # Korelasyon analizi
    corr_matrix = df_clean[feature_columns + ['label']].corr()
    label_corr = corr_matrix['label'].abs().sort_values(ascending=False)
    
    print("\nEn önemli özellikler (label ile korelasyon):")
    for feature, corr in label_corr.head(10).items():
        if feature != 'label':
            print(f"{feature}: {corr:.4f}")
    
    # Hybrid model için veri hazırlama
    X_images, X_features, y, scaler, feature_names = prepare_hybrid_data(df_clean)
    
    # Geleneksel ML modelleri
    ml_results, X_test_features, y_test = train_traditional_ml_models(X_features, y)
    
    # En iyi geleneksel model
    best_ml_model = max(ml_results.items(), key=lambda x: x[1]['accuracy'])
    print(f"\n🏆 EN İYİ GELENEKSEL MODEL: {best_ml_model[0]}")
    print(f"🎯 ACCURACY: {best_ml_model[1]['accuracy']*100:.2f}%")
    
    # Hybrid model eğitimi
    print("\n" + "="*60)
    print("HYBRID MODEL EĞİTİMİ")
    print("="*60)
    
    # Train-test split for hybrid model
    indices = np.arange(len(X_images))
    train_idx, test_idx = train_test_split(indices, test_size=0.2, random_state=42, stratify=y)
    
    X_img_train, X_img_test = X_images[train_idx], X_images[test_idx]
    X_feat_train, X_feat_test = X_features[train_idx], X_features[test_idx]
    y_train, y_test_hybrid = y[train_idx], y[test_idx]
    
    # Hybrid model oluştur
    hybrid_model = create_hybrid_model((IMG_SIZE[0], IMG_SIZE[1], 3), X_features.shape[1])
    
    # Compile
    hybrid_model.compile(
        optimizer=Adam(learning_rate=0.001),
        loss='binary_crossentropy',
        metrics=['accuracy', 'precision', 'recall']
    )
    
    print(f"Hybrid model parametreleri: {hybrid_model.count_params():,}")
    
    # Class weights
    class_weights = {
        0: len(y_train) / (2 * np.sum(y_train == 0)),
        1: len(y_train) / (2 * np.sum(y_train == 1))
    }
    
    # Callbacks
    callbacks = [
        ModelCheckpoint(
            '/home/ubuntu/ms_oct_project/models/best_hybrid_model.h5',
            monitor='val_accuracy',
            save_best_only=True,
            mode='max',
            verbose=1
        ),
        EarlyStopping(
            monitor='val_accuracy',
            patience=8,
            restore_best_weights=True,
            verbose=1
        ),
        ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=4,
            min_lr=1e-7,
            verbose=1
        )
    ]
    
    # Eğitim
    history = hybrid_model.fit(
        [X_img_train, X_feat_train], y_train,
        batch_size=BATCH_SIZE,
        epochs=EPOCHS,
        validation_split=0.2,
        callbacks=callbacks,
        class_weight=class_weights,
        verbose=1
    )
    
    # Hybrid model değerlendirme
    print("\nHybrid model değerlendiriliyor...")
    y_pred_proba = hybrid_model.predict([X_img_test, X_feat_test], batch_size=BATCH_SIZE)
    y_pred_proba = y_pred_proba.flatten()
    
    # Optimal threshold
    thresholds = np.arange(0.1, 0.9, 0.01)
    best_threshold = 0.5
    best_score = 0
    
    for threshold in thresholds:
        y_pred_temp = (y_pred_proba > threshold).astype(int)
        try:
            acc = accuracy_score(y_test_hybrid, y_pred_temp)
            f1 = f1_score(y_test_hybrid, y_pred_temp, zero_division=0)
            recall = recall_score(y_test_hybrid, y_pred_temp, zero_division=0)
            
            # Balanced score
            score = acc * 0.4 + f1 * 0.3 + recall * 0.3
            
            if score > best_score and recall >= 0.3:
                best_score = score
                best_threshold = threshold
        except:
            continue
    
    # Final predictions
    y_pred_hybrid = (y_pred_proba > best_threshold).astype(int)
    
    # Metrics
    hybrid_accuracy = accuracy_score(y_test_hybrid, y_pred_hybrid)
    hybrid_precision = precision_score(y_test_hybrid, y_pred_hybrid, zero_division=0)
    hybrid_recall = recall_score(y_test_hybrid, y_pred_hybrid, zero_division=0)
    hybrid_f1 = f1_score(y_test_hybrid, y_pred_hybrid, zero_division=0)
    hybrid_auc = roc_auc_score(y_test_hybrid, y_pred_proba)
    
    print(f"\nHybrid Model Sonuçları:")
    print(f"Accuracy: {hybrid_accuracy:.4f} ({hybrid_accuracy*100:.2f}%)")
    print(f"Precision: {hybrid_precision:.4f} ({hybrid_precision*100:.2f}%)")
    print(f"Recall: {hybrid_recall:.4f} ({hybrid_recall*100:.2f}%)")
    print(f"F1-Score: {hybrid_f1:.4f} ({hybrid_f1*100:.2f}%)")
    print(f"AUC: {hybrid_auc:.4f} ({hybrid_auc*100:.2f}%)")
    print(f"Optimal Threshold: {best_threshold:.3f}")
    
    # Final sonuçlar
    print("\n" + "="*70)
    print("FINAL SONUÇLAR")
    print("="*70)
    
    all_results = []
    
    # Geleneksel ML sonuçları
    for name, result in ml_results.items():
        all_results.append({
            'model_name': name,
            'accuracy': result['accuracy'],
            'precision': result['precision'],
            'recall': result['recall'],
            'f1_score': result['f1_score'],
            'auc_score': result['auc_score']
        })
    
    # Hybrid model sonucu
    all_results.append({
        'model_name': 'Hybrid CNN+ML',
        'accuracy': hybrid_accuracy,
        'precision': hybrid_precision,
        'recall': hybrid_recall,
        'f1_score': hybrid_f1,
        'auc_score': hybrid_auc
    })
    
    # En iyi model
    best_result = max(all_results, key=lambda x: x['accuracy'])
    
    print(f"\n🏆 EN İYİ MODEL: {best_result['model_name']}")
    print(f"🎯 EN İYİ ACCURACY: {best_result['accuracy']*100:.2f}%")
    
    # Baseline karşılaştırması
    baseline_accuracy = 0.6480  # Önceki en iyi sonuç
    improvement = best_result['accuracy'] - baseline_accuracy
    
    print(f"📊 BASELINE: {baseline_accuracy*100:.2f}%")
    print(f"📈 İYİLEŞME: {improvement*100:+.2f}%")
    
    if best_result['accuracy'] >= 0.70:
        print("🎉 HEDEF BAŞARILDI! %70+ accuracy elde edildi!")
    elif best_result['accuracy'] >= 0.67:
        print("✅ ÇOK İYİ SONUÇ! Hedefe çok yakın!")
    elif improvement > 0:
        print("📈 İYİLEŞME VAR! Doğru yöndeyiz!")
    else:
        print("📊 Baseline seviyesinde.")
    
    # Sonuçları kaydet
    with open('/home/ubuntu/ms_oct_project/results/feature_engineering_results.pkl', 'wb') as f:
        pickle.dump({
            'all_results': all_results,
            'best_result': best_result,
            'ml_results': ml_results,
            'hybrid_result': {
                'accuracy': hybrid_accuracy,
                'precision': hybrid_precision,
                'recall': hybrid_recall,
                'f1_score': hybrid_f1,
                'auc_score': hybrid_auc,
                'threshold': best_threshold
            },
            'feature_names': feature_names,
            'scaler': scaler,
            'cleaned_data': df_clean
        }, f)
    
    print(f"\n✅ Tüm sonuçlar kaydedildi!")
    
    return all_results, best_result

if __name__ == "__main__":
    results, best_result = main()

