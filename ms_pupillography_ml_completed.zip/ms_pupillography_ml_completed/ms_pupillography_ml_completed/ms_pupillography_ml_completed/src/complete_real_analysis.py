#!/usr/bin/env python3
"""
MS OCT Project - Complete Real Analysis
Train Random Forest on real data and create complete package
"""

import os
import numpy as np
import pandas as pd
import cv2
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix, roc_auc_score, roc_curve, precision_recall_curve
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import FancyBboxPatch, ConnectionPatch
import warnings
warnings.filterwarnings('ignore')

print("🎯 MS OCT COMPLETE REAL ANALYSIS")
print("=" * 60)

# Paths
data_dir = "/home/ubuntu/upload/pupillografi_hasta_veri/pupillografi_hasta_veri"
output_dir = "/home/ubuntu/ms_oct_project/complete_real_package"
charts_dir = os.path.join(output_dir, "charts")
tables_dir = os.path.join(output_dir, "tables")
models_dir = os.path.join(output_dir, "models")
scripts_dir = os.path.join(output_dir, "scripts")

# Create directories
for dir_path in [output_dir, charts_dir, tables_dir, models_dir, scripts_dir]:
    os.makedirs(dir_path, exist_ok=True)

def extract_features(image_path):
    """Extract 22 features from image"""
    try:
        # Load and preprocess image
        img = cv2.imread(image_path)
        if img is None:
            return None
        
        img_resized = cv2.resize(img, (400, 200))
        gray = cv2.cvtColor(img_resized, cv2.COLOR_BGR2GRAY)
        
        features = []
        
        # 1. Basic statistics (5 features)
        features.extend([
            np.mean(gray),           # mean_intensity
            np.std(gray),            # std_intensity
            np.min(gray),            # min_intensity
            np.max(gray),            # max_intensity
            np.max(gray) - np.min(gray)  # intensity_range
        ])
        
        # 2. Pupil analysis (6 features)
        circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1, 20,
                                  param1=50, param2=30, minRadius=10, maxRadius=100)
        
        if circles is not None:
            circles = np.round(circles[0, :]).astype("int")
            x, y, r = circles[0]
            features.extend([
                1,                           # pupil_detected
                r / max(gray.shape),         # pupil_radius (normalized)
                x / gray.shape[1],           # pupil_x_norm
                y / gray.shape[0],           # pupil_y_norm
                np.mean(gray[max(0, y-r):min(gray.shape[0], y+r), 
                            max(0, x-r):min(gray.shape[1], x+r)]),  # pupil_mean_intensity
                np.std(gray[max(0, y-r):min(gray.shape[0], y+r), 
                           max(0, x-r):min(gray.shape[1], x+r)])    # pupil_std_intensity
            ])
        else:
            features.extend([0, 0, 0.5, 0.5, np.mean(gray), np.std(gray)])
        
        # 3. Texture analysis (4 features)
        sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        gradient = np.sqrt(sobelx**2 + sobely**2)
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        
        features.extend([
            np.mean(gradient),       # gradient_mean
            np.std(gradient),        # gradient_std
            np.var(laplacian),       # laplacian_variance
            np.var(sobelx + sobely)  # sobel_variance
        ])
        
        # 4. Histogram features (3 features)
        hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
        hist = hist.flatten()
        hist = hist / np.sum(hist)  # normalize
        
        features.extend([
            np.argmax(hist),         # hist_peak
            -np.sum(hist * np.log(hist + 1e-10)),  # hist_entropy
            np.sum(hist**2)          # hist_uniformity
        ])
        
        # 5. Regional analysis (4 features)
        h, w = gray.shape
        quad_0 = gray[:h//2, :w//2]      # top-left
        quad_1 = gray[:h//2, w//2:]      # top-right
        quad_2 = gray[h//2:, :w//2]      # bottom-left
        quad_3 = gray[h//2:, w//2:]      # bottom-right
        
        features.extend([
            np.mean(quad_0),         # quad_0_mean
            np.mean(quad_1),         # quad_1_mean
            np.mean(quad_2),         # quad_2_mean
            np.mean(quad_3)          # quad_3_mean
        ])
        
        return np.array(features)
        
    except Exception as e:
        print(f"Error processing {image_path}: {e}")
        return None

def load_and_process_data():
    """Load and process all images"""
    print("📂 Loading and processing images...")
    
    X = []
    y = []
    
    # Load control group
    control_dir = os.path.join(data_dir, "kontrol_grubu")
    control_count = 0
    print(f"   Processing control group...")
    for patient_folder in os.listdir(control_dir):
        patient_path = os.path.join(control_dir, patient_folder)
        if os.path.isdir(patient_path):
            for img_file in os.listdir(patient_path):
                if img_file.lower().endswith(('.jpg', '.jpeg', '.png')):
                    img_path = os.path.join(patient_path, img_file)
                    features = extract_features(img_path)
                    if features is not None:
                        X.append(features)
                        y.append(0)  # Control = 0
                        control_count += 1
    
    # Load MS group
    ms_dir = os.path.join(data_dir, "ms_grubu")
    ms_count = 0
    print(f"   Processing MS group...")
    for patient_folder in os.listdir(ms_dir):
        patient_path = os.path.join(ms_dir, patient_folder)
        if os.path.isdir(patient_path):
            for img_file in os.listdir(patient_path):
                if img_file.lower().endswith(('.jpg', '.jpeg', '.png')):
                    img_path = os.path.join(patient_path, img_file)
                    features = extract_features(img_path)
                    if features is not None:
                        X.append(features)
                        y.append(1)  # MS = 1
                        ms_count += 1
    
    print(f"   ✅ Control images: {control_count}")
    print(f"   ✅ MS images: {ms_count}")
    print(f"   ✅ Total images: {len(X)}")
    
    return np.array(X), np.array(y), control_count, ms_count

def train_model(X, y):
    """Train Random Forest model with exact parameters"""
    print("🤖 Training Random Forest model...")
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train Random Forest with exact parameters
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        min_samples_split=5,
        min_samples_leaf=3,
        class_weight='balanced',
        random_state=42,
        n_jobs=-1
    )
    
    model.fit(X_train_scaled, y_train)
    
    # Predict
    y_pred = model.predict(X_test_scaled)
    y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]
    
    # Calculate metrics
    accuracy = accuracy_score(y_test, y_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(y_test, y_pred, average=None)
    cm = confusion_matrix(y_test, y_pred)
    auc_roc = roc_auc_score(y_test, y_pred_proba)
    
    # Get curves
    fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
    precision_curve, recall_curve, _ = precision_recall_curve(y_test, y_pred_proba)
    auc_pr = np.trapz(precision_curve, recall_curve)
    
    print(f"   ✅ Training completed!")
    print(f"   ✅ Test Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"   ✅ AUC-ROC: {auc_roc:.4f}")
    print(f"   ✅ Confusion Matrix:")
    print(f"      [[{cm[0,0]:3d} {cm[0,1]:3d}]")
    print(f"       [{cm[1,0]:3d} {cm[1,1]:3d}]]")
    
    # Save model and scaler
    with open(os.path.join(models_dir, 'ms_detection_model.pkl'), 'wb') as f:
        pickle.dump(model, f)
    
    with open(os.path.join(models_dir, 'feature_scaler.pkl'), 'wb') as f:
        pickle.dump(scaler, f)
    
    results = {
        'accuracy': accuracy,
        'precision_control': precision[0],
        'recall_control': recall[0],
        'precision_ms': precision[1],
        'recall_ms': recall[1],
        'f1_control': f1[0],
        'f1_ms': f1[1],
        'auc_roc': auc_roc,
        'auc_pr': auc_pr,
        'confusion_matrix': cm,
        'fpr': fpr,
        'tpr': tpr,
        'precision_curve': precision_curve,
        'recall_curve': recall_curve,
        'feature_importance': model.feature_importances_,
        'test_size': len(y_test),
        'control_test': np.sum(y_test == 0),
        'ms_test': np.sum(y_test == 1)
    }
    
    return results

def create_titleless_charts(results, total_control, total_ms):
    """Create all charts without titles"""
    print("📊 Creating title-less charts...")
    
    plt.style.use('default')
    
    # 1. Performance Metrics (NO TITLE)
    plt.figure(figsize=(12, 8))
    metrics_names = ['Accuracy', 'Precision\\n(Control)', 'Recall\\n(Control)', 
                    'Precision\\n(MS)', 'Recall\\n(MS)', 'F1-Score\\n(Control)', 'F1-Score\\n(MS)', 'AUC-ROC']
    metrics_values = [
        results['accuracy'], results['precision_control'], results['recall_control'],
        results['precision_ms'], results['recall_ms'], results['f1_control'],
        results['f1_ms'], results['auc_roc']
    ]
    
    colors = ['green' if v >= 0.7 else 'orange' if v >= 0.6 else 'red' for v in metrics_values]
    bars = plt.bar(metrics_names, metrics_values, color=colors, alpha=0.8)
    
    for bar, value in zip(bars, metrics_values):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                f'{value:.3f}', ha='center', va='bottom', fontweight='bold')
    
    plt.ylim(0, 1.1)
    plt.ylabel('Score', fontsize=12)
    plt.axhline(y=0.7, color='red', linestyle='--', alpha=0.7, label='Target (70%)')
    plt.xticks(rotation=45)
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'performance_metrics.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 2. ROC Curve (NO TITLE)
    plt.figure(figsize=(10, 8))
    plt.plot(results['fpr'], results['tpr'], color='darkorange', lw=2, 
             label=f'ROC Curve (AUC = {results["auc_roc"]:.3f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random Classifier')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate', fontsize=12)
    plt.ylabel('True Positive Rate', fontsize=12)
    plt.legend(loc="lower right")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'roc_curve.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 3. Precision-Recall Curve (NO TITLE)
    plt.figure(figsize=(10, 8))
    plt.plot(results['recall_curve'], results['precision_curve'], color='blue', lw=2, 
             label=f'PR Curve (AUC = {results["auc_pr"]:.3f})')
    plt.xlabel('Recall', fontsize=12)
    plt.ylabel('Precision', fontsize=12)
    plt.legend(loc="lower left")
    plt.grid(True, alpha=0.3)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'precision_recall_curve.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 4. Confusion Matrix (NO TITLE)
    plt.figure(figsize=(8, 6))
    cm = results['confusion_matrix']
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['Control', 'MS'], yticklabels=['Control', 'MS'])
    plt.xlabel('Predicted Label', fontsize=12)
    plt.ylabel('True Label', fontsize=12)
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'confusion_matrix.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 5. Feature Importance (NO TITLE)
    plt.figure(figsize=(12, 10))
    feature_names = [
        'mean_intensity', 'std_intensity', 'min_intensity', 'max_intensity', 'intensity_range',
        'pupil_detected', 'pupil_radius', 'pupil_x_norm', 'pupil_y_norm', 'pupil_mean_intensity', 'pupil_std_intensity',
        'gradient_mean', 'gradient_std', 'laplacian_variance', 'sobel_variance',
        'hist_peak', 'hist_entropy', 'hist_uniformity',
        'quad_0_mean', 'quad_1_mean', 'quad_2_mean', 'quad_3_mean'
    ]
    
    importance = results['feature_importance']
    sorted_idx = np.argsort(importance)[::-1][:15]  # Top 15 features
    
    plt.barh(range(len(sorted_idx)), importance[sorted_idx], color='skyblue')
    plt.yticks(range(len(sorted_idx)), [feature_names[i] for i in sorted_idx])
    plt.xlabel('Feature Importance', fontsize=12)
    plt.gca().invert_yaxis()
    plt.grid(True, alpha=0.3, axis='x')
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'feature_importance.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 6. Class Distribution (NO TITLE)
    plt.figure(figsize=(8, 6))
    class_counts = [total_control, total_ms]
    plt.pie(class_counts, labels=['Control', 'MS'], autopct='%1.1f%%', 
            startangle=90, colors=['lightblue', 'lightcoral'])
    plt.axis('equal')
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'class_distribution.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"   ✅ 6 title-less charts created")

def main():
    """Main execution"""
    try:
        # Load and process data
        X, y, control_count, ms_count = load_and_process_data()
        
        # Train model
        results = train_model(X, y)
        
        # Create charts
        create_titleless_charts(results, control_count, ms_count)
        
        print("\n🎉 COMPLETE REAL ANALYSIS FINISHED!")
        print("=" * 60)
        print(f"📊 Final Results:")
        print(f"   - Real Accuracy: {results['accuracy']*100:.2f}%")
        print(f"   - Real AUC-ROC: {results['auc_roc']:.3f}")
        print(f"   - Total Images: {len(X)}")
        print(f"   - Control Images: {control_count}")
        print(f"   - MS Images: {ms_count}")
        print(f"   - Test Set Size: {results['test_size']}")
        print(f"   - Real Confusion Matrix:")
        cm = results['confusion_matrix']
        print(f"     Control: TN={cm[0,0]}, FP={cm[0,1]}")
        print(f"     MS: FN={cm[1,0]}, TP={cm[1,1]}")
        
        return results
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    results = main()

