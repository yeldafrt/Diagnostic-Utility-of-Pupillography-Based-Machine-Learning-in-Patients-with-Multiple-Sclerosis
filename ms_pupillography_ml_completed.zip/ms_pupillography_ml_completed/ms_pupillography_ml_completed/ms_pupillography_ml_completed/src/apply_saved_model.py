#!/usr/bin/env python3
"""
MS OCT Project - Apply Saved Model to Real Data
Load the saved model and apply it to the actual dataset to get real results
"""

import os
import numpy as np
import pandas as pd
import cv2
import pickle
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix, roc_auc_score, roc_curve, precision_recall_curve
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import FancyBboxPatch, ConnectionPatch
import warnings
warnings.filterwarnings('ignore')

print("🎯 APPLYING SAVED MODEL TO REAL DATA")
print("=" * 60)

# Paths
data_dir = "/home/ubuntu/upload/pupillografi_hasta_veri/pupillografi_hasta_veri"
model_path = "/home/ubuntu/ms_oct_project/models/lightweight_rf_model.pkl"
scaler_path = "/home/ubuntu/ms_oct_project/models/lightweight_scaler.pkl"

# Create output directories
output_dir = "/home/ubuntu/ms_oct_project/real_results_package"
charts_dir = os.path.join(output_dir, "charts")
tables_dir = os.path.join(output_dir, "tables")
models_dir = os.path.join(output_dir, "models")
scripts_dir = os.path.join(output_dir, "scripts")

for dir_path in [output_dir, charts_dir, tables_dir, models_dir, scripts_dir]:
    os.makedirs(dir_path, exist_ok=True)

def extract_features(image_path):
    """Extract 22 features from image (same as training)"""
    try:
        # Load and preprocess image
        img = cv2.imread(image_path)
        if img is None:
            return None
        
        img_resized = cv2.resize(img, (400, 200))
        gray = cv2.cvtColor(img_resized, cv2.COLOR_BGR2GRAY)
        
        features = []
        
        # 1. Basic statistics (5 features)
        features.extend([
            np.mean(gray),           # mean_intensity
            np.std(gray),            # std_intensity
            np.min(gray),            # min_intensity
            np.max(gray),            # max_intensity
            np.max(gray) - np.min(gray)  # intensity_range
        ])
        
        # 2. Pupil analysis (6 features)
        circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1, 20,
                                  param1=50, param2=30, minRadius=10, maxRadius=100)
        
        if circles is not None:
            circles = np.round(circles[0, :]).astype("int")
            x, y, r = circles[0]
            features.extend([
                1,                           # pupil_detected
                r / max(gray.shape),         # pupil_radius (normalized)
                x / gray.shape[1],           # pupil_x_norm
                y / gray.shape[0],           # pupil_y_norm
                np.mean(gray[max(0, y-r):min(gray.shape[0], y+r), 
                            max(0, x-r):min(gray.shape[1], x+r)]),  # pupil_mean_intensity
                np.std(gray[max(0, y-r):min(gray.shape[0], y+r), 
                           max(0, x-r):min(gray.shape[1], x+r)])    # pupil_std_intensity
            ])
        else:
            features.extend([0, 0, 0.5, 0.5, np.mean(gray), np.std(gray)])
        
        # 3. Texture analysis (4 features)
        sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        gradient = np.sqrt(sobelx**2 + sobely**2)
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        
        features.extend([
            np.mean(gradient),       # gradient_mean
            np.std(gradient),        # gradient_std
            np.var(laplacian),       # laplacian_variance
            np.var(sobelx + sobely)  # sobel_variance
        ])
        
        # 4. Histogram features (3 features)
        hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
        hist = hist.flatten()
        hist = hist / np.sum(hist)  # normalize
        
        features.extend([
            np.argmax(hist),         # hist_peak
            -np.sum(hist * np.log(hist + 1e-10)),  # hist_entropy
            np.sum(hist**2)          # hist_uniformity
        ])
        
        # 5. Regional analysis (4 features)
        h, w = gray.shape
        quad_0 = gray[:h//2, :w//2]      # top-left
        quad_1 = gray[:h//2, w//2:]      # top-right
        quad_2 = gray[h//2:, :w//2]      # bottom-left
        quad_3 = gray[h//2:, w//2:]      # bottom-right
        
        features.extend([
            np.mean(quad_0),         # quad_0_mean
            np.mean(quad_1),         # quad_1_mean
            np.mean(quad_2),         # quad_2_mean
            np.mean(quad_3)          # quad_3_mean
        ])
        
        return np.array(features)
        
    except Exception as e:
        print(f"Error processing {image_path}: {e}")
        return None

def load_data():
    """Load and process all images"""
    print("📂 Loading and processing images...")
    
    X = []
    y = []
    image_paths = []
    
    # Load control group
    control_dir = os.path.join(data_dir, "kontrol_grubu")
    control_count = 0
    for patient_folder in os.listdir(control_dir):
        patient_path = os.path.join(control_dir, patient_folder)
        if os.path.isdir(patient_path):
            for img_file in os.listdir(patient_path):
                if img_file.lower().endswith(('.jpg', '.jpeg', '.png')):
                    img_path = os.path.join(patient_path, img_file)
                    features = extract_features(img_path)
                    if features is not None:
                        X.append(features)
                        y.append(0)  # Control = 0
                        image_paths.append(img_path)
                        control_count += 1
    
    # Load MS group
    ms_dir = os.path.join(data_dir, "ms_grubu")
    ms_count = 0
    for patient_folder in os.listdir(ms_dir):
        patient_path = os.path.join(ms_dir, patient_folder)
        if os.path.isdir(patient_path):
            for img_file in os.listdir(patient_path):
                if img_file.lower().endswith(('.jpg', '.jpeg', '.png')):
                    img_path = os.path.join(patient_path, img_file)
                    features = extract_features(img_path)
                    if features is not None:
                        X.append(features)
                        y.append(1)  # MS = 1
                        image_paths.append(img_path)
                        ms_count += 1
    
    print(f"   ✅ Control images: {control_count}")
    print(f"   ✅ MS images: {ms_count}")
    print(f"   ✅ Total images: {len(X)}")
    
    return np.array(X), np.array(y), image_paths

def apply_saved_model():
    """Apply the saved model to get real results"""
    print("🤖 Loading saved model and applying to data...")
    
    # Load data
    X, y, image_paths = load_data()
    
    # Load saved model and scaler
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
    
    with open(scaler_path, 'rb') as f:
        scaler = pickle.load(f)
    
    # Apply scaler and predict
    X_scaled = scaler.transform(X)
    y_pred = model.predict(X_scaled)
    y_pred_proba = model.predict_proba(X_scaled)[:, 1]
    
    # Calculate metrics
    accuracy = accuracy_score(y, y_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(y, y_pred, average=None)
    cm = confusion_matrix(y, y_pred)
    auc_roc = roc_auc_score(y, y_pred_proba)
    
    # Get ROC and PR curves
    fpr, tpr, _ = roc_curve(y, y_pred_proba)
    precision_curve, recall_curve, _ = precision_recall_curve(y, y_pred_proba)
    auc_pr = np.trapz(precision_curve, recall_curve)
    
    print(f"   ✅ Real Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"   ✅ Real AUC-ROC: {auc_roc:.4f}")
    print(f"   ✅ Real Confusion Matrix:")
    print(f"      Control: {cm[0]} (TN={cm[0,0]}, FP={cm[0,1]})")
    print(f"      MS: {cm[1]} (FN={cm[1,0]}, TP={cm[1,1]})")
    
    results = {
        'accuracy': accuracy,
        'precision_control': precision[0],
        'recall_control': recall[0],
        'precision_ms': precision[1],
        'recall_ms': recall[1],
        'f1_control': f1[0],
        'f1_ms': f1[1],
        'auc_roc': auc_roc,
        'auc_pr': auc_pr,
        'confusion_matrix': cm,
        'fpr': fpr,
        'tpr': tpr,
        'precision_curve': precision_curve,
        'recall_curve': recall_curve,
        'total_images': len(X),
        'control_images': np.sum(y == 0),
        'ms_images': np.sum(y == 1)
    }
    
    return results

def create_titleless_charts(results):
    """Create all charts without titles"""
    print("📊 Creating title-less charts...")
    
    plt.style.use('default')
    
    # 1. Performance Metrics (NO TITLE)
    plt.figure(figsize=(12, 8))
    metrics_names = ['Accuracy', 'Precision\\n(Control)', 'Recall\\n(Control)', 
                    'Precision\\n(MS)', 'Recall\\n(MS)', 'F1-Score\\n(Control)', 'F1-Score\\n(MS)', 'AUC-ROC']
    metrics_values = [
        results['accuracy'],
        results['precision_control'],
        results['recall_control'],
        results['precision_ms'],
        results['recall_ms'],
        results['f1_control'],
        results['f1_ms'],
        results['auc_roc']
    ]
    
    colors = ['green' if v >= 0.7 else 'orange' if v >= 0.6 else 'red' for v in metrics_values]
    bars = plt.bar(metrics_names, metrics_values, color=colors, alpha=0.8)
    
    for bar, value in zip(bars, metrics_values):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                f'{value:.3f}', ha='center', va='bottom', fontweight='bold')
    
    plt.ylim(0, 1.1)
    plt.ylabel('Score', fontsize=12)
    plt.axhline(y=0.7, color='red', linestyle='--', alpha=0.7, label='Target (70%)')
    plt.xticks(rotation=45)
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'performance_metrics.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 2. ROC Curve (NO TITLE)
    plt.figure(figsize=(10, 8))
    plt.plot(results['fpr'], results['tpr'], color='darkorange', lw=2, 
             label=f'ROC Curve (AUC = {results["auc_roc"]:.3f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random Classifier')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate', fontsize=12)
    plt.ylabel('True Positive Rate', fontsize=12)
    plt.legend(loc="lower right")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'roc_curve.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 3. Precision-Recall Curve (NO TITLE)
    plt.figure(figsize=(10, 8))
    plt.plot(results['recall_curve'], results['precision_curve'], color='blue', lw=2, 
             label=f'PR Curve (AUC = {results["auc_pr"]:.3f})')
    plt.xlabel('Recall', fontsize=12)
    plt.ylabel('Precision', fontsize=12)
    plt.legend(loc="lower left")
    plt.grid(True, alpha=0.3)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'precision_recall_curve.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 4. Confusion Matrix (NO TITLE)
    plt.figure(figsize=(8, 6))
    cm = results['confusion_matrix']
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['Control', 'MS'], yticklabels=['Control', 'MS'])
    plt.xlabel('Predicted Label', fontsize=12)
    plt.ylabel('True Label', fontsize=12)
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'confusion_matrix.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 5. Feature Importance (NO TITLE) - Use model feature importance
    plt.figure(figsize=(12, 10))
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
    
    feature_names = [
        'mean_intensity', 'std_intensity', 'min_intensity', 'max_intensity', 'intensity_range',
        'pupil_detected', 'pupil_radius', 'pupil_x_norm', 'pupil_y_norm', 'pupil_mean_intensity', 'pupil_std_intensity',
        'gradient_mean', 'gradient_std', 'laplacian_variance', 'sobel_variance',
        'hist_peak', 'hist_entropy', 'hist_uniformity',
        'quad_0_mean', 'quad_1_mean', 'quad_2_mean', 'quad_3_mean'
    ]
    
    importance = model.feature_importances_
    sorted_idx = np.argsort(importance)[::-1][:15]  # Top 15 features
    
    plt.barh(range(len(sorted_idx)), importance[sorted_idx], color='skyblue')
    plt.yticks(range(len(sorted_idx)), [feature_names[i] for i in sorted_idx])
    plt.xlabel('Feature Importance', fontsize=12)
    plt.gca().invert_yaxis()
    plt.grid(True, alpha=0.3, axis='x')
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'feature_importance.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 6. Class Distribution (NO TITLE)
    plt.figure(figsize=(8, 6))
    class_counts = [results['control_images'], results['ms_images']]
    plt.pie(class_counts, labels=['Control', 'MS'], autopct='%1.1f%%', 
            startangle=90, colors=['lightblue', 'lightcoral'])
    plt.axis('equal')
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'class_distribution.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"   ✅ 6 title-less charts created")

def create_architecture_diagrams():
    """Create architecture diagrams without titles"""
    print("🏗️ Creating title-less architecture diagrams...")
    
    # 1. Random Forest Architecture (NO TITLE)
    fig, ax = plt.subplots(figsize=(14, 10))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 10)
    ax.axis('off')
    
    # Input features
    input_box = FancyBboxPatch((1, 8), 2, 0.8, boxstyle="round,pad=0.1", 
                               facecolor='lightblue', edgecolor='black', linewidth=2)
    ax.add_patch(input_box)
    ax.text(2, 8.4, 'Input Features\\n(22 features)', fontsize=10, ha='center', va='center', fontweight='bold')
    
    # Feature scaling
    scaler_box = FancyBboxPatch((5, 8), 2, 0.8, boxstyle="round,pad=0.1", 
                                facecolor='lightgreen', edgecolor='black', linewidth=2)
    ax.add_patch(scaler_box)
    ax.text(6, 8.4, 'StandardScaler\\nNormalization', fontsize=10, ha='center', va='center', fontweight='bold')
    
    # Random Forest trees
    forest_y_positions = np.linspace(5.5, 6.5, 5)
    forest_x_positions = np.linspace(2, 12, 5)
    
    for i, (x, y) in enumerate(zip(forest_x_positions, forest_y_positions)):
        if i < 3:
            tree_box = FancyBboxPatch((x-0.4, y-0.3), 0.8, 0.6, boxstyle="round,pad=0.05", 
                                     facecolor='lightcoral', edgecolor='darkred', linewidth=1)
            ax.add_patch(tree_box)
            ax.text(x, y, f'Tree {i+1}', fontsize=8, ha='center', va='center', fontweight='bold')
        elif i == 3:
            ax.text(x, y, '...', fontsize=16, ha='center', va='center', fontweight='bold')
        else:
            tree_box = FancyBboxPatch((x-0.4, y-0.3), 0.8, 0.6, boxstyle="round,pad=0.05", 
                                     facecolor='lightcoral', edgecolor='darkred', linewidth=1)
            ax.add_patch(tree_box)
            ax.text(x, y, 'Tree 100', fontsize=8, ha='center', va='center', fontweight='bold')
    
    ax.text(7, 7.2, 'Random Forest Ensemble (100 Decision Trees)', fontsize=12, ha='center', fontweight='bold')
    
    # Voting and output
    voting_box = FancyBboxPatch((5.5, 4), 3, 0.8, boxstyle="round,pad=0.1", 
                                facecolor='gold', edgecolor='orange', linewidth=2)
    ax.add_patch(voting_box)
    ax.text(7, 4.4, 'Majority Voting\\n(Ensemble Decision)', fontsize=10, ha='center', va='center', fontweight='bold')
    
    output_box = FancyBboxPatch((5.5, 2), 3, 0.8, boxstyle="round,pad=0.1", 
                                facecolor='lightpink', edgecolor='purple', linewidth=2)
    ax.add_patch(output_box)
    ax.text(7, 2.4, 'Final Prediction\\n(Control / MS)', fontsize=10, ha='center', va='center', fontweight='bold')
    
    # Add arrows
    arrows = [
        ((3, 8.4), (5, 8.4)),
        ((7, 8), (7, 7.2)),
        ((7, 5.5), (7, 4.8)),
        ((7, 4), (7, 2.8))
    ]
    
    for start, end in arrows:
        arrow = ConnectionPatch(start, end, "data", "data", 
                               arrowstyle="->", shrinkA=5, shrinkB=5, 
                               mutation_scale=20, fc="black")
        ax.add_artist(arrow)
    
    # Model parameters
    params_text = """Model Parameters:
• n_estimators: 100
• max_depth: 10
• min_samples_split: 5
• min_samples_leaf: 3
• class_weight: balanced
• random_state: 42"""
    
    ax.text(0.5, 3.5, params_text, fontsize=9, va='top', 
            bbox=dict(boxstyle="round,pad=0.3", facecolor='lightyellow', edgecolor='gray'))
    
    plt.tight_layout()
    plt.savefig(os.path.join(charts_dir, 'random_forest_architecture.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"   ✅ Architecture diagrams created")

def create_tables(results):
    """Create English tables with real results"""
    print("📋 Creating English tables...")
    
    # 1. Performance Metrics Table
    performance_table = pd.DataFrame({
        'Metric': ['Accuracy', 'Precision (Control)', 'Recall (Control)', 
                  'Precision (MS)', 'Recall (MS)', 'F1-Score (Control)', 'F1-Score (MS)', 'AUC-ROC', 'AUC-PR'],
        'Value': [
            results['accuracy'], results['precision_control'], results['recall_control'],
            results['precision_ms'], results['recall_ms'], results['f1_control'],
            results['f1_ms'], results['auc_roc'], results['auc_pr']
        ],
        'Percentage': [
            f"{results['accuracy']*100:.2f}%", f"{results['precision_control']*100:.2f}%",
            f"{results['recall_control']*100:.2f}%", f"{results['precision_ms']*100:.2f}%",
            f"{results['recall_ms']*100:.2f}%", f"{results['f1_control']*100:.2f}%",
            f"{results['f1_ms']*100:.2f}%", f"{results['auc_roc']*100:.2f}%", f"{results['auc_pr']*100:.2f}%"
        ]
    })
    performance_table.to_csv(os.path.join(tables_dir, 'performance_metrics.csv'), index=False)
    
    # 2. Dataset Information
    # Count patients
    control_patients = len(os.listdir(os.path.join(data_dir, "kontrol_grubu")))
    ms_patients = len(os.listdir(os.path.join(data_dir, "ms_grubu")))
    
    dataset_info = pd.DataFrame({
        'Dataset_Info': ['Total Patients', 'Control Patients', 'MS Patients', 
                        'Total Images', 'Control Images', 'MS Images'],
        'Value': [str(control_patients + ms_patients), str(control_patients), str(ms_patients),
                 str(results['total_images']), str(results['control_images']), str(results['ms_images'])]
    })
    dataset_info.to_csv(os.path.join(tables_dir, 'dataset_information.csv'), index=False)
    
    # 3. Confusion Matrix Table
    cm = results['confusion_matrix']
    confusion_table = pd.DataFrame({
        'Predicted': ['Control', 'Control', 'MS', 'MS'],
        'Actual': ['Control', 'MS', 'Control', 'MS'],
        'Count': [cm[0,0], cm[1,0], cm[0,1], cm[1,1]],
        'Type': ['True Negative', 'False Negative', 'False Positive', 'True Positive']
    })
    confusion_table.to_csv(os.path.join(tables_dir, 'confusion_matrix.csv'), index=False)
    
    # 4. Model Summary
    model_summary = pd.DataFrame({
        'Parameter': ['Algorithm', 'Number of Features', 'Total Patients', 'Total Images',
                     'Control Images', 'MS Images', 'Random State'],
        'Value': ['Random Forest', '22', f'{control_patients + ms_patients} ({control_patients} Control + {ms_patients} MS)', 
                 str(results['total_images']), str(results['control_images']), str(results['ms_images']), '42']
    })
    model_summary.to_csv(os.path.join(tables_dir, 'model_summary.csv'), index=False)
    
    print(f"   ✅ 4 English tables created")

def copy_files():
    """Copy model and script files"""
    print("📁 Copying model and script files...")
    
    import shutil
    
    # Copy model files
    shutil.copy(model_path, os.path.join(models_dir, 'ms_detection_model.pkl'))
    shutil.copy(scaler_path, os.path.join(models_dir, 'feature_scaler.pkl'))
    
    # Copy script files
    script_files = [
        '/home/ubuntu/ms_oct_project/scripts/lightweight_analysis.py',
        '/home/ubuntu/ms_oct_project/scripts/correct_package_generator.py',
        '/home/ubuntu/ms_oct_project/scripts/add_pr_curve.py',
        '/home/ubuntu/ms_oct_project/scripts/create_architecture_diagrams.py'
    ]
    
    for script_file in script_files:
        if os.path.exists(script_file):
            shutil.copy(script_file, scripts_dir)
    
    # Copy this script too
    shutil.copy(__file__, scripts_dir)
    
    print(f"   ✅ Files copied")

def main():
    """Main execution"""
    try:
        # Apply saved model to real data
        results = apply_saved_model()
        
        # Create visualizations
        create_titleless_charts(results)
        create_architecture_diagrams()
        
        # Create tables
        create_tables(results)
        
        # Copy files
        copy_files()
        
        print("\n🎉 REAL RESULTS PACKAGE GENERATED!")
        print("=" * 60)
        print(f"📊 Real Results:")
        print(f"   - Accuracy: {results['accuracy']*100:.2f}%")
        print(f"   - AUC-ROC: {results['auc_roc']:.3f}")
        print(f"   - Total Images: {results['total_images']}")
        print(f"   - Control Images: {results['control_images']}")
        print(f"   - MS Images: {results['ms_images']}")
        print(f"   - Confusion Matrix: {results['confusion_matrix'].tolist()}")
        
        print(f"\n📁 Package Location: {output_dir}/")
        print(f"🏆 Status: ✅ SUCCESS")
        
        return results
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return None

if __name__ == "__main__":
    results = main()

