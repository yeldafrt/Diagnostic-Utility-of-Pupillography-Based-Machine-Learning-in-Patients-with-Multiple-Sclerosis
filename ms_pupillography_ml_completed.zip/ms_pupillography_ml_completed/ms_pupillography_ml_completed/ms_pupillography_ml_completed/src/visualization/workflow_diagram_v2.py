import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

# Create figure
fig, ax = plt.subplots(1, 1, figsize=(12, 9), dpi=300)
ax.set_xlim(0, 10)
ax.set_ylim(0, 10)
ax.axis('off')

# Define colors
color_initial = '#E8F4F8'
color_split = '#E8F5E9'
color_final = '#F3E5F5'

# Level 1: Initial Data Collection (NO TITLE)
y = 9
box1 = FancyBboxPatch((2, y-0.4), 6, 0.8, boxstyle="round,pad=0.1", 
                       edgecolor='black', facecolor=color_initial, linewidth=2)
ax.add_patch(box1)
ax.text(5, y, 'Initial Data Collection\n63 Participants (25 MS + 38 Controls)', 
        ha='center', va='center', fontsize=11, fontweight='bold')

# Arrow down
arrow1 = FancyArrowPatch((5, y-0.5), (5, y-1.2), 
                         arrowstyle='->', mutation_scale=20, linewidth=2, color='black')
ax.add_patch(arrow1)

# Level 2: High-Quality Images (NO 977!)
y = 7.3
box2 = FancyBboxPatch((2, y-0.4), 6, 0.8, boxstyle="round,pad=0.1", 
                       edgecolor='black', facecolor=color_initial, linewidth=2)
ax.add_patch(box2)
ax.text(5, y, '692 High-Quality Pupillography Images\n63 Participants (25 MS + 38 Controls)\n~11 images per participant', 
        ha='center', va='center', fontsize=11, fontweight='bold')

# Arrow down
arrow2 = FancyArrowPatch((5, y-0.5), (5, y-1.2), 
                         arrowstyle='->', mutation_scale=20, linewidth=2, color='black')
ax.add_patch(arrow2)
ax.text(6.5, y-0.85, 'Patient-based\nstratified split', 
        ha='left', va='center', fontsize=9, style='italic', 
        bbox=dict(boxstyle='round,pad=0.3', facecolor=color_split, alpha=0.8))

# Level 3: Train-Test Split
y = 5.3
# Training box
box3a = FancyBboxPatch((0.5, y-0.6), 4, 1.2, boxstyle="round,pad=0.1", 
                        edgecolor='darkgreen', facecolor=color_split, linewidth=2.5)
ax.add_patch(box3a)
ax.text(2.5, y+0.2, 'Training Set', ha='center', va='center', 
        fontsize=12, fontweight='bold', color='darkgreen')
ax.text(2.5, y-0.15, '384 images\n35 patients\n(9 MS + 26 Controls)', 
        ha='center', va='center', fontsize=10)

# Test box
box3b = FancyBboxPatch((5.5, y-0.6), 4, 1.2, boxstyle="round,pad=0.1", 
                        edgecolor='darkblue', facecolor=color_split, linewidth=2.5)
ax.add_patch(box3b)
ax.text(7.5, y+0.2, 'Test Set (Independent)', ha='center', va='center', 
        fontsize=12, fontweight='bold', color='darkblue')
ax.text(7.5, y-0.15, '308 images\n28 patients\n(16 MS + 12 Controls)', 
        ha='center', va='center', fontsize=10)

# Arrows down from both
arrow3a = FancyArrowPatch((2.5, y-0.7), (2.5, y-1.4), 
                          arrowstyle='->', mutation_scale=20, linewidth=2, color='darkgreen')
ax.add_patch(arrow3a)

arrow3b = FancyArrowPatch((7.5, y-0.7), (7.5, y-1.4), 
                          arrowstyle='->', mutation_scale=20, linewidth=2, color='darkblue')
ax.add_patch(arrow3b)

# Level 4: Model Development and Evaluation
y = 2.8
# Training process
box4a = FancyBboxPatch((0.5, y-0.6), 4, 1.2, boxstyle="round,pad=0.1", 
                        edgecolor='darkgreen', facecolor=color_final, linewidth=2)
ax.add_patch(box4a)
ax.text(2.5, y+0.2, 'Model Development', ha='center', va='center', 
        fontsize=11, fontweight='bold', color='darkgreen')
ax.text(2.5, y-0.15, '5-fold Cross-Validation\nHyperparameter Tuning\nCV Accuracy: 56.7%', 
        ha='center', va='center', fontsize=9)

# Test evaluation
box4b = FancyBboxPatch((5.5, y-0.6), 4, 1.2, boxstyle="round,pad=0.1", 
                        edgecolor='darkblue', facecolor=color_final, linewidth=2)
ax.add_patch(box4b)
ax.text(7.5, y+0.2, 'Independent Evaluation', ha='center', va='center', 
        fontsize=11, fontweight='bold', color='darkblue')
ax.text(7.5, y-0.15, 'Patient-based Assessment\nTest Accuracy: 85.7%\nAUC-ROC: 0.945', 
        ha='center', va='center', fontsize=9)

# Bottom note
ax.text(5, 1.1, 'Note: Patient-based split ensures no patient overlap between training and test sets,\npreventing data leakage and enabling clinically meaningful evaluation.', 
        ha='center', va='center', fontsize=9, style='italic',
        bbox=dict(boxstyle='round,pad=0.5', facecolor='lightyellow', alpha=0.7))

# Legend for repeated measures
ax.text(5, 0.3, 'Repeated Measures: Each participant contributed ~11 images (both eyes, multiple measurements)\nAddressed through patient-based stratification', 
        ha='center', va='center', fontsize=8, style='italic',
        bbox=dict(boxstyle='round,pad=0.4', facecolor='lightcoral', alpha=0.3))

plt.tight_layout()
plt.savefig('/home/ubuntu/analysis/workflow_diagram_v2_no_title.png', dpi=300, bbox_inches='tight', facecolor='white')
print("✅ Workflow diagram v2 created (no title, no 977): workflow_diagram_v2_no_title.png")
