import os
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import random

# Veri yolları
ms_path = "/home/ubuntu/pupillografi_hasta_veri/pupillografi_hasta_veri/ms_grubu"
control_path = "/home/ubuntu/pupillografi_hasta_veri/pupillografi_hasta_veri/kontrol_grubu"

random.seed(42)
np.random.seed(42)

def get_sample_images(base_path, n_patients=2, n_images_per_patient=5):
    all_images = []
    patient_folders = [f for f in os.listdir(base_path) if os.path.isdir(os.path.join(base_path, f))]
    selected_patients = random.sample(patient_folders, min(n_patients, len(patient_folders)))
    
    for patient in selected_patients:
        patient_path = os.path.join(base_path, patient)
        images = [f for f in os.listdir(patient_path) if f.endswith(('.jpg', '.png', '.jpeg'))]
        selected_images = random.sample(images, min(n_images_per_patient, len(images)))
        for img in selected_images:
            all_images.append(os.path.join(patient_path, img))
    
    return all_images

# Görüntüleri al
ms_images = get_sample_images(ms_path, n_patients=2, n_images_per_patient=5)
control_images = get_sample_images(control_path, n_patients=2, n_images_per_patient=5)

# DAHA BÜYÜK Figure - 300 DPI
fig = plt.figure(figsize=(24, 10), dpi=300)  # Daha büyük: 24x10 inch
gs = fig.add_gridspec(2, 10, hspace=0.25, wspace=0.08, 
                       left=0.03, right=0.97, top=0.92, bottom=0.08)

# MS görüntüleri (Kırmızı kenarlık)
for idx, img_path in enumerate(ms_images):
    ax = fig.add_subplot(gs[0, idx])
    img = Image.open(img_path)
    ax.imshow(img)
    ax.axis('off')
    # Kalın kırmızı kenarlık
    for spine in ax.spines.values():
        spine.set_edgecolor('#d32f2f')
        spine.set_linewidth(6)  # Daha kalın
        spine.set_visible(True)

# MS başlığı - daha büyük
fig.text(0.5, 0.96, 'MS Patients', ha='center', fontsize=36, 
         fontweight='bold', color='#d32f2f')

# Control görüntüleri (Yeşil kenarlık)
for idx, img_path in enumerate(control_images):
    ax = fig.add_subplot(gs[1, idx])
    img = Image.open(img_path)
    ax.imshow(img)
    ax.axis('off')
    # Kalın yeşil kenarlık
    for spine in ax.spines.values():
        spine.set_edgecolor('#388e3c')
        spine.set_linewidth(6)  # Daha kalın
        spine.set_visible(True)

# Control başlığı - daha büyük
fig.text(0.5, 0.46, 'Healthy Controls', ha='center', fontsize=36, 
         fontweight='bold', color='#388e3c')

# Kaydet - 300 DPI
output_path = '/home/ubuntu/Figure_2_Large_300dpi.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
print(f"✅ Large Figure 2 saved: {output_path}")
plt.close()

file_size = os.path.getsize(output_path) / (1024 * 1024)
print(f"📊 File size: {file_size:.2f} MB")
print(f"📐 Resolution: 300 DPI")
print(f"📏 Dimensions: 24 x 10 inches")
