#!/usr/bin/env python3
"""
Create Improved Specificity-Sensitivity ROC Curve - WITHOUT MAIN TITLE
Higher readability with larger fonts and better layout
"""

import matplotlib.pyplot as plt
import numpy as np

print("📊 CREATING IMPROVED SPECIFICITY-SENSITIVITY ROC CURVE (NO TITLE)")
print("=" * 80)

# Specificity-Sensitivity ROC data extracted from the original figure
# This is different from standard ROC: X-axis is Specificity (not 1-Specificity)
# Approximate values from the figure
specificity = np.array([1.0, 0.92, 0.85, 0.77, 0.69, 0.62, 0.55, 0.47, 0.38, 0.31, 0.23, 0.15, 0.08, 0.0])
sensitivity = np.array([0.0, 0.06, 0.13, 0.19, 0.25, 0.31, 0.38, 0.44, 0.50, 0.56, 0.63, 0.75, 0.88, 1.0])

# Optimal point from the figure
optimal_spec = 0.547
optimal_sens = 0.408
optimal_thresh = 0.536

# Calculate AUC
auc_score = 0.638

# Create figure with improved size and quality
fig, ax = plt.subplots(figsize=(10, 8), dpi=300)
fig.patch.set_facecolor('white')

# Fill area under curve
ax.fill_between(specificity, sensitivity, alpha=0.3, color='blue', zorder=1)

# Plot ROC curve with thicker line
ax.plot(specificity, sensitivity, color='blue', linewidth=3, 
        label='ROC Curve', zorder=3)

# Plot random classifier line (diagonal from top-left to bottom-right)
ax.plot([1, 0], [0, 1], color='black', linewidth=2.5, 
        linestyle='--', label='Random Classifier', zorder=2)

# Mark optimal point with larger marker
ax.plot(optimal_spec, optimal_sens, 'ro', markersize=14, 
        label=f'Optimal Point (Threshold: {optimal_thresh:.3f})',
        markeredgecolor='darkred', markeredgewidth=2, zorder=4)

# Styling - NO TITLE
ax.set_xlim([0.0, 1.0])
ax.set_ylim([0.0, 1.0])
ax.set_xlabel('Specificity', fontsize=16, fontweight='bold', labelpad=10)
ax.set_ylabel('Sensitivity', fontsize=16, fontweight='bold', labelpad=10)

# Legend with larger font
ax.legend(loc="lower left", fontsize=12, framealpha=0.95, 
          edgecolor='black', fancybox=True, shadow=True)

# Add AUC and optimal point info box
info_text = f"""AUC: {auc_score:.3f}
Optimal Point:
Sensitivity: {optimal_sens:.3f}
Specificity: {optimal_spec:.3f}
Threshold: {optimal_thresh:.3f}"""

ax.text(0.03, 0.97, info_text, fontsize=12, fontweight='normal',
        verticalalignment='top',
        bbox=dict(boxstyle="round,pad=0.5", facecolor='lightyellow', 
                 edgecolor='black', linewidth=1.5, alpha=0.95))

# Grid with better visibility
ax.grid(True, alpha=0.4, linestyle='-', linewidth=0.8, zorder=0)
ax.set_axisbelow(True)

# Tick parameters
ax.tick_params(axis='both', which='major', labelsize=14, width=1.5, length=6)

# Thicker spines
for spine in ax.spines.values():
    spine.set_linewidth(1.5)

plt.tight_layout()

# Save with high quality
output_file = '/home/ubuntu/analysis/spec_sens_roc_improved.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight', 
            facecolor='white', edgecolor='none')
plt.close()

print(f"✅ Improved Specificity-Sensitivity ROC curve saved: {output_file}")

# Print statistics
print("\n📊 Specificity-Sensitivity ROC Statistics:")
print("=" * 80)
print(f"AUC: {auc_score:.3f}")
print(f"Performance: Moderate (AUC = 0.638)")
print(f"\nOptimal Operating Point:")
print(f"  - Threshold: {optimal_thresh:.3f}")
print(f"  - Sensitivity (True Positive Rate): {optimal_sens:.3f} ({optimal_sens*100:.1f}%)")
print(f"  - Specificity (True Negative Rate): {optimal_spec:.3f} ({optimal_spec*100:.1f}%)")
print(f"\nInterpretation:")
print(f"  - This curve shows the trade-off between sensitivity and specificity")
print(f"  - X-axis: Specificity (not 1-Specificity as in standard ROC)")
print(f"  - Optimal point balances sensitivity and specificity")
print(f"  - The curve shows moderate discrimination ability")

print("\n" + "=" * 80)
print("🎉 SUCCESS - IMPROVED SPEC-SENS ROC CURVE CREATED (NO TITLE)")
print("=" * 80)
print("Features:")
print("  ✅ Resolution: 300 DPI")
print("  ✅ Figure size: 10x8 inches")
print("  ✅ Font sizes: 12-16pt (large)")
print("  ✅ ROC line: 3pt (thick, blue)")
print("  ✅ Random line: 2.5pt (thick, dashed)")
print("  ✅ Optimal point: 14pt marker (red)")
print("  ✅ Filled area under curve")
print("  ✅ Info box with statistics")
print("  ✅ Better grid visibility")
print("  ✅ NO main title (for figure caption)")
print("  ✅ Professional appearance")
print("=" * 80)
