#!/usr/bin/env python3
"""
Final CV Plot - Keskin Renkler + Büyük Eksen Yazıları - 300 DPI
"""

import numpy as np
import matplotlib.pyplot as plt

cv_results = {
    'accuracy': [0.587, 0.623, 0.610, 0.571, 0.597],
    'precision': [0.534, 0.623, 0.571, 0.545, 0.623],
    'recall': [0.434, 0.571, 0.532, 0.377, 0.506],
    'f1_score': [0.377, 0.545, 0.506, 0.429, 0.558],
    'roc_auc': [0.560, 0.623, 0.597, 0.545, 0.610]
}

print("📊 Creating Sharp CV Plot with Larger Axis Labels (300 DPI)...")

metrics_names = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'ROC-AUC']
metrics_keys = ['accuracy', 'precision', 'recall', 'f1_score', 'roc_auc']

cv_data = [cv_results[key] for key in metrics_keys]
means = [np.mean(data) for data in cv_data]
stds = [np.std(data) for data in cv_data]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 8), dpi=300)
fig.patch.set_facecolor('white')

# ========== LEFT PANEL: BOX PLOTS - KESKİN RENKLER ==========

bp = ax1.boxplot(cv_data, tick_labels=metrics_names, patch_artist=True,
                 widths=0.6, showfliers=True,
                 boxprops=dict(facecolor='#4A90E2', edgecolor='black', linewidth=2.5, alpha=1.0),  # Keskin mavi
                 whiskerprops=dict(color='black', linewidth=2.5),
                 capprops=dict(color='black', linewidth=2.5),
                 medianprops=dict(color='#FF4500', linewidth=3.5),  # Keskin turuncu
                 flierprops=dict(marker='o', markerfacecolor='black', markersize=8, 
                                markeredgecolor='black', alpha=0.8))

# BÜYÜTÜLMÜŞ EKSEN YAZILARI
ax1.set_ylabel('Score', fontsize=22, fontweight='bold')  # 18 → 22
ax1.set_xlabel('Metrics', fontsize=22, fontweight='bold')  # 18 → 22
ax1.set_ylim([0, 1.0])
ax1.grid(True, alpha=0.4, axis='y', linestyle='-', linewidth=1.2)
ax1.set_axisbelow(True)
ax1.tick_params(axis='both', which='major', labelsize=17, width=2, length=8)  # 15 → 17

for i, (mean, std) in enumerate(zip(means, stds)):
    ax1.text(i+1, -0.10, f'μ={mean:.3f}\nσ={std:.3f}', 
            ha='center', va='top', fontsize=13, fontweight='bold',
            transform=ax1.get_xaxis_transform(),
            bbox=dict(boxstyle='round,pad=0.4', facecolor='#FFEB3B',  # Keskin sarı
                     edgecolor='black', linewidth=1.5, alpha=1.0))

for spine in ax1.spines.values():
    spine.set_linewidth(2.5)

# ========== RIGHT PANEL: GROUPED BAR CHART - KESKİN RENKLER ==========

n_folds = len(cv_data[0])
n_metrics = len(metrics_names)

x = np.arange(n_folds)
width = 0.16

# KESKİN RENKLER - Alpha 1.0
colors = ['#4A90E2', '#50C878', '#FF6B9D', '#FFEB3B', '#BA55D3']  # Mavi, Yeşil, Pembe, Sarı, Mor

for i, (metric_data, metric_name, color) in enumerate(zip(cv_data, metrics_names, colors)):
    offset = (i - n_metrics/2 + 0.5) * width
    ax2.bar(x + offset, metric_data, width, label=metric_name, 
           color=color, edgecolor='black', linewidth=1.2, alpha=1.0)  # 0.9 → 1.0

# BÜYÜTÜLMÜŞ EKSEN YAZILARI
ax2.set_ylabel('Score', fontsize=22, fontweight='bold')  # 18 → 22
ax2.set_xlabel('Cross-Validation Fold', fontsize=22, fontweight='bold')  # 18 → 22
ax2.set_xticks(x)
ax2.set_xticklabels([f'Fold {i+1}' for i in range(n_folds)])
ax2.set_ylim([0, 1.0])
ax2.legend(loc='upper right', fontsize=15, framealpha=1.0,  # 14 → 15
          edgecolor='black', fancybox=True, shadow=True)
ax2.grid(True, alpha=0.4, axis='y', linestyle='-', linewidth=1.2)
ax2.set_axisbelow(True)
ax2.tick_params(axis='both', which='major', labelsize=17, width=2, length=8)  # 15 → 17

for spine in ax2.spines.values():
    spine.set_linewidth(2.5)

# ========== DATA SIZES INFO ==========

data_sizes_text = ('Data Sizes: 5-fold cross-validation on training set | '
                  'Training set: 384 images (98 MS + 286 Control) | '
                  'Each fold: ~307 training, ~77 validation')

fig.text(0.5, 0.02, data_sizes_text, ha='center', fontsize=14, fontweight='bold',
         bbox=dict(boxstyle='round,pad=0.8', facecolor='#B3D9FF', alpha=1.0,  # Keskin açık mavi
                  edgecolor='#1E3A8A', linewidth=3.0))

plt.tight_layout(rect=[0, 0.08, 1, 1])

output_path = '/home/ubuntu/CV_Results_Sharp_300dpi.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight', 
           facecolor='white', edgecolor='none', pad_inches=0.2)
plt.close()

print(f"✅ Sharp CV plot saved: {output_path}")

import os
file_size = os.path.getsize(output_path) / (1024 * 1024)
print(f"📊 File size: {file_size:.2f} MB")
print(f"📐 Resolution: 300 DPI")
print(f"📏 Dimensions: 20 x 8 inches")
print(f"🎨 Colors: Sharp and vibrant (alpha=1.0)")
print(f"📝 Axis labels: 22pt (increased from 18pt)")
print(f"📝 Tick labels: 17pt (increased from 15pt)")
