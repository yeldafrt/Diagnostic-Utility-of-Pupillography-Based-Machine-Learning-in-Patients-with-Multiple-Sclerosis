#!/usr/bin/env python3
"""
Clinical Validation Figure Generator for MS Pupillography Study
Creates a 3-panel figure for manuscript:
(a) Confusion Matrix
(b) ROC Curve
(c) Performance Comparison (Training vs Test)

Final corrected version - metrics box positioned below confusion matrix

Requirements:
- matplotlib
- numpy
- pandas
- seaborn
- sklearn

Usage:
    python create_clinical_validation_figure_final.py
"""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import roc_curve, auc, confusion_matrix
import seaborn as sns

# Set publication-quality style
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 11
plt.rcParams['axes.linewidth'] = 1.5
plt.rcParams['xtick.major.width'] = 1.5
plt.rcParams['ytick.major.width'] = 1.5

# Load patient data
patient_df = pd.read_csv('/home/ubuntu/clinical_validation_results/patient_final_predictions.csv')

# Calculate final predictions with best configuration
# Best: 0.7*max_prob + 0.3*top5_mean, threshold=0.465
combined_score = 0.7 * patient_df['max_prob'] + 0.3 * patient_df['top5_mean']
final_pred = (combined_score > 0.465).astype(int)
y_true = patient_df['true_label'].values

# Create figure with 3 panels
fig = plt.figure(figsize=(18, 6))
gs = fig.add_gridspec(1, 3, hspace=0.3, wspace=0.3)

# ============================================================================
# Panel (a): Confusion Matrix
# ============================================================================
ax1 = fig.add_subplot(gs[0, 0])

cm = confusion_matrix(y_true, final_pred)
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

# Create heatmap
sns.heatmap(cm, annot=False, fmt='d', cmap='Blues', cbar=False,
            linewidths=2, linecolor='white', ax=ax1,
            vmin=0, vmax=18)

# Add text annotations with both count and percentage
for i in range(2):
    for j in range(2):
        count = cm[i, j]
        percentage = cm_normalized[i, j] * 100
        text = f'{count}\n({percentage:.1f}%)'
        color = 'white' if cm[i, j] > cm.max()/2 else 'black'
        ax1.text(j+0.5, i+0.5, text, ha='center', va='center',
                fontsize=14, fontweight='bold', color=color)

# Labels
ax1.set_xlabel('Predicted Label', fontsize=13, fontweight='bold')
ax1.set_ylabel('True Label', fontsize=13, fontweight='bold')
ax1.set_xticklabels(['Control', 'MS'], fontsize=12)
ax1.set_yticklabels(['Control', 'MS'], fontsize=12, rotation=0)
ax1.set_title('(a) Confusion Matrix', fontsize=14, fontweight='bold', pad=15)

# Add performance metrics BELOW the confusion matrix
metrics_text = 'Accuracy: 75.0%\nSensitivity: 88.9%\nSpecificity: 57.1%'
ax1.text(1.0, -0.25, metrics_text, transform=ax1.transAxes,
         fontsize=11, ha='center', va='top',
         bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5, 
                  edgecolor='black', linewidth=1.5))

# ============================================================================
# Panel (b): ROC Curve
# ============================================================================
ax2 = fig.add_subplot(gs[0, 1])

# Calculate ROC curve
fpr, tpr, thresholds = roc_curve(y_true, combined_score)
roc_auc = auc(fpr, tpr)

# Plot ROC curve
ax2.plot(fpr, tpr, color='#2E86AB', linewidth=3, 
         label=f'ROC Curve (AUC = {roc_auc:.3f})')

# Plot diagonal reference line
ax2.plot([0, 1], [0, 1], 'k--', linewidth=2, alpha=0.3, label='Random Classifier')

# Mark operating point (at threshold=0.465)
idx = np.argmin(np.abs(thresholds - 0.465))
ax2.plot(fpr[idx], tpr[idx], 'ro', markersize=12, 
         label=f'Operating Point\n(Sens={tpr[idx]:.3f}, 1-Spec={fpr[idx]:.3f})',
         markeredgewidth=2, markeredgecolor='darkred')

# Labels and styling
ax2.set_xlabel('False Positive Rate (1 - Specificity)', fontsize=13, fontweight='bold')
ax2.set_ylabel('True Positive Rate (Sensitivity)', fontsize=13, fontweight='bold')
ax2.set_title('(b) ROC Curve', fontsize=14, fontweight='bold', pad=15)
ax2.legend(loc='lower right', fontsize=10, frameon=True, shadow=True)
ax2.grid(True, alpha=0.3, linestyle='--')
ax2.set_xlim([-0.05, 1.05])
ax2.set_ylim([-0.05, 1.05])
ax2.set_aspect('equal')

# ============================================================================
# Panel (c): Performance Metrics Comparison
# ============================================================================
ax3 = fig.add_subplot(gs[0, 2])

# Data for comparison
metrics = ['Accuracy', 'Sensitivity', 'Specificity', 'AUC']
training_values = [85.7, 93.8, 80.8, 94.5]  # From training set
test_values = [75.0, 88.9, 57.1, roc_auc*100]  # From test set

x = np.arange(len(metrics))
width = 0.35

# Create bars
bars1 = ax3.bar(x - width/2, training_values, width, label='Training Set',
                color='#A23B72', alpha=0.8, edgecolor='black', linewidth=1.5)
bars2 = ax3.bar(x + width/2, test_values, width, label='Independent Test Set',
                color='#F18F01', alpha=0.8, edgecolor='black', linewidth=1.5)

# Add value labels on bars
for bars in [bars1, bars2]:
    for bar in bars:
        height = bar.get_height()
        ax3.text(bar.get_x() + bar.get_width()/2., height,
                f'{height:.1f}%',
                ha='center', va='bottom', fontsize=10, fontweight='bold')

# Labels and styling
ax3.set_ylabel('Performance (%)', fontsize=13, fontweight='bold')
ax3.set_title('(c) Performance Comparison', fontsize=14, fontweight='bold', pad=15)
ax3.set_xticks(x)
ax3.set_xticklabels(metrics, fontsize=12)
ax3.legend(loc='upper right', fontsize=10, frameon=True, shadow=True)
ax3.set_ylim([0, 105])
ax3.grid(True, axis='y', alpha=0.3, linestyle='--')
ax3.spines['top'].set_visible(False)
ax3.spines['right'].set_visible(False)

# Add horizontal line at 70% for reference
ax3.axhline(y=70, color='gray', linestyle=':', linewidth=2, alpha=0.5)
ax3.text(3.5, 72, '70% threshold', fontsize=9, color='gray', style='italic')

# Save figure
plt.tight_layout()
plt.savefig('clinical_validation_figure_final.png', dpi=300, bbox_inches='tight')
print("✅ Figure saved: clinical_validation_figure_final.png (300 DPI)")

# Also save as high-quality PDF
plt.savefig('clinical_validation_figure_final.pdf', dpi=300, bbox_inches='tight')
print("✅ Figure saved: clinical_validation_figure_final.pdf (300 DPI)")

plt.close()

# Print summary
print("\n" + "="*70)
print("FIGURE SUMMARY")
print("="*70)
print("\nPanel (a): Confusion Matrix")
print(f"  TN: {cm[0][0]}, FP: {cm[0][1]}, FN: {cm[1][0]}, TP: {cm[1][1]}")
print(f"  Metrics box positioned below matrix")
print(f"\nPanel (b): ROC Curve")
print(f"  AUC: {roc_auc:.3f}")
print(f"  Operating point: Sensitivity={tpr[idx]:.3f}, Specificity={1-fpr[idx]:.3f}")
print(f"\nPanel (c): Performance Comparison")
print(f"  Training → Test accuracy drop: {training_values[0] - test_values[0]:.1f}%")
print("\n✅ All panels created successfully!")
print("✅ Metrics box correctly positioned!")

