#!/usr/bin/env python3
"""
Create Improved Confusion Matrix - WITHOUT MAIN TITLE
Higher readability with larger fonts and better layout
"""

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

print("📊 CREATING IMPROVED CONFUSION MATRIX (NO TITLE)")
print("=" * 80)

# Confusion matrix data from the original figure
# True Label (rows): Control, MS
# Predicted Label (cols): Control, MS
confusion_matrix = np.array([
    [21, 5],   # Control: 21 correct, 5 misclassified as MS
    [1, 15]    # MS: 1 misclassified as Control, 15 correct
])

# Create figure with improved size and quality
fig, ax = plt.subplots(figsize=(9, 7), dpi=300)
fig.patch.set_facecolor('white')

# Create heatmap with better styling
sns.heatmap(confusion_matrix, 
            annot=True,           # Show numbers
            fmt='d',              # Integer format
            cmap='Blues',         # Color scheme
            xticklabels=['Control', 'MS'], 
            yticklabels=['Control', 'MS'],
            cbar_kws={'label': 'Count'},
            annot_kws={'fontsize': 18, 'fontweight': 'bold'},  # Larger numbers
            linewidths=2,         # Cell borders
            linecolor='black',    # Border color
            square=True,          # Square cells
            ax=ax)

# Styling - NO TITLE
ax.set_xlabel('Predicted Label (Patient)', fontsize=15, fontweight='bold', labelpad=10)
ax.set_ylabel('True Label (Patient)', fontsize=15, fontweight='bold', labelpad=10)

# Tick parameters
ax.tick_params(axis='both', which='major', labelsize=14, width=1.5, length=6)

# Colorbar styling
cbar = ax.collections[0].colorbar
cbar.ax.tick_params(labelsize=12, width=1.5, length=6)
cbar.set_label('Count', fontsize=14, fontweight='bold', labelpad=10)

plt.tight_layout()

# Save with high quality
output_file = '/home/ubuntu/analysis/confusion_matrix_improved.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight', 
            facecolor='white', edgecolor='none')
plt.close()

print(f"✅ Improved confusion matrix saved: {output_file}")

# Print statistics
print("\n📊 Confusion Matrix Statistics:")
print("=" * 80)
print("True Positives (MS correctly identified): 15")
print("True Negatives (Control correctly identified): 21")
print("False Positives (Control misclassified as MS): 5")
print("False Negatives (MS misclassified as Control): 1")
print(f"\nTotal patients: {confusion_matrix.sum()}")
print(f"Accuracy: {(21 + 15) / confusion_matrix.sum():.3f} ({(21 + 15) / confusion_matrix.sum() * 100:.1f}%)")
print(f"Sensitivity (Recall): {15 / (15 + 1):.3f} ({15 / (15 + 1) * 100:.1f}%)")
print(f"Specificity: {21 / (21 + 5):.3f} ({21 / (21 + 5) * 100:.1f}%)")
print(f"Precision: {15 / (15 + 5):.3f} ({15 / (15 + 5) * 100:.1f}%)")

print("\n" + "=" * 80)
print("🎉 SUCCESS - IMPROVED CONFUSION MATRIX CREATED (NO TITLE)")
print("=" * 80)
print("Features:")
print("  ✅ Resolution: 300 DPI")
print("  ✅ Figure size: 9x7 inches")
print("  ✅ Font sizes: 14-18pt (large)")
print("  ✅ Numbers inside cells: 18pt (bold)")
print("  ✅ Thick cell borders (2pt)")
print("  ✅ Square cells for symmetry")
print("  ✅ NO main title (for figure caption)")
print("  ✅ Professional appearance")
print("=" * 80)
