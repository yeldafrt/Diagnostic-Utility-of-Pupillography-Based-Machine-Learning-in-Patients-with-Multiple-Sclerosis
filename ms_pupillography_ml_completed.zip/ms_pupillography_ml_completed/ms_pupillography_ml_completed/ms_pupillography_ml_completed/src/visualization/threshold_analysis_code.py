#!/usr/bin/env python3
"""
Threshold Analysis Plot - Original Code
Shows how different classification thresholds affect model performance metrics
"""

import numpy as np
import matplotlib.pyplot as plt

def create_threshold_analysis(model, X, y, output_path='threshold_analysis.png'):
    """
    Create threshold analysis plot
    
    Parameters:
    -----------
    model : trained classifier with predict_proba method
    X : feature matrix
    y : true labels
    output_path : path to save the figure
    """
    print("📊 Creating Threshold Analysis...")
    
    # Get predicted probabilities
    y_prob = model.predict_proba(X)[:, 1]
    
    # Calculate metrics for different thresholds
    thresholds = np.linspace(0, 1, 101)
    sensitivity_scores = []
    specificity_scores = []
    precision_scores = []
    f1_scores = []
    
    for threshold in thresholds:
        y_pred_thresh = (y_prob >= threshold).astype(int)
        
        # Calculate metrics
        tp = np.sum((y_pred_thresh == 1) & (y == 1))
        tn = np.sum((y_pred_thresh == 0) & (y == 0))
        fp = np.sum((y_pred_thresh == 1) & (y == 0))
        fn = np.sum((y_pred_thresh == 0) & (y == 1))
        
        sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        f1 = 2 * (precision * sensitivity) / (precision + sensitivity) if (precision + sensitivity) > 0 else 0
        
        sensitivity_scores.append(sensitivity)
        specificity_scores.append(specificity)
        precision_scores.append(precision)
        f1_scores.append(f1)
    
    # Create plot (NO TITLE)
    plt.figure(figsize=(12, 8), dpi=300)
    
    plt.plot(thresholds, sensitivity_scores, label='Sensitivity (Recall)', linewidth=2, color='blue')
    plt.plot(thresholds, specificity_scores, label='Specificity', linewidth=2, color='red')
    plt.plot(thresholds, precision_scores, label='Precision', linewidth=2, color='green')
    plt.plot(thresholds, f1_scores, label='F1-Score', linewidth=2, color='orange')
    
    # Find optimal threshold (max F1)
    optimal_idx = np.argmax(f1_scores)
    optimal_threshold = thresholds[optimal_idx]
    
    plt.axvline(x=optimal_threshold, color='black', linestyle='--', linewidth=2, 
                label=f'Optimal Threshold: {optimal_threshold:.3f}')
    
    plt.xlabel('Classification Threshold', fontsize=12)
    plt.ylabel('Score', fontsize=12)
    plt.legend(loc='center right', fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.xlim([0, 1])
    plt.ylim([0, 1])
    
    # Add optimal metrics text
    opt_text = f"""Optimal Metrics (Threshold = {optimal_threshold:.3f}):
Sensitivity: {sensitivity_scores[optimal_idx]:.3f}
Specificity: {specificity_scores[optimal_idx]:.3f}
Precision: {precision_scores[optimal_idx]:.3f}
F1-Score: {f1_scores[optimal_idx]:.3f}"""
    
    plt.text(0.02, 0.6, opt_text, fontsize=10, 
             bbox=dict(boxstyle="round,pad=0.3", facecolor='lightyellow'))
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close()
    
    print(f"   ✅ Threshold analysis created: {output_path}")
    return optimal_threshold


# Example usage (requires trained model and data):
# from sklearn.ensemble import RandomForestClassifier
# model = RandomForestClassifier()
# model.fit(X_train, y_train)
# optimal_thresh = create_threshold_analysis(model, X_test, y_test)

print("""
📊 THRESHOLD ANALYSIS CODE
==========================

This code creates a threshold analysis plot showing how different 
classification thresholds affect model performance metrics:

- Sensitivity (Recall): True Positive Rate
- Specificity: True Negative Rate  
- Precision: Positive Predictive Value
- F1-Score: Harmonic mean of Precision and Recall

The optimal threshold is determined by maximizing the F1-Score.

Usage:
------
1. Train your model with predict_proba() method
2. Call: create_threshold_analysis(model, X_test, y_test)
3. The function will save the plot and return the optimal threshold

Key Features:
-------------
✅ 4 performance metrics plotted
✅ Optimal threshold marked with vertical line
✅ Info box with optimal metrics
✅ 300 DPI resolution
✅ No main title (for figure caption)
✅ Professional appearance
""")
