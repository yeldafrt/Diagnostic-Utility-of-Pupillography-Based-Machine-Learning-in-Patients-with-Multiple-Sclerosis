#!/usr/bin/env python3
"""
Figure 2 - Clean Version (Side-by-side single images)
MS Patient vs Healthy Control - Pupillographic Images
"""

from PIL import Image
import matplotlib.pyplot as plt
import os

# =============================================================================
# AYARLAR
# =============================================================================

# Veri yolları (kendi yollarınızı güncelleyin)
ms_img_path = "/home/ubuntu/pupillografi_hasta_veri/pupillografi_hasta_veri/ms_grubu/10_ms/10.jpg"
control_img_path = "/home/ubuntu/pupillografi_hasta_veri/pupillografi_hasta_veri/kontrol_grubu/1/10.jpg"

# Çıktı dosyası
output_path = '/home/ubuntu/Figure_2_Clean_300dpi.png'

# Figür boyutları
FIGURE_WIDTH = 24  # inch
FIGURE_HEIGHT = 12  # inch
DPI = 300

# Renkler
MS_COLOR = '#c62828'  # Koyu kırmızı
CONTROL_COLOR = '#2e7d32'  # Koyu yeşil

# Kenarlık kalınlığı
BORDER_WIDTH = 16

# Font boyutları
TITLE_FONTSIZE = 72

# =============================================================================
# GÖRÜNTÜ YÜKLEME
# =============================================================================

print("Görüntüler yükleniyor...")
ms_img = Image.open(ms_img_path)
control_img = Image.open(control_img_path)
print(f"✅ MS görüntü boyutu: {ms_img.size}")
print(f"✅ Kontrol görüntü boyutu: {control_img.size}")

# =============================================================================
# FİGÜR OLUŞTURMA
# =============================================================================

print(f"\nFigür oluşturuluyor ({FIGURE_WIDTH}x{FIGURE_HEIGHT} inch, {DPI} DPI)...")

# Figure oluştur
fig = plt.figure(figsize=(FIGURE_WIDTH, FIGURE_HEIGHT), dpi=DPI)

# Grid layout: 1 satır, 2 sütun
gs = fig.add_gridspec(1, 2, 
                       wspace=0.08,  # Sütunlar arası boşluk
                       left=0.03,    # Sol kenar
                       right=0.97,   # Sağ kenar
                       top=0.92,     # Üst kenar
                       bottom=0.03)  # Alt kenar

# =============================================================================
# MS GÖRÜNTÜSÜ (SOL)
# =============================================================================

ax1 = fig.add_subplot(gs[0, 0])
ax1.imshow(ms_img, interpolation='lanczos')  # En yüksek kalite interpolasyon
ax1.axis('off')

# Kalın kırmızı kenarlık
for spine in ax1.spines.values():
    spine.set_edgecolor(MS_COLOR)
    spine.set_linewidth(BORDER_WIDTH)
    spine.set_visible(True)

# =============================================================================
# KONTROL GÖRÜNTÜSÜ (SAĞ)
# =============================================================================

ax2 = fig.add_subplot(gs[0, 1])
ax2.imshow(control_img, interpolation='lanczos')  # En yüksek kalite interpolasyon
ax2.axis('off')

# Kalın yeşil kenarlık
for spine in ax2.spines.values():
    spine.set_edgecolor(CONTROL_COLOR)
    spine.set_linewidth(BORDER_WIDTH)
    spine.set_visible(True)

# =============================================================================
# BAŞLIKLAR
# =============================================================================

# MS Patient başlığı
fig.text(0.27, 0.97, 'MS Patient', 
         ha='center', 
         fontsize=TITLE_FONTSIZE, 
         fontweight='bold', 
         color=MS_COLOR)

# Healthy Control başlığı
fig.text(0.73, 0.97, 'Healthy Control', 
         ha='center', 
         fontsize=TITLE_FONTSIZE, 
         fontweight='bold', 
         color=CONTROL_COLOR)

# =============================================================================
# KAYDETME
# =============================================================================

print(f"\nFigür kaydediliyor: {output_path}")
plt.savefig(output_path, 
            dpi=DPI, 
            bbox_inches='tight', 
            facecolor='white', 
            edgecolor='none')
plt.close()

# =============================================================================
# SONUÇ BİLGİLERİ
# =============================================================================

file_size = os.path.getsize(output_path) / (1024 * 1024)
print(f"\n{'='*60}")
print(f"✅ Figure 2 (Clean Version) başarıyla oluşturuldu!")
print(f"{'='*60}")
print(f"📁 Dosya: {output_path}")
print(f"📊 Boyut: {file_size:.2f} MB")
print(f"📐 Çözünürlük: {DPI} DPI")
print(f"📏 Fiziksel boyut: {FIGURE_WIDTH} x {FIGURE_HEIGHT} inch")
print(f"📏 Fiziksel boyut: {FIGURE_WIDTH*2.54:.1f} x {FIGURE_HEIGHT*2.54:.1f} cm")
print(f"{'='*60}")
