#!/usr/bin/env python3
"""
Cross-Validation Results Plot - Complete Code
Shows box plots and fold-by-fold performance metrics
"""

import numpy as np
import matplotlib.pyplot as plt

def create_cross_validation_results(cv_results_dict, output_path='cv_results.png'):
    """
    Create cross-validation results plot with box plots and fold-by-fold bars
    
    Parameters:
    -----------
    cv_results_dict : dict
        Dictionary with keys: 'accuracy', 'precision', 'recall', 'f1_score', 'roc_auc'
        Each value is a list/array of 5 scores (one per fold)
    output_path : str
        Path to save the figure
    
    Example:
    --------
    cv_results = {
        'accuracy': [0.587, 0.623, 0.610, 0.571, 0.597],
        'precision': [0.534, 0.623, 0.571, 0.545, 0.623],
        'recall': [0.434, 0.571, 0.532, 0.377, 0.506],
        'f1_score': [0.377, 0.545, 0.506, 0.429, 0.558],
        'roc_auc': [0.560, 0.623, 0.597, 0.545, 0.610]
    }
    create_cross_validation_results(cv_results, 'cv_results.png')
    """
    print("📊 Creating Cross-Validation Results Plot...")
    
    # Extract data
    metrics_names = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'ROC-AUC']
    metrics_keys = ['accuracy', 'precision', 'recall', 'f1_score', 'roc_auc']
    
    # Prepare data for plotting
    cv_data = []
    for key in metrics_keys:
        cv_data.append(cv_results_dict[key])
    
    # Calculate statistics
    means = [np.mean(data) for data in cv_data]
    stds = [np.std(data) for data in cv_data]
    
    # Create figure with two subplots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6), dpi=300)
    fig.patch.set_facecolor('white')
    
    # ========== LEFT PANEL: BOX PLOTS ==========
    
    # Create box plots
    bp = ax1.boxplot(cv_data, labels=metrics_names, patch_artist=True,
                     widths=0.6, showfliers=True,
                     boxprops=dict(facecolor='lightblue', edgecolor='black', linewidth=1.5, alpha=0.7),
                     whiskerprops=dict(color='black', linewidth=1.5),
                     capprops=dict(color='black', linewidth=1.5),
                     medianprops=dict(color='orange', linewidth=2),
                     flierprops=dict(marker='o', markerfacecolor='black', markersize=6, 
                                    markeredgecolor='black', alpha=0.5))
    
    # Customize left panel
    ax1.set_ylabel('Score', fontsize=14, fontweight='bold')
    ax1.set_xlabel('Metrics', fontsize=14, fontweight='bold')
    ax1.set_ylim([0, 1.0])
    ax1.grid(True, alpha=0.3, axis='y', linestyle='-', linewidth=0.8)
    ax1.set_axisbelow(True)
    ax1.tick_params(axis='both', which='major', labelsize=12, width=1.5, length=6)
    
    # Add mean and std annotations below each box
    for i, (mean, std) in enumerate(zip(means, stds)):
        ax1.text(i+1, -0.08, f'μ={mean:.3f}\nσ={std:.3f}', 
                ha='center', va='top', fontsize=10, fontweight='bold',
                transform=ax1.get_xaxis_transform())
    
    # Thicker spines
    for spine in ax1.spines.values():
        spine.set_linewidth(1.5)
    
    # ========== RIGHT PANEL: GROUPED BAR CHART ==========
    
    n_folds = len(cv_data[0])
    n_metrics = len(metrics_names)
    
    # Set up bar positions
    x = np.arange(n_folds)
    width = 0.15
    
    # Colors for each metric
    colors = ['lightblue', 'lightgreen', 'lightcoral', 'lightyellow', 'plum']
    
    # Plot bars for each metric
    for i, (metric_data, metric_name, color) in enumerate(zip(cv_data, metrics_names, colors)):
        offset = (i - n_metrics/2 + 0.5) * width
        ax2.bar(x + offset, metric_data, width, label=metric_name, 
               color=color, edgecolor='black', linewidth=0.8, alpha=0.85)
    
    # Customize right panel
    ax2.set_ylabel('Score', fontsize=14, fontweight='bold')
    ax2.set_xlabel('Cross-Validation Fold', fontsize=14, fontweight='bold')
    ax2.set_xticks(x)
    ax2.set_xticklabels([f'Fold {i+1}' for i in range(n_folds)])
    ax2.set_ylim([0, 1.0])
    ax2.legend(loc='upper right', fontsize=11, framealpha=0.95, 
              edgecolor='black', fancybox=True)
    ax2.grid(True, alpha=0.3, axis='y', linestyle='-', linewidth=0.8)
    ax2.set_axisbelow(True)
    ax2.tick_params(axis='both', which='major', labelsize=12, width=1.5, length=6)
    
    # Thicker spines
    for spine in ax2.spines.values():
        spine.set_linewidth(1.5)
    
    # ========== ADD DATA SIZES INFO AT BOTTOM ==========
    
    data_sizes_text = ('Data sizes: 5-fold cross-validation on training set | '
                      'Training set: 384 images (98 MS + 286 Control) | '
                      'Each fold: ~307 training, ~77 validation')
    
    fig.text(0.5, 0.02, data_sizes_text, ha='center', fontsize=11, fontweight='bold',
             bbox=dict(boxstyle='round,pad=0.6', facecolor='lightblue', alpha=0.7, 
                      edgecolor='navy', linewidth=1.5))
    
    plt.tight_layout(rect=[0, 0.06, 1, 1])
    plt.savefig(output_path, dpi=300, bbox_inches='tight', 
               facecolor='white', edgecolor='none')
    plt.close()
    
    print(f"✅ Cross-validation results plot saved: {output_path}")
    
    # Print statistics
    print("\n📊 Cross-Validation Statistics:")
    print("=" * 60)
    for metric_name, mean, std in zip(metrics_names, means, stds):
        print(f"{metric_name:12s}: μ={mean:.3f}, σ={std:.3f}")
    print("=" * 60)
    
    return means, stds


# ========== EXAMPLE USAGE ==========

if __name__ == "__main__":
    print("📊 CROSS-VALIDATION RESULTS PLOT - EXAMPLE")
    print("=" * 60)
    
    # Example data (replace with your actual cross-validation results)
    cv_results_example = {
        'accuracy': [0.587, 0.623, 0.610, 0.571, 0.597],
        'precision': [0.534, 0.623, 0.571, 0.545, 0.623],
        'recall': [0.434, 0.571, 0.532, 0.377, 0.506],
        'f1_score': [0.377, 0.545, 0.506, 0.429, 0.558],
        'roc_auc': [0.560, 0.623, 0.597, 0.545, 0.610]
    }
    
    # Create the plot
    means, stds = create_cross_validation_results(
        cv_results_example, 
        output_path='/home/ubuntu/analysis/cv_results_example.png'
    )
    
    print("\n✅ Example plot created successfully!")
    print("\nTo use with your own data:")
    print("1. Perform 5-fold cross-validation")
    print("2. Collect scores for each fold")
    print("3. Pass to create_cross_validation_results()")
    
    print("\n" + "=" * 60)
    print("🎉 SUCCESS")
    print("=" * 60)
