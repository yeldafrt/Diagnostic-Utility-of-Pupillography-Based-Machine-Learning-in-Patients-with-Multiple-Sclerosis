#!/usr/bin/env python3
"""
Create Improved Precision-Recall Curve - WITHOUT MAIN TITLE
Higher readability with larger fonts and better layout
"""

import matplotlib.pyplot as plt
import numpy as np

print("📊 CREATING IMPROVED PRECISION-RECALL CURVE (NO TITLE)")
print("=" * 80)

# Precision-Recall curve data extracted from the original figure
# AUC = 0.899 (excellent performance)
# Approximate Recall and Precision values from the figure
recall = np.array([0.0, 0.06, 0.31, 0.38, 0.50, 0.56, 0.69, 0.81, 0.88, 0.94, 1.0])
precision = np.array([1.0, 1.0, 1.0, 0.88, 0.89, 0.90, 0.85, 0.87, 0.85, 0.79, 0.76])

auc_value = 0.899

# Create figure with improved size and quality
fig, ax = plt.subplots(figsize=(10, 8), dpi=300)
fig.patch.set_facecolor('white')

# Plot PR curve with thicker line
ax.plot(recall, precision, color='blue', linewidth=3, 
        label=f'PR Curve (AUC = {auc_value:.3f})', zorder=3)

# Styling - NO TITLE
ax.set_xlim([0.0, 1.0])
ax.set_ylim([0.0, 1.05])
ax.set_xlabel('Recall', fontsize=16, fontweight='bold', labelpad=10)
ax.set_ylabel('Precision', fontsize=16, fontweight='bold', labelpad=10)

# Legend with larger font - moved to upper right for better visibility
ax.legend(loc="lower left", fontsize=13, framealpha=0.95, 
          edgecolor='black', fancybox=True, shadow=True)

# Grid with better visibility
ax.grid(True, alpha=0.4, linestyle='-', linewidth=0.8, zorder=1)
ax.set_axisbelow(True)

# Tick parameters
ax.tick_params(axis='both', which='major', labelsize=14, width=1.5, length=6)

# Thicker spines
for spine in ax.spines.values():
    spine.set_linewidth(1.5)

plt.tight_layout()

# Save with high quality
output_file = '/home/ubuntu/analysis/pr_curve_improved.png'
plt.savefig(output_file, dpi=300, bbox_inches='tight', 
            facecolor='white', edgecolor='none')
plt.close()

print(f"✅ Improved Precision-Recall curve saved: {output_file}")

# Print statistics
print("\n📊 Precision-Recall Curve Statistics:")
print("=" * 80)
print(f"AUC-PR (Average Precision): {auc_value:.3f}")
print(f"Performance: Excellent (AUC-PR > 0.8)")
print(f"Interpretation:")
print(f"  - The model maintains high precision across different recall levels")
print(f"  - AUC-PR of {auc_value:.3f} indicates strong classification performance")
print(f"  - Particularly useful for imbalanced datasets")
print(f"  - The curve stays close to the top, indicating good precision-recall trade-off")

print("\n" + "=" * 80)
print("🎉 SUCCESS - IMPROVED PR CURVE CREATED (NO TITLE)")
print("=" * 80)
print("Features:")
print("  ✅ Resolution: 300 DPI")
print("  ✅ Figure size: 10x8 inches")
print("  ✅ Font sizes: 13-16pt (large)")
print("  ✅ PR line: 3pt (thick, blue)")
print("  ✅ Better grid visibility")
print("  ✅ Enhanced legend with shadow")
print("  ✅ NO main title (for figure caption)")
print("  ✅ Professional appearance")
print("=" * 80)
