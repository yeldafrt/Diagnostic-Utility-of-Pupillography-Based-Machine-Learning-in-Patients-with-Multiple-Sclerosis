"""
Visualization module for MS Pupillography ML
Generates publication-quality figures (300 DPI)
"""

from .create_confusion_matrix_improved import create_confusion_matrix
from .create_roc_curve_improved import create_roc_curve
from .create_pr_curve_improved import create_pr_curve
from .create_feature_importance_no_title import create_feature_importance
from .create_cv_results_code import create_cross_validation_results
from .create_spec_sens_roc_improved import create_specificity_sensitivity_roc
from .threshold_analysis_code import create_threshold_analysis
from .create_architecture_diagrams import (
    create_random_forest_architecture,
    create_feature_engineering_pipeline,
    create_data_flow_diagram,
    create_prediction_pipeline
)
from .workflow_diagram_v2 import create_workflow_diagram

__all__ = [
    'create_confusion_matrix',
    'create_roc_curve',
    'create_pr_curve',
    'create_feature_importance',
    'create_cross_validation_results',
    'create_specificity_sensitivity_roc',
    'create_threshold_analysis',
    'create_random_forest_architecture',
    'create_feature_engineering_pipeline',
    'create_data_flow_diagram',
    'create_prediction_pipeline',
    'create_workflow_diagram',
]
