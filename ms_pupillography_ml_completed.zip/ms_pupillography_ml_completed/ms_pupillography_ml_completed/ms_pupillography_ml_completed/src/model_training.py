#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, roc_curve
import tensorflow as tf
from tensorflow.keras.applications import ResNet50, VGG16, EfficientNetB0
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout, BatchNormalization
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import pickle

# Sabit değerler
IMG_SIZE = (224, 224)
BATCH_SIZE = 16  # Küçük veri seti için daha küçük batch size
EPOCHS = 100
LEARNING_RATE = 0.0001

def load_preprocessed_data():
    """Ön işlenmiş veriyi yükle"""
    
    print("Ön işlenmiş veriler yükleniyor...")
    
    X_train = np.load('/home/ubuntu/ms_oct_project/data/X_train.npy')
    y_train = np.load('/home/ubuntu/ms_oct_project/data/y_train.npy')
    X_val = np.load('/home/ubuntu/ms_oct_project/data/X_val.npy')
    y_val = np.load('/home/ubuntu/ms_oct_project/data/y_val.npy')
    X_test = np.load('/home/ubuntu/ms_oct_project/data/X_test.npy')
    y_test = np.load('/home/ubuntu/ms_oct_project/data/y_test.npy')
    
    # Label encoder'ı yükle
    with open('/home/ubuntu/ms_oct_project/models/label_encoder.pkl', 'rb') as f:
        le = pickle.load(f)
    
    print(f"Eğitim seti: {X_train.shape}")
    print(f"Doğrulama seti: {X_val.shape}")
    print(f"Test seti: {X_test.shape}")
    
    return (X_train, y_train), (X_val, y_val), (X_test, y_test), le

def create_resnet_model(input_shape=(224, 224, 3), num_classes=1):
    """ResNet50 tabanlı transfer learning modeli oluştur"""
    
    # Önceden eğitilmiş ResNet50 modelini yükle
    base_model = ResNet50(
        weights='imagenet',
        include_top=False,
        input_shape=input_shape
    )
    
    # İlk katmanları dondurmayalım (fine-tuning için)
    base_model.trainable = True
    
    # Son birkaç katmanı eğitilebilir yap
    for layer in base_model.layers[:-20]:
        layer.trainable = False
    
    # Yeni katmanlar ekle
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = BatchNormalization()(x)
    x = Dense(512, activation='relu')(x)
    x = Dropout(0.5)(x)
    x = Dense(256, activation='relu')(x)
    x = Dropout(0.3)(x)
    
    # Çıkış katmanı (binary classification)
    predictions = Dense(num_classes, activation='sigmoid')(x)
    
    # Modeli oluştur
    model = Model(inputs=base_model.input, outputs=predictions)
    
    return model

def create_efficientnet_model(input_shape=(224, 224, 3), num_classes=1):
    """EfficientNetB0 tabanlı transfer learning modeli oluştur"""
    
    # Önceden eğitilmiş EfficientNetB0 modelini yükle
    base_model = EfficientNetB0(
        weights='imagenet',
        include_top=False,
        input_shape=input_shape
    )
    
    # Fine-tuning için son katmanları eğitilebilir yap
    base_model.trainable = True
    for layer in base_model.layers[:-20]:
        layer.trainable = False
    
    # Yeni katmanlar ekle
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = BatchNormalization()(x)
    x = Dense(256, activation='relu')(x)
    x = Dropout(0.4)(x)
    x = Dense(128, activation='relu')(x)
    x = Dropout(0.2)(x)
    
    # Çıkış katmanı
    predictions = Dense(num_classes, activation='sigmoid')(x)
    
    # Modeli oluştur
    model = Model(inputs=base_model.input, outputs=predictions)
    
    return model

def create_data_generators(X_train, y_train, X_val, y_val):
    """Veri artırma için generator'lar oluştur"""
    
    # Eğitim için veri artırma
    train_datagen = ImageDataGenerator(
        rotation_range=15,
        width_shift_range=0.15,
        height_shift_range=0.15,
        horizontal_flip=True,
        zoom_range=0.15,
        brightness_range=[0.8, 1.2],
        fill_mode='nearest'
    )
    
    # Validation için sadece normalizasyon
    val_datagen = ImageDataGenerator()
    
    # Generator'ları oluştur
    train_generator = train_datagen.flow(
        X_train, y_train,
        batch_size=BATCH_SIZE,
        shuffle=True
    )
    
    val_generator = val_datagen.flow(
        X_val, y_val,
        batch_size=BATCH_SIZE,
        shuffle=False
    )
    
    return train_generator, val_generator

def train_model(model, train_generator, val_generator, model_name):
    """Modeli eğit"""
    
    print(f"\n{model_name} modeli eğitiliyor...")
    
    # Optimizer
    optimizer = Adam(learning_rate=LEARNING_RATE)
    
    # Modeli derle
    model.compile(
        optimizer=optimizer,
        loss='binary_crossentropy',
        metrics=['accuracy', 'precision', 'recall']
    )
    
    # Callback'ler
    callbacks = [
        EarlyStopping(
            monitor='val_loss',
            patience=15,
            restore_best_weights=True,
            verbose=1
        ),
        ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=8,
            min_lr=1e-7,
            verbose=1
        ),
        ModelCheckpoint(
            f'/home/ubuntu/ms_oct_project/models/{model_name}_best.h5',
            monitor='val_loss',
            save_best_only=True,
            verbose=1
        )
    ]
    
    # Modeli eğit
    history = model.fit(
        train_generator,
        epochs=EPOCHS,
        validation_data=val_generator,
        callbacks=callbacks,
        verbose=1
    )
    
    return history

def plot_training_history(history, model_name):
    """Eğitim geçmişini görselleştir"""
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # Loss
    axes[0, 0].plot(history.history['loss'], label='Eğitim Loss')
    axes[0, 0].plot(history.history['val_loss'], label='Doğrulama Loss')
    axes[0, 0].set_title('Model Loss')
    axes[0, 0].set_xlabel('Epoch')
    axes[0, 0].set_ylabel('Loss')
    axes[0, 0].legend()
    
    # Accuracy
    axes[0, 1].plot(history.history['accuracy'], label='Eğitim Accuracy')
    axes[0, 1].plot(history.history['val_accuracy'], label='Doğrulama Accuracy')
    axes[0, 1].set_title('Model Accuracy')
    axes[0, 1].set_xlabel('Epoch')
    axes[0, 1].set_ylabel('Accuracy')
    axes[0, 1].legend()
    
    # Precision
    axes[1, 0].plot(history.history['precision'], label='Eğitim Precision')
    axes[1, 0].plot(history.history['val_precision'], label='Doğrulama Precision')
    axes[1, 0].set_title('Model Precision')
    axes[1, 0].set_xlabel('Epoch')
    axes[1, 0].set_ylabel('Precision')
    axes[1, 0].legend()
    
    # Recall
    axes[1, 1].plot(history.history['recall'], label='Eğitim Recall')
    axes[1, 1].plot(history.history['val_recall'], label='Doğrulama Recall')
    axes[1, 1].set_title('Model Recall')
    axes[1, 1].set_xlabel('Epoch')
    axes[1, 1].set_ylabel('Recall')
    axes[1, 1].legend()
    
    plt.tight_layout()
    plt.savefig(f'/home/ubuntu/ms_oct_project/results/{model_name}_training_history.png', 
                dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"Eğitim geçmişi grafiği kaydedildi: results/{model_name}_training_history.png")

def evaluate_model(model, X_test, y_test, model_name, le):
    """Modeli test verisi üzerinde değerlendir"""
    
    print(f"\n{model_name} modeli değerlendiriliyor...")
    
    # Tahmin yap
    y_pred_proba = model.predict(X_test, batch_size=BATCH_SIZE)
    y_pred = (y_pred_proba > 0.5).astype(int).flatten()
    
    # Metrikleri hesapla
    accuracy = np.mean(y_pred == y_test)
    auc_score = roc_auc_score(y_test, y_pred_proba)
    
    print(f"Test Accuracy: {accuracy:.4f}")
    print(f"AUC Score: {auc_score:.4f}")
    
    # Classification report
    class_names = le.classes_
    report = classification_report(y_test, y_pred, target_names=class_names)
    print(f"\nClassification Report:\n{report}")
    
    # Confusion Matrix
    cm = confusion_matrix(y_test, y_pred)
    
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=class_names, yticklabels=class_names)
    plt.title(f'{model_name} - Confusion Matrix')
    plt.ylabel('Gerçek Etiket')
    plt.xlabel('Tahmin Edilen Etiket')
    plt.savefig(f'/home/ubuntu/ms_oct_project/results/{model_name}_confusion_matrix.png', 
                dpi=300, bbox_inches='tight')
    plt.close()
    
    # ROC Curve
    fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
    
    plt.figure(figsize=(8, 6))
    plt.plot(fpr, tpr, label=f'{model_name} (AUC = {auc_score:.3f})')
    plt.plot([0, 1], [0, 1], 'k--', label='Random')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title(f'{model_name} - ROC Curve')
    plt.legend()
    plt.grid(True)
    plt.savefig(f'/home/ubuntu/ms_oct_project/results/{model_name}_roc_curve.png', 
                dpi=300, bbox_inches='tight')
    plt.close()
    
    return {
        'accuracy': accuracy,
        'auc_score': auc_score,
        'classification_report': report,
        'confusion_matrix': cm,
        'y_pred': y_pred,
        'y_pred_proba': y_pred_proba
    }

def main():
    """Ana fonksiyon"""
    
    # Veriyi yükle
    (X_train, y_train), (X_val, y_val), (X_test, y_test), le = load_preprocessed_data()
    
    # Veri generator'larını oluştur
    train_generator, val_generator = create_data_generators(X_train, y_train, X_val, y_val)
    
    # Model sonuçlarını saklamak için
    results = {}
    
    # ResNet50 modeli
    print("\n" + "="*50)
    print("ResNet50 Modeli")
    print("="*50)
    
    resnet_model = create_resnet_model()
    print(f"ResNet50 model parametreleri: {resnet_model.count_params():,}")
    
    resnet_history = train_model(resnet_model, train_generator, val_generator, "resnet50")
    plot_training_history(resnet_history, "resnet50")
    
    # En iyi modeli yükle ve değerlendir
    resnet_model.load_weights('/home/ubuntu/ms_oct_project/models/resnet50_best.h5')
    resnet_results = evaluate_model(resnet_model, X_test, y_test, "ResNet50", le)
    results['ResNet50'] = resnet_results
    
    # EfficientNetB0 modeli
    print("\n" + "="*50)
    print("EfficientNetB0 Modeli")
    print("="*50)
    
    efficientnet_model = create_efficientnet_model()
    print(f"EfficientNetB0 model parametreleri: {efficientnet_model.count_params():,}")
    
    efficientnet_history = train_model(efficientnet_model, train_generator, val_generator, "efficientnet")
    plot_training_history(efficientnet_history, "efficientnet")
    
    # En iyi modeli yükle ve değerlendir
    efficientnet_model.load_weights('/home/ubuntu/ms_oct_project/models/efficientnet_best.h5')
    efficientnet_results = evaluate_model(efficientnet_model, X_test, y_test, "EfficientNetB0", le)
    results['EfficientNetB0'] = efficientnet_results
    
    # Sonuçları karşılaştır
    print("\n" + "="*50)
    print("MODEL KARŞILAŞTIRMASI")
    print("="*50)
    
    comparison_data = []
    for model_name, result in results.items():
        comparison_data.append({
            'Model': model_name,
            'Accuracy': result['accuracy'],
            'AUC Score': result['auc_score']
        })
    
    comparison_df = pd.DataFrame(comparison_data)
    print(comparison_df.to_string(index=False))
    
    # En iyi modeli belirle
    best_model_name = comparison_df.loc[comparison_df['AUC Score'].idxmax(), 'Model']
    print(f"\nEn iyi model: {best_model_name}")
    
    # Karşılaştırma tablosunu kaydet
    comparison_df.to_csv('/home/ubuntu/ms_oct_project/results/model_comparison.csv', index=False)
    
    print(f"\nModel eğitimi tamamlandı!")
    print(f"En iyi model: {best_model_name}")
    print(f"Sonuçlar '/home/ubuntu/ms_oct_project/results/' klasöründe kaydedildi.")

if __name__ == "__main__":
    main()

