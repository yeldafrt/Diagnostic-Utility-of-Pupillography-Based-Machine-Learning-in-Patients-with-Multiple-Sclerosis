"""
Evaluation module for MS Pupillography ML
Computes performance metrics and ICC analysis
"""

def compute_metrics(y_true, y_pred, y_scores=None):
    """Compute all performance metrics"""
    pass

def compute_icc(features_df, patient_id_column):
    """Compute intra-class correlation coefficients"""
    pass

__all__ = ['compute_metrics', 'compute_icc']
