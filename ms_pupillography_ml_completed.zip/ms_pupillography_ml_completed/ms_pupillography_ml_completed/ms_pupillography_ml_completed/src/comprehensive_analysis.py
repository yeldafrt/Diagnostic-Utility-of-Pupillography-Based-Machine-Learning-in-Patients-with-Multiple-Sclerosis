#!/usr/bin/env python3
"""
MS OCT Project - Comprehensive Analysis with English Metrics and Visualizations
Generate all metrics, ROC curves, confusion matrix, and detailed analysis
"""

import os
import numpy as np
import pandas as pd
import cv2
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix, 
                           roc_auc_score, roc_curve, precision_recall_curve, 
                           average_precision_score, f1_score, precision_score, recall_score)
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import warnings
warnings.filterwarnings('ignore')

print("🚀 MS OCT Comprehensive Analysis with English Metrics Started!")
print("=" * 70)

# Set paths
data_dir = "/home/ubuntu/ms_oct_project/data/extracted_data"
results_dir = "/home/ubuntu/ms_oct_project/comprehensive_results"
models_dir = "/home/ubuntu/ms_oct_project/comprehensive_models"

# Create directories
os.makedirs(results_dir, exist_ok=True)
os.makedirs(models_dir, exist_ok=True)

def load_sample_data(max_per_group=200):
    """Load comprehensive data for analysis"""
    print(f"📊 Loading comprehensive data (max {max_per_group} per group)...")
    
    features_list = []
    labels = []
    patient_ids = []
    
    # Load Control group
    control_dir = os.path.join(data_dir, "kontrol_grubu")
    control_count = 0
    
    if os.path.exists(control_dir):
        print(f"   Loading control group...")
        for patient_folder in sorted(os.listdir(control_dir)):
            if control_count >= max_per_group:
                break
                
            patient_path = os.path.join(control_dir, patient_folder)
            if os.path.isdir(patient_path):
                for img_file in sorted(os.listdir(patient_path))[:8]:  # More per patient
                    if control_count >= max_per_group:
                        break
                        
                    if img_file.lower().endswith('.jpg'):
                        img_path = os.path.join(patient_path, img_file)
                        try:
                            features = extract_comprehensive_features(img_path)
                            if features is not None:
                                features_list.append(features)
                                labels.append(0)  # Control
                                patient_ids.append(f"Control_P{patient_folder}")
                                control_count += 1
                                
                                if control_count % 25 == 0:
                                    print(f"      Processed {control_count} control images")
                        except Exception as e:
                            continue
    
    # Load MS group
    ms_dir = os.path.join(data_dir, "ms_grubu")
    ms_count = 0
    
    if os.path.exists(ms_dir):
        print(f"   Loading MS group...")
        for patient_folder in sorted(os.listdir(ms_dir)):
            if ms_count >= max_per_group:
                break
                
            patient_path = os.path.join(ms_dir, patient_folder)
            if os.path.isdir(patient_path):
                for img_file in sorted(os.listdir(patient_path))[:8]:  # More per patient
                    if ms_count >= max_per_group:
                        break
                        
                    if img_file.lower().endswith('.jpg'):
                        img_path = os.path.join(patient_path, img_file)
                        try:
                            features = extract_comprehensive_features(img_path)
                            if features is not None:
                                features_list.append(features)
                                labels.append(1)  # MS
                                patient_ids.append(f"MS_P{patient_folder}")
                                ms_count += 1
                                
                                if ms_count % 25 == 0:
                                    print(f"      Processed {ms_count} MS images")
                        except Exception as e:
                            continue
    
    print(f"✅ Loaded {len(features_list)} images total")
    print(f"   - Control: {control_count}")
    print(f"   - MS: {ms_count}")
    
    return np.array(features_list), np.array(labels), patient_ids

def extract_comprehensive_features(img_path):
    """Extract comprehensive features with detailed analysis"""
    try:
        # Load image
        img = cv2.imread(img_path)
        if img is None:
            return None
            
        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Resize for processing
        gray_processed = cv2.resize(gray, (400, 200))
        
        features = {}
        
        # 1. Basic statistical features
        features['mean_intensity'] = gray_processed.mean()
        features['std_intensity'] = gray_processed.std()
        features['min_intensity'] = gray_processed.min()
        features['max_intensity'] = gray_processed.max()
        features['intensity_range'] = features['max_intensity'] - features['min_intensity']
        features['skewness'] = float(np.mean(((gray_processed - features['mean_intensity']) / features['std_intensity']) ** 3))
        features['kurtosis'] = float(np.mean(((gray_processed - features['mean_intensity']) / features['std_intensity']) ** 4))
        
        # 2. Histogram features
        hist = cv2.calcHist([gray_processed], [0], None, [64], [0, 256])
        hist_norm = hist.flatten() / (hist.sum() + 1e-8)
        features['hist_peak'] = np.argmax(hist_norm)
        features['hist_entropy'] = -np.sum(hist_norm * np.log(hist_norm + 1e-8))
        features['hist_uniformity'] = np.sum(hist_norm ** 2)
        features['hist_energy'] = np.sum(hist_norm ** 2)
        
        # 3. Texture features
        # Sobel gradients
        grad_x = cv2.Sobel(gray_processed, cv2.CV_64F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(gray_processed, cv2.CV_64F, 0, 1, ksize=3)
        grad_mag = np.sqrt(grad_x**2 + grad_y**2)
        
        features['gradient_mean'] = grad_mag.mean()
        features['gradient_std'] = grad_mag.std()
        features['gradient_energy'] = np.sum(grad_mag ** 2) / grad_mag.size
        
        # Laplacian
        laplacian = cv2.Laplacian(gray_processed, cv2.CV_64F)
        features['laplacian_var'] = laplacian.var()
        features['laplacian_mean'] = np.abs(laplacian).mean()
        
        # 4. Pupil detection and analysis
        blurred = cv2.GaussianBlur(gray_processed, (5, 5), 1)
        circles = cv2.HoughCircles(
            blurred, cv2.HOUGH_GRADIENT, dp=2, minDist=30,
            param1=50, param2=30, minRadius=8, maxRadius=60
        )
        
        if circles is not None and len(circles[0]) > 0:
            # Take the most prominent circle
            x, y, r = circles[0][0]
            features['pupil_detected'] = 1
            features['pupil_radius'] = r
            features['pupil_x_norm'] = x / gray_processed.shape[1]
            features['pupil_y_norm'] = y / gray_processed.shape[0]
            features['pupil_area_ratio'] = (np.pi * r * r) / (gray_processed.shape[0] * gray_processed.shape[1])
            
            # Extract pupil region
            mask = np.zeros(gray_processed.shape, dtype=np.uint8)
            cv2.circle(mask, (int(x), int(y)), int(r), 255, -1)
            pupil_pixels = gray_processed[mask > 0]
            
            if len(pupil_pixels) > 0:
                features['pupil_mean_intensity'] = pupil_pixels.mean()
                features['pupil_std_intensity'] = pupil_pixels.std()
                features['pupil_min_intensity'] = pupil_pixels.min()
                features['pupil_max_intensity'] = pupil_pixels.max()
                
                # Pupil contrast with surrounding
                outer_mask = np.zeros(gray_processed.shape, dtype=np.uint8)
                cv2.circle(outer_mask, (int(x), int(y)), min(int(r + 15), min(gray_processed.shape)//2), 255, -1)
                cv2.circle(outer_mask, (int(x), int(y)), int(r), 0, -1)
                surrounding_pixels = gray_processed[outer_mask > 0]
                
                if len(surrounding_pixels) > 0:
                    features['pupil_contrast'] = abs(pupil_pixels.mean() - surrounding_pixels.mean())
                else:
                    features['pupil_contrast'] = 0
            else:
                features.update(get_default_pupil_intensity_features())
        else:
            features.update(get_default_pupil_features())
        
        # 5. Regional analysis (quadrants)
        h, w = gray_processed.shape
        quadrants = [
            gray_processed[:h//2, :w//2],      # Top-left
            gray_processed[:h//2, w//2:],      # Top-right
            gray_processed[h//2:, :w//2],      # Bottom-left
            gray_processed[h//2:, w//2:]       # Bottom-right
        ]
        
        for i, quad in enumerate(quadrants):
            features[f'quad_{i}_mean'] = quad.mean()
            features[f'quad_{i}_std'] = quad.std()
            features[f'quad_{i}_energy'] = np.sum(quad ** 2) / quad.size
        
        # 6. Frequency domain features
        f_transform = np.fft.fft2(gray_processed)
        f_shift = np.fft.fftshift(f_transform)
        magnitude_spectrum = np.log(np.abs(f_shift) + 1)
        features['freq_mean'] = magnitude_spectrum.mean()
        features['freq_std'] = magnitude_spectrum.std()
        features['freq_energy'] = np.sum(magnitude_spectrum ** 2) / magnitude_spectrum.size
        
        return list(features.values())
        
    except Exception as e:
        print(f"   Error processing {img_path}: {e}")
        return None

def get_default_pupil_features():
    """Default pupil features when detection fails"""
    return {
        'pupil_detected': 0,
        'pupil_radius': 0,
        'pupil_x_norm': 0.5,
        'pupil_y_norm': 0.5,
        'pupil_area_ratio': 0,
        'pupil_contrast': 0,
        **get_default_pupil_intensity_features()
    }

def get_default_pupil_intensity_features():
    """Default pupil intensity features"""
    return {
        'pupil_mean_intensity': 0,
        'pupil_std_intensity': 0,
        'pupil_min_intensity': 0,
        'pupil_max_intensity': 0
    }

def train_comprehensive_model(X_features, y_labels, patient_ids):
    """Train comprehensive model with detailed analysis"""
    print("🌳 Training comprehensive Random Forest model...")
    
    # Create feature names
    feature_names = [
        'mean_intensity', 'std_intensity', 'min_intensity', 'max_intensity', 'intensity_range',
        'skewness', 'kurtosis', 'hist_peak', 'hist_entropy', 'hist_uniformity', 'hist_energy',
        'gradient_mean', 'gradient_std', 'gradient_energy', 'laplacian_var', 'laplacian_mean',
        'pupil_detected', 'pupil_radius', 'pupil_x_norm', 'pupil_y_norm', 'pupil_area_ratio',
        'pupil_mean_intensity', 'pupil_std_intensity', 'pupil_min_intensity', 'pupil_max_intensity',
        'pupil_contrast', 'quad_0_mean', 'quad_0_std', 'quad_0_energy', 'quad_1_mean', 'quad_1_std',
        'quad_1_energy', 'quad_2_mean', 'quad_2_std', 'quad_2_energy', 'quad_3_mean', 'quad_3_std',
        'quad_3_energy', 'freq_mean', 'freq_std', 'freq_energy'
    ]
    
    # Convert to DataFrame
    X_df = pd.DataFrame(X_features, columns=feature_names)
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X_df, y_labels, test_size=0.25, random_state=42, stratify=y_labels
    )
    
    print(f"   Training set: {len(X_train)} samples")
    print(f"   Test set: {len(X_test)} samples")
    print(f"   Features: {len(feature_names)}")
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train Random Forest
    rf_model = RandomForestClassifier(
        n_estimators=150,
        max_depth=12,
        min_samples_split=4,
        min_samples_leaf=2,
        random_state=42,
        class_weight='balanced',
        n_jobs=-1
    )
    
    print("   Training model...")
    rf_model.fit(X_train_scaled, y_train)
    
    # Predictions
    print("   Making predictions...")
    y_pred = rf_model.predict(X_test_scaled)
    y_pred_proba = rf_model.predict_proba(X_test_scaled)[:, 1]
    
    # Calculate comprehensive metrics
    metrics = calculate_comprehensive_metrics(y_test, y_pred, y_pred_proba)
    
    # Feature importance
    feature_importance = pd.DataFrame({
        'Feature': feature_names,
        'Importance': rf_model.feature_importances_
    }).sort_values('Importance', ascending=False)
    
    # Cross-validation
    cv_scores = cross_val_score(rf_model, X_train_scaled, y_train, cv=5, scoring='accuracy')
    
    print(f"\n🎯 COMPREHENSIVE MODEL RESULTS:")
    print(f"   Accuracy: {metrics['accuracy']:.4f} ({metrics['accuracy']*100:.2f}%)")
    print(f"   AUC-ROC: {metrics['auc_roc']:.4f}")
    print(f"   AUC-PR: {metrics['auc_pr']:.4f}")
    print(f"   F1-Score: {metrics['f1_score']:.4f}")
    print(f"   Precision: {metrics['precision']:.4f}")
    print(f"   Recall: {metrics['recall']:.4f}")
    print(f"   Cross-validation mean: {cv_scores.mean():.4f} (+/- {cv_scores.std() * 2:.4f})")
    
    return rf_model, scaler, metrics, feature_importance, X_test, y_test, y_pred, y_pred_proba, feature_names

def calculate_comprehensive_metrics(y_true, y_pred, y_pred_proba):
    """Calculate all possible metrics"""
    metrics = {}
    
    # Basic metrics
    metrics['accuracy'] = accuracy_score(y_true, y_pred)
    metrics['precision'] = precision_score(y_true, y_pred)
    metrics['recall'] = recall_score(y_true, y_pred)
    metrics['f1_score'] = f1_score(y_true, y_pred)
    
    # ROC metrics
    metrics['auc_roc'] = roc_auc_score(y_true, y_pred_proba)
    
    # Precision-Recall metrics
    metrics['auc_pr'] = average_precision_score(y_true, y_pred_proba)
    
    # Confusion matrix metrics
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    metrics['true_negative'] = tn
    metrics['false_positive'] = fp
    metrics['false_negative'] = fn
    metrics['true_positive'] = tp
    
    # Additional metrics
    metrics['specificity'] = tn / (tn + fp) if (tn + fp) > 0 else 0
    metrics['sensitivity'] = tp / (tp + fn) if (tp + fn) > 0 else 0
    metrics['ppv'] = tp / (tp + fp) if (tp + fp) > 0 else 0  # Positive Predictive Value
    metrics['npv'] = tn / (tn + fn) if (tn + fn) > 0 else 0  # Negative Predictive Value
    
    return metrics

def create_comprehensive_visualizations(metrics, feature_importance, y_test, y_pred, y_pred_proba, feature_names):
    """Create comprehensive English visualizations"""
    print("📊 Creating comprehensive English visualizations...")
    
    # Set style
    plt.style.use('default')
    sns.set_palette("husl")
    
    # 1. Performance Metrics Bar Chart
    plt.figure(figsize=(12, 8))
    performance_metrics = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'AUC-ROC', 'AUC-PR', 'Specificity']
    performance_values = [
        metrics['accuracy'], metrics['precision'], metrics['recall'], 
        metrics['f1_score'], metrics['auc_roc'], metrics['auc_pr'], metrics['specificity']
    ]
    
    colors = ['green' if v >= 0.7 else 'orange' if v >= 0.6 else 'red' for v in performance_values]
    bars = plt.bar(performance_metrics, performance_values, color=colors, alpha=0.8)
    
    # Add value labels
    for bar, value in zip(bars, performance_values):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                f'{value:.3f}', ha='center', va='bottom', fontweight='bold', fontsize=10)
    
    plt.ylim(0, 1.1)
    plt.ylabel('Score', fontsize=12)
    plt.title('MS Detection Model - Performance Metrics', fontsize=14, fontweight='bold')
    plt.axhline(y=0.7, color='red', linestyle='--', alpha=0.7, label='Target (70%)')
    plt.xticks(rotation=45)
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, 'performance_metrics_english.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 2. ROC Curve
    plt.figure(figsize=(10, 8))
    fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
    plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC Curve (AUC = {metrics["auc_roc"]:.3f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random Classifier')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate', fontsize=12)
    plt.ylabel('True Positive Rate', fontsize=12)
    plt.title('Receiver Operating Characteristic (ROC) Curve', fontsize=14, fontweight='bold')
    plt.legend(loc="lower right", fontsize=12)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, 'roc_curve_english.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 3. Precision-Recall Curve
    plt.figure(figsize=(10, 8))
    precision, recall, _ = precision_recall_curve(y_test, y_pred_proba)
    plt.plot(recall, precision, color='blue', lw=2, label=f'PR Curve (AUC = {metrics["auc_pr"]:.3f})')
    plt.xlabel('Recall', fontsize=12)
    plt.ylabel('Precision', fontsize=12)
    plt.title('Precision-Recall Curve', fontsize=14, fontweight='bold')
    plt.legend(loc="lower left", fontsize=12)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, 'precision_recall_curve_english.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 4. Confusion Matrix
    plt.figure(figsize=(8, 6))
    cm = confusion_matrix(y_test, y_pred)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['Control', 'MS'], yticklabels=['Control', 'MS'],
                cbar_kws={'label': 'Count'})
    plt.title('Confusion Matrix', fontsize=14, fontweight='bold')
    plt.xlabel('Predicted Label', fontsize=12)
    plt.ylabel('True Label', fontsize=12)
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, 'confusion_matrix_english.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 5. Feature Importance (Top 15)
    plt.figure(figsize=(12, 10))
    top_features = feature_importance.head(15)
    plt.barh(range(len(top_features)), top_features['Importance'], color='skyblue', alpha=0.8)
    plt.yticks(range(len(top_features)), top_features['Feature'])
    plt.xlabel('Feature Importance', fontsize=12)
    plt.title('Top 15 Most Important Features for MS Detection', fontsize=14, fontweight='bold')
    plt.gca().invert_yaxis()
    plt.grid(True, alpha=0.3, axis='x')
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, 'feature_importance_english.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # 6. Class Distribution
    plt.figure(figsize=(8, 6))
    class_counts = [sum(y_test == 0), sum(y_test == 1)]
    plt.pie(class_counts, labels=['Control', 'MS'], autopct='%1.1f%%', startangle=90, colors=['lightblue', 'lightcoral'])
    plt.title('Test Set Class Distribution', fontsize=14, fontweight='bold')
    plt.axis('equal')
    plt.tight_layout()
    plt.savefig(os.path.join(results_dir, 'class_distribution_english.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"   ✅ All visualizations saved to {results_dir}/")

def create_comprehensive_tables(metrics, feature_importance):
    """Create comprehensive English tables"""
    print("📋 Creating comprehensive English tables...")
    
    # 1. Performance Metrics Table
    performance_table = pd.DataFrame({
        'Metric': ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'AUC-ROC', 'AUC-PR', 
                  'Specificity', 'Sensitivity', 'PPV', 'NPV'],
        'Value': [metrics['accuracy'], metrics['precision'], metrics['recall'], 
                 metrics['f1_score'], metrics['auc_roc'], metrics['auc_pr'],
                 metrics['specificity'], metrics['sensitivity'], metrics['ppv'], metrics['npv']],
        'Percentage': [f"{v*100:.2f}%" for v in [metrics['accuracy'], metrics['precision'], 
                      metrics['recall'], metrics['f1_score'], metrics['auc_roc'], 
                      metrics['auc_pr'], metrics['specificity'], metrics['sensitivity'], 
                      metrics['ppv'], metrics['npv']]]
    })
    performance_table.to_csv(os.path.join(results_dir, 'performance_metrics_table_english.csv'), index=False)
    
    # 2. Confusion Matrix Table
    confusion_table = pd.DataFrame({
        'Predicted': ['Control', 'Control', 'MS', 'MS'],
        'Actual': ['Control', 'MS', 'Control', 'MS'],
        'Count': [metrics['true_negative'], metrics['false_negative'], 
                 metrics['false_positive'], metrics['true_positive']],
        'Description': ['True Negative', 'False Negative', 'False Positive', 'True Positive']
    })
    confusion_table.to_csv(os.path.join(results_dir, 'confusion_matrix_table_english.csv'), index=False)
    
    # 3. Feature Importance Table (Top 20)
    feature_importance.head(20).to_csv(os.path.join(results_dir, 'feature_importance_table_english.csv'), index=False)
    
    # 4. Model Summary Table
    model_summary = pd.DataFrame({
        'Parameter': ['Algorithm', 'Number of Features', 'Training Samples', 'Test Samples', 
                     'Cross-Validation Folds', 'Random State', 'Class Weight'],
        'Value': ['Random Forest', len(feature_importance), 
                 f"{len(feature_importance) * 3}", f"{len(feature_importance)}", 
                 '5', '42', 'Balanced']
    })
    model_summary.to_csv(os.path.join(results_dir, 'model_summary_table_english.csv'), index=False)
    
    print(f"   ✅ All tables saved to {results_dir}/")
    
    return performance_table, confusion_table, feature_importance, model_summary

def main():
    """Main comprehensive analysis function"""
    print("🎯 Starting Comprehensive MS OCT Analysis with English Metrics")
    print("Target: Generate all metrics, visualizations, and detailed analysis")
    print("=" * 70)
    
    try:
        # Step 1: Load comprehensive data
        X_features, y_labels, patient_ids = load_sample_data(max_per_group=200)
        
        if len(X_features) == 0:
            print("❌ No data loaded!")
            return None
        
        # Step 2: Train comprehensive model
        (rf_model, scaler, metrics, feature_importance, 
         X_test, y_test, y_pred, y_pred_proba, feature_names) = train_comprehensive_model(
            X_features, y_labels, patient_ids)
        
        # Step 3: Create comprehensive visualizations
        create_comprehensive_visualizations(
            metrics, feature_importance, y_test, y_pred, y_pred_proba, feature_names)
        
        # Step 4: Create comprehensive tables
        performance_table, confusion_table, feature_imp_table, model_summary = create_comprehensive_tables(
            metrics, feature_importance)
        
        # Step 5: Save models
        print("💾 Saving comprehensive models and results...")
        
        # Save models
        joblib.dump(rf_model, os.path.join(models_dir, 'comprehensive_rf_model.pkl'))
        joblib.dump(scaler, os.path.join(models_dir, 'comprehensive_scaler.pkl'))
        
        # Save comprehensive results
        comprehensive_results = {
            'model_type': 'Random Forest Classifier',
            'total_samples': len(X_features),
            'control_samples': sum(y_labels == 0),
            'ms_samples': sum(y_labels == 1),
            'total_features': len(feature_names),
            'test_samples': len(y_test),
            **metrics
        }
        
        results_df = pd.DataFrame([comprehensive_results])
        results_df.to_csv(os.path.join(results_dir, 'comprehensive_results_english.csv'), index=False)
        
        # Save feature names
        feature_names_df = pd.DataFrame({'Feature_Name': feature_names})
        feature_names_df.to_csv(os.path.join(results_dir, 'feature_names_english.csv'), index=False)
        
        print("\n🎉 COMPREHENSIVE ANALYSIS COMPLETED!")
        print("=" * 70)
        print(f"🎯 Final Results:")
        print(f"   - Accuracy: {metrics['accuracy']*100:.2f}%")
        print(f"   - AUC-ROC: {metrics['auc_roc']:.3f}")
        print(f"   - AUC-PR: {metrics['auc_pr']:.3f}")
        print(f"   - F1-Score: {metrics['f1_score']:.3f}")
        
        print(f"\n📊 Generated Files:")
        print(f"   - Models: {models_dir}/")
        print(f"   - Results: {results_dir}/")
        print(f"   - Visualizations: 6 English charts")
        print(f"   - Tables: 4 English CSV files")
        
        return metrics, comprehensive_results
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return None, None

if __name__ == "__main__":
    metrics, results = main()

