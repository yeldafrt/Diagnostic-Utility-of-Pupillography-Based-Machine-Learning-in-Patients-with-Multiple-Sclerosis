# Source Code Directory

This directory contains all source code for the MS pupillography machine learning project.

## 📁 Directory Structure

```
src/
├── preprocessing/              # Image preprocessing
│   ├── __init__.py
│   └── preprocess.py          # Resize, normalize, quality check
├── feature_extraction/        # Feature extraction
│   ├── __init__.py
│   └── extract_features.py    # Extract 22 features
├── model_training/            # Model training utilities
│   └── __init__.py
├── evaluation/                # Evaluation metrics
│   └── __init__.py
├── visualization/             # Figure generation scripts
│   ├── __init__.py
│   ├── create_confusion_matrix_improved.py
│   ├── create_roc_curve_improved.py
│   ├── create_pr_curve_improved.py
│   ├── create_feature_importance_no_title.py
│   ├── create_spec_sens_roc_improved.py
│   ├── threshold_analysis_code.py
│   ├── create_cv_results_code.py
│   ├── add_data_sizes_to_figureCV.py
│   ├── create_TRAIN_VALIDATION_with_data_sizes_.py
│   ├── create_architecture_diagrams.py
│   └── workflow_diagram_v2.py
├── patient_based_analysis.py      # Main analysis script (manuscript)
├── comprehensive_analysis.py      # Comprehensive feature extraction
├── complete_real_analysis.py      # Complete analysis pipeline
├── apply_saved_model.py           # Apply trained model to new data
├── data_preprocessing.py          # Data preprocessing utilities
├── model_training.py              # Model training script
└── data_cleaning_feature_engineering.py  # Data cleaning and feature engineering
```

## 🚀 Main Analysis Scripts

### 1. patient_based_analysis.py ⭐ (Primary Script)
**This is the main script used in the manuscript.**

- Implements patient-based stratified evaluation
- Trains Random Forest model with optimized hyperparameters
- Generates all performance metrics reported in the paper
- Creates publication-quality figures

**Usage:**
```bash
python src/patient_based_analysis.py
```

**Results:**
- **Accuracy:** 85.7%
- **Sensitivity:** 93.8%
- **Specificity:** 80.8%
- **AUC-ROC:** 0.945
- **AUC-PR:** 0.920

### 2. comprehensive_analysis.py
Complete feature extraction and analysis pipeline.

**Usage:**
```bash
python src/comprehensive_analysis.py
```

### 3. complete_real_analysis.py
End-to-end analysis with real data.

**Usage:**
```bash
python src/complete_real_analysis.py
```

### 4. apply_saved_model.py
Apply pre-trained model to new images.

**Usage:**
```bash
python src/apply_saved_model.py --image path/to/image.jpg
```

## 📊 Dataset Information

### Full Dataset (From Manuscript)
- **Total images:** 692 pupillographic images
- **Total participants:** 63 (25 MS, 38 Control)
- **MS images:** 274
- **Control images:** 418

### Train/Test Split
- **Training set:** 384 images from 35 patients (9 MS, 26 Control)
- **Test set:** 308 images from 28 patients (16 MS, 12 Control)
- **Evaluation:** Patient-based stratified split

## 🔧 Module Usage

### Feature Extraction

```python
from src.feature_extraction import extract_features

# Extract 22 features from an image
features = extract_features('path/to/image.jpg')
print(f"Extracted {len(features)} features")
```

### Preprocessing

```python
from src.preprocessing import preprocess

# Preprocess image
processed_img = preprocess('path/to/image.jpg', target_size=(400, 200))
```

### Model Training

```python
from src.model_training import train_random_forest

# Train model
model, scaler = train_random_forest(X_train, y_train)
```

## 📈 Visualization Scripts

All visualization scripts generate publication-quality figures at 300 DPI:

1. **create_confusion_matrix_improved.py** - Confusion matrix
2. **create_roc_curve_improved.py** - ROC curve (AUC = 0.945)
3. **create_pr_curve_improved.py** - Precision-Recall curve (AUC = 0.920)
4. **create_feature_importance_no_title.py** - Feature importance
5. **create_spec_sens_roc_improved.py** - Specificity-Sensitivity analysis
6. **threshold_analysis_code.py** - Threshold analysis
7. **create_cv_results_code.py** - Cross-validation results
8. **add_data_sizes_to_figureCV.py** - CV with data sizes
9. **create_TRAIN_VALIDATION_with_data_sizes_.py** - Training/validation curves
10. **create_architecture_diagrams.py** - Model architecture diagram
11. **workflow_diagram_v2.py** - Workflow diagram

**Usage:**
```bash
python src/visualization/create_confusion_matrix_improved.py
```

## 🔬 Model Specifications

### Random Forest Classifier
- **Number of trees:** 100
- **Max depth:** 10
- **Min samples split:** 5
- **Min samples leaf:** 3
- **Class weight:** Balanced
- **Random state:** 42

### Features (22 total)
1. **Basic Statistics (5):** mean, std, min, max, range
2. **Pupil Morphology (6):** detection, radius, position, intensity
3. **Texture Analysis (4):** gradient, Laplacian
4. **Histogram (3):** entropy, uniformity, peak
5. **Regional Analysis (4):** quadrant means

## 📦 Dependencies

All scripts require:
- Python >= 3.8
- numpy >= 1.21.0
- pandas >= 1.3.0
- scikit-learn >= 1.0.0
- opencv-python >= 4.5.0
- matplotlib >= 3.4.0
- seaborn >= 0.11.0

See `requirements.txt` for complete list.

## 📄 Citation

If you use this code, please cite our paper:

> Neslihan Parmak Yener, Yelda Fırat, Meral Seferoğlu, Ahmet Metin Kargın, Yılmaz Kılıçaslan. "Diagnostic Utility of Pupillography-Based Machine Learning in Patients with Multiple Sclerosis." (Under review)

## 📧 Contact

For questions about the code:
- **Email:** drnparmak@yahoo.com, parmakyener@gmail.com
- **GitHub Issues:** [Create an issue](https://github.com/yourusername/ms_pupillography_ml/issues)
