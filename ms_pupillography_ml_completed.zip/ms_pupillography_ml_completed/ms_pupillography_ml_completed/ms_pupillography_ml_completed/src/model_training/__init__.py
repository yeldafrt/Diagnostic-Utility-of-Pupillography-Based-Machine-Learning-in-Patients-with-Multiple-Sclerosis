"""
Model Training module for MS Pupillography ML
Handles model training, evaluation, and prediction
"""

def train_model(features_csv, patient_id_column, label_column, test_size=0.25):
    """Train Random Forest model with patient-based stratification"""
    pass

def load_model(model_path, scaler_path=None):
    """Load trained model and scaler"""
    pass

def predict(model, scaler, image_path):
    """Make prediction on a new image"""
    pass

__all__ = ['train_model', 'load_model', 'predict']
