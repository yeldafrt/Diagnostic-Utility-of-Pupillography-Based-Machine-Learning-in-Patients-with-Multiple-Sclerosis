#!/usr/bin/env python3
"""
Patient-based Analysis with Saved Model
Test the saved model and perform patient-based analysis
"""

import os
import numpy as np
import pandas as pd
import cv2
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix, roc_auc_score, roc_curve, precision_recall_curve
import matplotlib.pyplot as plt
import seaborn as sns
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')

print("🎯 PATIENT-BASED ANALYSIS WITH SAVED MODEL")
print("=" * 60)

# Paths
data_dir = "/home/ubuntu/upload/pupillografi_hasta_veri/pupillografi_hasta_veri"
model_path = "/home/ubuntu/upload/correct_package/models/ms_detection_model.pkl"
scaler_path = "/home/ubuntu/upload/correct_package/models/feature_scaler.pkl"

def test_saved_model():
    """Test if saved model can be loaded"""
    try:
        print("🔍 Testing saved model...")
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
        with open(scaler_path, 'rb') as f:
            scaler = pickle.load(f)
        print("   ✅ Saved model loaded successfully!")
        return model, scaler
    except Exception as e:
        print(f"   ❌ Saved model failed: {e}")
        return None, None

def extract_features(image_path):
    """Extract 22 features from image (same as original)"""
    try:
        # Load and preprocess image
        img = cv2.imread(image_path)
        if img is None:
            return None
        
        img_resized = cv2.resize(img, (400, 200))
        gray = cv2.cvtColor(img_resized, cv2.COLOR_BGR2GRAY)
        
        features = []
        
        # 1. Basic statistics (5 features)
        features.extend([
            np.mean(gray),           # mean_intensity
            np.std(gray),            # std_intensity
            np.min(gray),            # min_intensity
            np.max(gray),            # max_intensity
            np.max(gray) - np.min(gray)  # intensity_range
        ])
        
        # 2. Pupil analysis (6 features)
        circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1, 20,
                                  param1=50, param2=30, minRadius=10, maxRadius=100)
        
        if circles is not None:
            circles = np.round(circles[0, :]).astype("int")
            x, y, r = circles[0]
            features.extend([
                1,                           # pupil_detected
                r / max(gray.shape),         # pupil_radius (normalized)
                x / gray.shape[1],           # pupil_x_norm
                y / gray.shape[0],           # pupil_y_norm
                np.mean(gray[max(0, y-r):min(gray.shape[0], y+r), 
                            max(0, x-r):min(gray.shape[1], x+r)]),  # pupil_mean_intensity
                np.std(gray[max(0, y-r):min(gray.shape[0], y+r), 
                           max(0, x-r):min(gray.shape[1], x+r)])    # pupil_std_intensity
            ])
        else:
            features.extend([0, 0, 0.5, 0.5, np.mean(gray), np.std(gray)])
        
        # 3. Texture analysis (4 features)
        sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        gradient = np.sqrt(sobelx**2 + sobely**2)
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        
        features.extend([
            np.mean(gradient),       # gradient_mean
            np.std(gradient),        # gradient_std
            np.var(laplacian),       # laplacian_variance
            np.var(sobelx + sobely)  # sobel_variance
        ])
        
        # 4. Histogram features (3 features)
        hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
        hist = hist.flatten()
        hist = hist / np.sum(hist)  # normalize
        
        features.extend([
            np.argmax(hist),         # hist_peak
            -np.sum(hist * np.log(hist + 1e-10)),  # hist_entropy
            np.sum(hist**2)          # hist_uniformity
        ])
        
        # 5. Regional analysis (4 features)
        h, w = gray.shape
        quad_0 = gray[:h//2, :w//2]      # top-left
        quad_1 = gray[:h//2, w//2:]      # top-right
        quad_2 = gray[h//2:, :w//2]      # bottom-left
        quad_3 = gray[h//2:, w//2:]      # bottom-right
        
        features.extend([
            np.mean(quad_0),         # quad_0_mean
            np.mean(quad_1),         # quad_1_mean
            np.mean(quad_2),         # quad_2_mean
            np.mean(quad_3)          # quad_3_mean
        ])
        
        return np.array(features)
        
    except Exception as e:
        print(f"Error processing {image_path}: {e}")
        return None

def load_patient_data():
    """Load data organized by patients"""
    print("📂 Loading patient-based data...")
    
    patient_data = defaultdict(list)
    
    # Load control group
    control_dir = os.path.join(data_dir, "kontrol_grubu")
    control_patients = 0
    for patient_folder in os.listdir(control_dir):
        patient_path = os.path.join(control_dir, patient_folder)
        if os.path.isdir(patient_path):
            patient_images = []
            for img_file in os.listdir(patient_path):
                if img_file.lower().endswith(('.jpg', '.jpeg', '.png')):
                    img_path = os.path.join(patient_path, img_file)
                    features = extract_features(img_path)
                    if features is not None:
                        patient_images.append(features)
            
            if len(patient_images) > 0:
                patient_data[f"control_{patient_folder}"] = {
                    'features': np.array(patient_images),
                    'label': 0,
                    'group': 'control'
                }
                control_patients += 1
    
    # Load MS group
    ms_dir = os.path.join(data_dir, "ms_grubu")
    ms_patients = 0
    for patient_folder in os.listdir(ms_dir):
        patient_path = os.path.join(ms_dir, patient_folder)
        if os.path.isdir(patient_path):
            patient_images = []
            for img_file in os.listdir(patient_path):
                if img_file.lower().endswith(('.jpg', '.jpeg', '.png')):
                    img_path = os.path.join(patient_path, img_file)
                    features = extract_features(img_path)
                    if features is not None:
                        patient_images.append(features)
            
            if len(patient_images) > 0:
                patient_data[f"ms_{patient_folder}"] = {
                    'features': np.array(patient_images),
                    'label': 1,
                    'group': 'ms'
                }
                ms_patients += 1
    
    print(f"   ✅ Control patients: {control_patients}")
    print(f"   ✅ MS patients: {ms_patients}")
    print(f"   ✅ Total patients: {len(patient_data)}")
    
    return patient_data, control_patients, ms_patients

def patient_based_analysis(model, scaler, patient_data):
    """Perform patient-based analysis"""
    print("🏥 Performing patient-based analysis...")
    
    patient_predictions = {}
    patient_probabilities = {}
    
    for patient_id, data in patient_data.items():
        # Get all features for this patient
        patient_features = data['features']
        
        # Scale features
        patient_features_scaled = scaler.transform(patient_features)
        
        # Get predictions for all images of this patient
        predictions = model.predict(patient_features_scaled)
        probabilities = model.predict_proba(patient_features_scaled)[:, 1]
        
        # Patient-level decision: majority vote
        patient_prediction = 1 if np.mean(predictions) >= 0.5 else 0
        patient_probability = np.mean(probabilities)
        
        patient_predictions[patient_id] = {
            'true_label': data['label'],
            'predicted_label': patient_prediction,
            'probability': patient_probability,
            'group': data['group'],
            'num_images': len(patient_features)
        }
    
    # Calculate patient-based metrics
    y_true = [patient_predictions[pid]['true_label'] for pid in patient_predictions]
    y_pred = [patient_predictions[pid]['predicted_label'] for pid in patient_predictions]
    y_prob = [patient_predictions[pid]['probability'] for pid in patient_predictions]
    
    # Metrics
    accuracy = accuracy_score(y_true, y_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(y_true, y_pred, average=None)
    cm = confusion_matrix(y_true, y_pred)
    auc_roc = roc_auc_score(y_true, y_prob)
    
    # Get curves
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    precision_curve, recall_curve, _ = precision_recall_curve(y_true, y_prob)
    auc_pr = np.trapz(precision_curve, recall_curve)
    
    print(f"   ✅ Patient-based Analysis completed!")
    print(f"   ✅ Patient Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"   ✅ Patient AUC-ROC: {auc_roc:.4f}")
    print(f"   ✅ Patient Confusion Matrix:")
    print(f"      Control: TN={cm[0,0]}, FP={cm[0,1]}")
    print(f"      MS: FN={cm[1,0]}, TP={cm[1,1]}")
    
    results = {
        'accuracy': accuracy,
        'precision_control': precision[0],
        'recall_control': recall[0],
        'precision_ms': precision[1],
        'recall_ms': recall[1],
        'f1_control': f1[0],
        'f1_ms': f1[1],
        'auc_roc': auc_roc,
        'auc_pr': auc_pr,
        'confusion_matrix': cm,
        'fpr': fpr,
        'tpr': tpr,
        'precision_curve': precision_curve,
        'recall_curve': recall_curve,
        'patient_predictions': patient_predictions,
        'total_patients': len(patient_predictions),
        'control_patients': len([p for p in patient_predictions.values() if p['group'] == 'control']),
        'ms_patients': len([p for p in patient_predictions.values() if p['group'] == 'ms'])
    }
    
    return results

def train_new_model_if_needed(patient_data):
    """Train new model with same parameters if saved model fails"""
    print("🤖 Training new model with original parameters...")
    
    # Prepare data
    X = []
    y = []
    
    for patient_id, data in patient_data.items():
        for features in data['features']:
            X.append(features)
            y.append(data['label'])
    
    X = np.array(X)
    y = np.array(y)
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    
    # Train Random Forest with original parameters
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        min_samples_split=5,
        min_samples_leaf=3,
        class_weight='balanced',
        random_state=42,
        n_jobs=-1
    )
    
    model.fit(X_train_scaled, y_train)
    
    print(f"   ✅ New model trained successfully!")
    
    return model, scaler

def main():
    """Main execution"""
    try:
        # Test saved model
        model, scaler = test_saved_model()
        
        # Load patient data
        patient_data, control_patients, ms_patients = load_patient_data()
        
        # If saved model failed, train new one
        if model is None or scaler is None:
            model, scaler = train_new_model_if_needed(patient_data)
        
        # Perform patient-based analysis
        results = patient_based_analysis(model, scaler, patient_data)
        
        print("\n🎉 PATIENT-BASED ANALYSIS COMPLETED!")
        print("=" * 60)
        print(f"📊 Patient-Based Results:")
        print(f"   - Patient Accuracy: {results['accuracy']*100:.2f}%")
        print(f"   - Patient AUC-ROC: {results['auc_roc']:.3f}")
        print(f"   - Total Patients: {results['total_patients']}")
        print(f"   - Control Patients: {results['control_patients']}")
        print(f"   - MS Patients: {results['ms_patients']}")
        print(f"   - Patient Confusion Matrix:")
        cm = results['confusion_matrix']
        print(f"     Control: TN={cm[0,0]}, FP={cm[0,1]} (Total: {cm[0,0]+cm[0,1]})")
        print(f"     MS: FN={cm[1,0]}, TP={cm[1,1]} (Total: {cm[1,0]+cm[1,1]})")
        
        return results
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    results = main()

