"""
MS Pupillography ML - Source Code Package
Machine Learning-Based Detection of Multiple Sclerosis Using Pupillography Features
"""

__version__ = '1.0.0'
__author__ = 'Your Name'
__email__ = 'your.email@institution.edu'

from . import visualization
from . import preprocessing
from . import feature_extraction
from . import model_training
from . import evaluation

__all__ = [
    'visualization',
    'preprocessing',
    'feature_extraction',
    'model_training',
    'evaluation',
]
