"""
Image Preprocessing Module for MS Pupillography ML
"""

import cv2
import numpy as np
from PIL import Image


def resize_image(image, target_size=(400, 200)):
    """
    Resize image to target size
    
    Args:
        image: Input image (numpy array or PIL Image)
        target_size: Tuple of (width, height)
        
    Returns:
        numpy.ndarray: Resized image
    """
    if isinstance(image, Image.Image):
        image = np.array(image)
    
    return cv2.resize(image, target_size)


def normalize_image(image, method='minmax'):
    """
    Normalize image intensities
    
    Args:
        image: Input image (numpy array)
        method: Normalization method ('minmax', 'zscore', or 'clahe')
        
    Returns:
        numpy.ndarray: Normalized image
    """
    if method == 'minmax':
        # Min-max normalization to [0, 255]
        img_min = image.min()
        img_max = image.max()
        if img_max > img_min:
            normalized = ((image - img_min) / (img_max - img_min) * 255).astype(np.uint8)
        else:
            normalized = image.astype(np.uint8)
            
    elif method == 'zscore':
        # Z-score normalization
        mean = image.mean()
        std = image.std()
        if std > 0:
            normalized = ((image - mean) / std * 50 + 128).clip(0, 255).astype(np.uint8)
        else:
            normalized = image.astype(np.uint8)
            
    elif method == 'clahe':
        # Contrast Limited Adaptive Histogram Equalization
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        normalized = clahe.apply(gray)
        
    else:
        raise ValueError(f"Unknown normalization method: {method}")
    
    return normalized


def quality_check(image_path, min_size=(100, 100), max_blur_score=100):
    """
    Check if image meets quality requirements
    
    Args:
        image_path: Path to image file
        min_size: Minimum (width, height) required
        max_blur_score: Maximum Laplacian variance (lower = more blurry)
        
    Returns:
        tuple: (is_valid, reason)
    """
    try:
        # Load image
        img = cv2.imread(image_path)
        if img is None:
            return False, "Cannot load image"
        
        # Check size
        h, w = img.shape[:2]
        if w < min_size[0] or h < min_size[1]:
            return False, f"Image too small: {w}x{h}"
        
        # Check blur (Laplacian variance)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        
        if laplacian_var < max_blur_score:
            return False, f"Image too blurry: {laplacian_var:.2f}"
        
        return True, "OK"
        
    except Exception as e:
        return False, f"Error: {str(e)}"


def preprocess_image(image_path, target_size=(400, 200), normalize_method='minmax'):
    """
    Complete preprocessing pipeline
    
    Args:
        image_path: Path to image file
        target_size: Target size for resizing
        normalize_method: Normalization method
        
    Returns:
        numpy.ndarray: Preprocessed image, or None if failed
    """
    try:
        # Load image
        img = cv2.imread(image_path)
        if img is None:
            return None
        
        # Convert to grayscale if needed
        if len(img.shape) == 3:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        else:
            gray = img
        
        # Resize
        resized = resize_image(gray, target_size)
        
        # Normalize
        normalized = normalize_image(resized, method=normalize_method)
        
        return normalized
        
    except Exception as e:
        print(f"Error preprocessing {image_path}: {e}")
        return None


def batch_preprocess(image_paths, target_size=(400, 200), normalize_method='minmax', verbose=True):
    """
    Preprocess multiple images
    
    Args:
        image_paths: List of image file paths
        target_size: Target size for resizing
        normalize_method: Normalization method
        verbose: Print progress
        
    Returns:
        list: List of preprocessed images
    """
    preprocessed_images = []
    
    for i, img_path in enumerate(image_paths):
        if verbose and (i + 1) % 50 == 0:
            print(f"Preprocessed {i + 1}/{len(image_paths)} images...")
        
        img = preprocess_image(img_path, target_size, normalize_method)
        if img is not None:
            preprocessed_images.append(img)
    
    if verbose:
        print(f"Successfully preprocessed {len(preprocessed_images)}/{len(image_paths)} images")
    
    return preprocessed_images


if __name__ == "__main__":
    # Example usage
    import sys
    
    if len(sys.argv) > 1:
        img_path = sys.argv[1]
        
        # Quality check
        is_valid, reason = quality_check(img_path)
        print(f"Quality check: {reason}")
        
        if is_valid:
            # Preprocess
            img = preprocess_image(img_path)
            if img is not None:
                print(f"Preprocessed image shape: {img.shape}")
                print(f"Intensity range: [{img.min()}, {img.max()}]")
    else:
        print("Usage: python preprocess.py <image_path>")
