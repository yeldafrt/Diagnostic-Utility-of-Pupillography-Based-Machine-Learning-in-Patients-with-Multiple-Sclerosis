# MS Pupillography Clinical Test Package

This package provides a complete clinical testing environment for the Multiple Sclerosis (MS) detection model based on pupillography images. It allows for single image prediction, batch processing, patient-based ensemble prediction, and the generation of comprehensive reports and visualizations.

## 1. Installation

Before running the scripts, you need to install the required Python libraries. It is recommended to use a virtual environment.

```bash
# Create and activate a virtual environment (optional but recommended)
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

## 2. Package Contents

- `predict_single_image.py`: Script to predict MS from a single pupillography image.
- `predict_batch.py`: Script to process a batch of images, generate predictions, and calculate performance metrics (image-level).
- `predict_batch_ensemble.py`: Script for patient-based ensemble prediction using aggregation strategy (recommended for clinical use).
- `visualize_results.py`: Script to generate publication-quality visualizations from the batch prediction results.
- `run_analysis.py`: A wrapper script that runs the complete analysis pipeline (batch prediction + visualization).
- `requirements.txt`: A list of required Python packages.
- `models/`: This directory should contain the trained model (`ms_detection_model.pkl`) and the feature scaler (`feature_scaler.pkl`).
- `data/`: This directory is for your input images.
- `results/`: This directory will be created to store the output files (CSV, Excel, figures).

## 3. Data Preparation

### 3.1. Image Data

Place your pupillography images (e.g., in `.png`, `.jpg` format) into the `data/` directory.

**For ensemble prediction**: The filename format is important. The patient ID is extracted from the filename (before the first `_` or `-`).

**Examples**:
```
Patient_001_img1.jpg  → Patient ID: Patient_001
Patient_001_img2.jpg  → Patient ID: Patient_001
MS_01-img1.png        → Patient ID: MS_01
Control_05-img2.png   → Patient ID: Control_05
```

### 3.2. True Labels (Optional)

If you have the true diagnostic labels for your images, create a CSV file named `true_labels.csv` in the `data/` directory. This file is required for calculating performance metrics (accuracy, sensitivity, etc.).

**Format**:
```csv
patient_id,true_label
Patient_001,MS
Patient_002,Control
Patient_003,MS
...
```

- `patient_id`: Must match the patient ID extracted from image filenames.
- `true_label`: Must be either `MS` or `Control`.

## 4. How to Run

### 4.1. Complete Analysis (Recommended)

To run the entire pipeline (batch prediction and visualization), use the `run_analysis.py` script. This is the easiest way to get all results.

```bash
python run_analysis.py data/ results/
```

This will:
1. Process all images in the `data/` directory.
2. Generate a `predictions_YYYYMMDD_HHMMSS.csv` and `predictions_YYYYMMDD_HHMMSS.xlsx` file in the `results/` directory.
3. If `true_labels.csv` is present, it will calculate performance metrics and save them to `metrics_YYYYMMDD_HHMMSS.json`.
4. Generate all visualizations (confusion matrix, ROC curve, etc.) in the `results/figures/` directory.

### 4.2. Single Image Prediction

To test a single image:

```bash
python predict_single_image.py /path/to/your/image.png
```

### 4.3. Batch Prediction (Image-Level)

To run only the batch prediction and generate the CSV/Excel report:

```bash
# Without true labels
python predict_batch.py data/ results/

# With true labels for performance analysis
python predict_batch.py data/ results/ data/true_labels.csv
```

### 4.4. Patient-Based Ensemble Prediction (Recommended for Clinical Use)

For patient-level predictions using the ensemble aggregation strategy:

```bash
# With true labels for performance analysis
python predict_batch_ensemble.py data/ --output results/ --labels data/true_labels.csv

# Without true labels
python predict_batch_ensemble.py data/ --output results/

# With custom threshold
python predict_batch_ensemble.py data/ --output results/ --threshold 0.5
```

**Ensemble Strategy**: This method groups multiple images by patient ID and applies:
- **Formula**: 0.7 × maximum probability + 0.3 × mean of top-5 probabilities
- **Decision threshold**: 0.465 (optimized for clinical screening)

**Outputs**:
- `patient_predictions_ensemble_*.csv`: Patient-level predictions
- `image_predictions_*.csv`: Image-level details
- `metrics_ensemble_*.json`: Performance metrics (if labels provided)
- `report_ensemble_*.xlsx`: Comprehensive Excel report

**Note**: This method is recommended for clinical decision-making as it provides a single prediction per patient based on all available images.

### 4.5. Visualization Only

If you have already run a batch prediction and have a `predictions_*.csv` file, you can generate the visualizations separately:

```bash
python visualize_results.py results/predictions_YYYYMMDD_HHMMSS.csv
```

## 5. Outputs

All output files are saved in the `results/` directory.

### Image-Level Prediction Outputs

- **`predictions_YYYYMMDD_HHMMSS.csv`**: Detailed prediction results for each image in CSV format.
- **`predictions_YYYYMMDD_HHMMSS.xlsx`**: A more detailed and formatted Excel report with multiple sheets:
    - `Summary`: An overview of the results.
    - `Detailed Predictions`: The full prediction data for each image.
    - `Performance Metrics`: If true labels were provided, this sheet contains accuracy, sensitivity, specificity, etc.
- **`metrics_YYYYMMDD_HHMMSS.json`**: Performance metrics in JSON format.
- **`results/figures/`**: This sub-directory contains all the generated plots:
    - `confusion_matrix_clinical.png`
    - `roc_curve_clinical.png`
    - `pr_curve_clinical.png`
    - `confidence_distribution.png`
- **`clinical_test_table.txt`**: A formatted table of the results, ready to be included in a manuscript.

### Patient-Level Ensemble Prediction Outputs

When using `predict_batch_ensemble.py`:

- **`patient_predictions_ensemble_YYYYMMDD_HHMMSS.csv`**: Patient-level predictions with ensemble scores.
  - Columns: `patient_id`, `num_images`, `num_valid`, `prediction`, `ensemble_score`, `max_probability`, `top5_mean`, `true_label` (if provided), `correct` (if provided)
- **`image_predictions_YYYYMMDD_HHMMSS.csv`**: Image-level details for all processed images.
  - Columns: `patient_id`, `image_file`, `image_path`, `quality_check`, `quality_reason`, `ms_probability`, `control_probability`
- **`metrics_ensemble_YYYYMMDD_HHMMSS.json`**: Performance metrics (if true labels provided).
  - Includes: accuracy, sensitivity, specificity, precision, f1_score, auc_roc, confusion matrix values
- **`report_ensemble_YYYYMMDD_HHMMSS.xlsx`**: Multi-sheet Excel report with:
    - `Patient Predictions`: Patient-level results with ensemble scores
    - `Image Details`: All image-level predictions
    - `Performance Metrics`: Accuracy, sensitivity, specificity, etc. (if labels provided)

## 6. Prediction Methods Comparison

This package provides two prediction approaches:

### Image-Level Prediction (`predict_batch.py`)
- **Purpose**: Predicts MS/Control for each individual image
- **Use case**: Research, feature analysis, image quality assessment
- **Output**: One prediction per image
- **Method**: Direct model prediction on each image

### Patient-Level Ensemble Prediction (`predict_batch_ensemble.py`)
- **Purpose**: Provides a single diagnostic decision per patient
- **Use case**: Clinical decision-making, patient diagnosis
- **Output**: One prediction per patient (aggregated from multiple images)
- **Method**: Ensemble aggregation strategy
  - Groups images by patient ID
  - Calculates: 0.7 × maximum probability + 0.3 × mean of top-5 probabilities
  - Decision threshold: 0.465 (optimized for high sensitivity)

**Recommendation**: Use `predict_batch_ensemble.py` for clinical applications where you need a single diagnostic decision per patient based on multiple images. This method achieved **88.9% sensitivity** on independent validation (32 patients).

## 7. Example Workflow

### Clinical Validation Scenario

```bash
# 1. Prepare your data
mkdir -p data/validation_cohort
# Copy your images to data/validation_cohort/
# Create data/true_labels.csv with patient IDs and true labels

# 2. Run patient-based ensemble prediction
python predict_batch_ensemble.py data/validation_cohort/ \
    --output results/validation/ \
    --labels data/true_labels.csv

# 3. Review results
# - Check results/validation/patient_predictions_ensemble_*.csv for patient-level predictions
# - Check results/validation/metrics_ensemble_*.json for performance metrics
# - Open results/validation/report_ensemble_*.xlsx for comprehensive report
```

### Research Analysis Scenario

```bash
# 1. Run complete image-level analysis
python run_analysis.py data/ results/

# 2. Review visualizations
ls results/figures/
# - confusion_matrix_clinical.png
# - roc_curve_clinical.png
# - pr_curve_clinical.png
```

## 8. Troubleshooting

### Common Issues

**Issue**: "No valid probabilities" warning for some patients
- **Cause**: All images for that patient failed quality check
- **Solution**: Check image quality, ensure proper format and resolution

**Issue**: Patient ID extraction incorrect
- **Cause**: Filename format doesn't match expected pattern
- **Solution**: Modify `extract_patient_id()` function in `predict_batch_ensemble.py` to match your naming convention

**Issue**: Model or scaler file not found
- **Cause**: Incorrect file paths
- **Solution**: Use `--model` and `--scaler` parameters to specify correct paths

## 9. Contact

For questions or issues:
- **Email**: drnparmak@yahoo.com, parmakyener@gmail.com
- **GitHub**: Create an issue in the repository

