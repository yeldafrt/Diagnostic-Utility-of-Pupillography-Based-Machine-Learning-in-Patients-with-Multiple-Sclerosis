"""
Setup script for MS Pupillography ML package
"""

from setuptools import setup, find_packages
import os

# Read README
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read requirements
with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="ms_pupillography_ml",
    version="1.0.0",
    author="Your Name",
    author_email="your.email@institution.edu",
    description="Machine Learning-Based Detection of Multiple Sclerosis Using Pupillography Features",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/ms_pupillography_ml",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=6.0",
            "black>=21.0",
            "flake8>=3.9",
            "mypy>=0.910",
        ],
        "docs": [
            "sphinx>=4.0",
            "sphinx-rtd-theme>=1.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "ms-predict=src.model_training.predict:main",
            "ms-train=src.model_training.train:main",
            "ms-extract-features=src.feature_extraction.extract:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
