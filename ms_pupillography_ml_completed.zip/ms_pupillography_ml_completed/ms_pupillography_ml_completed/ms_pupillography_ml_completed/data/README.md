# Data Directory

This directory is intended for storing OCT pupillography images and extracted features.

## ⚠️ Data Not Included

**Important:** The actual OCT pupillography images are **not included** in this repository due to privacy and data protection regulations (patient confidentiality).

### To Use This Code:

1. **Request Data Access:** Contact the authors for data access requests
2. **Prepare Your Data:** Organize your OCT images in the structure shown below
3. **Extract Features:** Run the feature extraction scripts on your images

## Directory Structure

```
data/
├── raw/                    # Raw OCT images (not included in repository)
│   ├── control/           # Control group images
│   └── ms/                # MS patient images
├── processed/             # Preprocessed images (resized to 400x200)
│   ├── control/
│   └── ms/
└── features/              # Extracted features (CSV files)
    ├── train_features.csv
    ├── test_features.csv
    └── all_features.csv
```

## Data Format

### Raw Images
- **Format:** PNG, JPEG, or TIFF
- **Original size:** 923 × 1906 pixels (as used in manuscript)
- **Processing size:** 400 × 200 pixels (automatic resizing)
- **Naming convention:** `patient_id_eye_session.png` (e.g., `P001_OD_01.png`)

### Feature CSV Format

The extracted features CSV should have the following columns:

| Column | Type | Description |
|--------|------|-------------|
| patient_id | str | Unique patient identifier |
| image_path | str | Path to the original image |
| diagnosis | str | 'Control' or 'MS' |
| mean_intensity | float | Mean pixel intensity |
| std_intensity | float | Standard deviation of intensity |
| ... | ... | (22 features total) |

Example:
```csv
patient_id,image_path,diagnosis,mean_intensity,std_intensity,...
P001,data/raw/control/P001_OD_01.png,Control,0.523,0.142,...
P002,data/raw/ms/P002_OS_01.png,MS,0.487,0.156,...
```

## Dataset Statistics (From Manuscript)

### Full Dataset
- **Total images:** 692 pupillographic images
- **Total participants:** 63 (25 MS, 38 Control)
- **MS images:** 274
- **Control images:** 418
- **Images per participant:** Variable (range: 8-15)

### Participant Demographics
- **MS patients:** 25 (RRMS without optic neuritis)
- **Healthy controls:** 38 (age and sex-matched)
- **Age range:** 18-60 years

### Train/Test Split (Patient-Based Stratification)
- **Training set:** 384 images from 35 patients
  - MS: 9 patients
  - Control: 26 patients
- **Test set:** 308 images from 28 patients
  - MS: 16 patients
  - Control: 12 patients
- **Split strategy:** Patient-based stratification (no patient in both sets)

## Data Collection

- **Equipment:** Cirrus CSO corneal topography device (pupillography module)
- **Illumination:** Infrared LED light (wavelength 875–940 nm)
- **Acquisition mode:** Static and dynamic pupillometry
- **Environment:** Dimly lit (0.1–0.5 lux) after 2-3 minute dark adaptation
- **Resolution:** Original 923 × 1906 pixels
- **Processing:** Resized to 400 × 200 for analysis
- **Quality control:** Manual inspection and automated quality checks

## Privacy and Ethics

- All data collection followed institutional ethical guidelines
- Ethics Committee approval: 2011-KAEK-25 2019/03–28
- Patient consent was obtained for research use
- All images are de-identified
- Data sharing requires appropriate agreements and institutional approval

## Data Access Requests

For data access requests or questions about the dataset:

- **Corresponding Author:** Neslihan Parmak Yener, MD
- **Email:** drnparmak@yahoo.com, parmakyener@gmail.com
- **Institution:** University of Health Sciences, Bursa Yuksek Ihtisas Training and Research Hospital, Bursa, Turkey
- **Department:** Department of Ophthalmology

Please include in your request:
1. Your institutional affiliation
2. Intended use of the data
3. IRB/Ethics approval from your institution
4. Data sharing agreement

## Using Your Own Data

If you have your own pupillography images, you can use this codebase:

1. **Organize images** in the `data/raw/` directory
2. **Run preprocessing:** `python src/preprocessing/preprocess.py`
3. **Extract features:** `python src/feature_extraction/extract_features.py`
4. **Train model:** `python src/patient_based_analysis.py`

See the main README.md for detailed usage instructions.
