# MS Pupillography Machine Learning

A machine learning-based system for Multiple Sclerosis (MS) detection using OCT pupillography images, validated on an independent cohort of 32 patients with **88.9% sensitivity maintained**. This repository contains the complete implementation of the Random Forest classifier achieving **85.7% accuracy** with **93.8% sensitivity** on patient-based evaluation.

## 📄 Publication

This code accompanies the manuscript:
> **"Diagnostic Utility of Pupillography-Based Machine Learning in Patients with Multiple Sclerosis"**
> 
> Neslihan Parmak Yener, Yelda Fırat, Meral Seferoğlu, Ahmet Metin Kargın, Yılmaz Kılıçaslan

## 🎯 Key Features

- **Patient-based stratified evaluation** - No patient overlap between training and test sets
- **Independent validation**: 88.9% sensitivity maintained on external cohort (32 patients)
- **22 quantitative features** extracted from OCT pupillography images across 5 main groups
- **Random Forest classifier** with 100 decision trees (max_depth=10)
- **High performance**: 85.7% accuracy, 93.8% sensitivity, 80.8% specificity, AUC-ROC=0.945
- **Patient-based ensemble prediction** - Optimized aggregation strategy for clinical use
- **Reproducible results** with saved models and complete analysis scripts
- **Publication-quality figures** (300 DPI) for all visualizations
- **Complete source code** - Feature extraction, preprocessing, training, evaluation
- **Clinical testing package** - Ready-to-use tools for real-world validation

## 📊 Performance Metrics

### Training Set Performance (28 patients)

| Metric | Value |
|--------|-------|
| Accuracy | 85.7% |
| Sensitivity (Recall) | 93.8% |
| Specificity | 80.8% |
| Precision | 75.0% |
| F1-Score | 83.3% |
| ROC-AUC | 0.945 |
| PR-AUC | 0.920 |

*Evaluated on 28 patients (16 MS, 12 Control) using patient-based stratified evaluation with 308 test images*

### Independent Validation Performance (32 patients)

| Metric | Value |
|--------|-------|
| Accuracy | 75.0% |
| Sensitivity (Recall) | 88.9% |
| Specificity | 57.1% |
| Precision | 72.7% |
| F1-Score | 80.0% |
| ROC-AUC | 0.627 |

*Validated on 32 additional patients (18 MS, 14 Control) with 384 images using ensemble aggregation strategy*

**Key Finding**: High sensitivity (88.9%) maintained on independent cohort, demonstrating robust generalization for clinical screening.

## 📚 Dataset Information

- **Total Images**: 692 pupillographic images
- **Participants**: 63 total (25 RRMS patients without ON, 38 healthy controls)
- **Training Set**: 384 images from 35 patients (9 MS, 26 controls)
- **Test Set**: 308 images from 28 patients (16 MS, 12 controls)
- **Validation Set**: 384 images from 32 patients (18 MS, 14 controls)
- **Image Resolution**: 923 × 1906 pixels (original), resized to 400 × 200 pixels
- **Format**: JPEG, grayscale conversion applied

## 🚀 Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/ms_pupillography_ml.git
cd ms_pupillography_ml

# Install dependencies
pip install -r requirements.txt
```

### Usage Examples

#### Extract Features

```python
from src.feature_extraction import extract_features

features = extract_features('path/to/image.jpg')
print(f"Extracted {len(features)} features")
```

#### Make Predictions

```python
import joblib
from src.feature_extraction import extract_features

# Load model
model = joblib.load('models/ms_detection_model.pkl')
scaler = joblib.load('models/feature_scaler.pkl')

# Predict
features = extract_features('path/to/image.jpg')
features_scaled = scaler.transform([features])
prediction = model.predict(features_scaled)[0]
probability = model.predict_proba(features_scaled)[0]

print(f"Prediction: {'MS' if prediction == 1 else 'Control'}")
print(f"Confidence: {max(probability)*100:.1f}%")
```

## 📁 Repository Contents

- **src/** - Complete source code (preprocessing, feature extraction, training, evaluation)
- **models/** - Trained Random Forest model and scaler (see models/README.md)
- **figures/** - Publication-quality figures (300 DPI, 13 figures)
- **notebooks/** - Example usage tutorials
- **clinical_test/** - Clinical testing package with patient-based ensemble prediction
- **data/** - Data directory (see data/README.md for format)
- **tests/** - Unit tests

See STRUCTURE.txt for full repository structure.

## 🔬 Methodology

### Features (22 total across 5 groups)
1. **Basic Statistics (5)**: mean, std, min, max, range
2. **Pupil Morphology (6)**: detection, radius, position (x, y), intensity (mean, std)
3. **Texture Analysis (4)**: gradient (mean, std), Laplacian (variance, mean)
4. **Histogram (3)**: entropy, uniformity, peak
5. **Regional Analysis (4)**: quadrant means (spatial distribution)

### Model Architecture
- **Algorithm**: Random Forest
- **Number of Trees**: 100
- **Max Depth**: 10 levels
- **Min Samples Split**: 5
- **Min Samples Leaf**: 3
- **Feature Normalization**: StandardScaler
- **Evaluation**: Patient-based stratified split with 5-fold cross-validation

### Key Clinical Finding
**15 out of 16 MS patients correctly identified** in the test set, demonstrating excellent sensitivity for clinical screening.

## 🏥 Clinical Testing Package

A comprehensive clinical testing package is included in `clinical_test/` directory for real-world validation. The package includes:

- **Single image prediction**: Test individual pupillography images
- **Batch prediction**: Process multiple images (image-level predictions)
- **Ensemble prediction**: Patient-based predictions using optimized aggregation strategy
  - Strategy: 0.7 × maximum probability + 0.3 × mean of top-5 probabilities
  - Threshold: 0.465 (optimized for clinical screening)
- **Comprehensive reports**: CSV, Excel, JSON outputs with performance metrics
- **Visualizations**: Publication-quality figures (confusion matrix, ROC curves, etc.)

See `clinical_test/README.md` for detailed usage instructions.

**Quick Start**:
```bash
# Image-level batch prediction
cd clinical_test
python predict_batch.py data/ results/

# Patient-level ensemble prediction (recommended for clinical use)
python predict_batch_ensemble.py data/ --output results/ --labels data/true_labels.csv
```

## 📦 Dependencies

- Python >= 3.8
- numpy >= 1.21.0
- pandas >= 1.3.0
- scikit-learn >= 1.0.0
- opencv-python >= 4.5.0
- matplotlib >= 3.4.0
- seaborn >= 0.11.0

See requirements.txt for complete list.

## 👥 Authors

- **Neslihan Parmak Yener, MD** - Department of Ophthalmology, University of Health Sciences, Bursa Yuksek Ihtisas Training and Research Hospital
- **Yelda Fırat** - Mudanya University Faculty of Engineering, Department of Computer Engineering
- **Meral Seferoğlu** - Department of Ophthalmology
- **Ahmet Metin Kargın** - Department of Ophthalmology
- **Yılmaz Kılıçaslan** - Department of Computer Engineering

## 📧 Contact

- **Corresponding Author**: Neslihan Parmak Yener, MD
- **Email**: drnparmak@yahoo.com, parmakyener@gmail.com
- **Institution**: University of Health Sciences, Bursa Yuksek Ihtisas Training and Research Hospital, Bursa, Turkey
- **GitHub**: [Create an issue](https://github.com/yourusername/ms_pupillography_ml/issues)

---

**Complete, reproducible implementation** of our manuscript methods with independent validation results.

*For the latest updates, star ⭐ this repository!*

