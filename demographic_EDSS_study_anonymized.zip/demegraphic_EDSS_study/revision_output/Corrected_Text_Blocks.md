# Makaleye Eklenecek Düzeltilmiş Metin Blokları

Aşağıdaki metinler, Frontiers dergisinin yazım kurallarına ve hakemlerin taleplerine uygun olarak, figür atıfları ve açıklamaları sıralı olacak şekilde yeniden düzenlenmiştir.

---

### 1. Eklenecek Yer: Results bölümünün sonuna (Sayfa 22, Satır 2'den sonra)

**Clinical Correlation Analysis**

To clarify the physiological and clinical meaning of the extracted parameters, a comprehensive correlation analysis was conducted between the 22 pupillographic features and clinical measures (EDSS and disease duration) for the 25 MS patients. The relationship between individual features and EDSS scores is presented in Figure 14.

[Insert Figure 14 here]

As shown in Figure 14, several significant correlations were identified. Histogram uniformity demonstrated a strong negative correlation with EDSS (Spearman ρ = -0.543, p = 0.005), indicating that higher disability scores are associated with less uniform pixel distributions in the pupillography images. Conversely, histogram entropy showed a positive correlation with EDSS (Spearman ρ = 0.434, p = 0.030). Pupil Y position exhibited a near-significant positive trend with EDSS (ρ = 0.392, p = 0.053), while pupil radius showed a weak, non-significant positive trend (ρ = 0.291, p = 0.158).

To further explore the interrelationships among all extracted features and clinical variables, a comprehensive correlation matrix was generated, which is illustrated in Figure 15.

[Insert Figure 15 here]

As illustrated in Figure 15, the heatmap confirms the strong associations between histogram-based features and EDSS. Additionally, it reveals that quadrant 3 mean intensity has a significant negative correlation with disease duration (ρ = -0.47, p < 0.05), suggesting that regional pupillary responses may alter as the disease progresses over time.

**Disease Duration Subgroup Analysis**

To evaluate the model's performance in relation to disease onset, a subgroup analysis was performed comparing patients with early MS (<5 years disease duration, n = 9) to those with late MS (≥5 years, n = 15). The comparative results of this analysis are presented in Figure 16.

[Insert Figure 16 here]

As shown in Figure 16, the analysis revealed no statistically significant differences in the extracted pupillography features between the early and late MS subgroups. For instance, pupil radius did not differ significantly between the groups (U = 40.0, p = 0.107), nor did the overall EDSS scores (U = 40.5, p = 0.100). This suggests that the pupillary changes detected by our model may be present early in the disease course and remain relatively stable, rather than being exclusively associated with late-stage disease.

---

### 2. Eklenecek Yer: Discussion bölümü (Sayfa 23, Satır 22'den sonra)

To address the biological interpretability of our extracted features, we correlated them with clinical disability scores. The significant negative correlation between histogram uniformity and EDSS (ρ = -0.543, p = 0.005) suggests that as neurological disability progresses, the pixel distribution of the pupillography images becomes less uniform. This may reflect structural changes or atrophy in the iris stroma associated with progressive autonomic dysfunction. However, we acknowledge that texture and histogram-based metrics can be strongly influenced by technical factors such as illumination, contrast, or image acquisition settings. The 'black box' nature of some radiomic features necessitates standardized image acquisition protocols in future studies to isolate true biological signals from technical noise.

---

### 3. Eklenecek Yer: Discussion bölümü (Sayfa 22, Satır 15-17)

**Mevcut Metin:** "Of note, the misclassified MS patient in the test set had minimal clinical findings (EDSS = 0, disease duration = 3 years), suggesting the model may be more effective in identifying MS patients with more pronounced neurological changes."

**Değiştirilecek Metin:** "Our subgroup analysis comparing early (<5 years) and late (≥5 years) MS patients revealed no significant differences in the extracted pupillographic features. This finding aligns with the goals of modern MS management, which prioritize early detection before significant disability accumulates. However, because our cohort had a mean disease duration of nearly seven years, the true utility of this method for early detection remains unproven. Assessing patients as close as possible to disease onset, ideally in a prospective cohort of newly diagnosed or clinically isolated syndrome (CIS) patients, is necessary to validate its early-detection capabilities."
