# Makale Revizyon Rehberi - Hakem Yorumu 1 (Terminoloji Değişikliği)

Hakem Yorumu 1: *"Çalışma sürekli olarak pupillografi tabanlı makine öğrenimini MS için bir 'tanısal' (diagnostic) veya 'tarama' (screening) aracı olarak adlandırıyor. Ancak diğer nörolojik hastalıklar değerlendirilmediği için tanısal özgüllük iddia edilemez. Makale, yöntemi bir tanı testi olarak sunmaktan kaçınmalı ve bunun yerine keşifsel (exploratory) veya yardımcı (adjunctive) doğasını vurgulamalıdır."*

Aşağıda makalede değiştirilmesi gereken tüm "diagnostic" ve "screening" kelimelerinin yerleri ve yeni öneriler bulunmaktadır:

### 1. Başlık (Sayfa 2, Satır 1)
- **Mevcut:** Diagnostic Utility of Pupillography-Based Machine Learning in Patients with Multiple Sclerosis
- **Öneri:** Exploratory Analysis of Pupillography-Based Machine Learning for Detecting Autonomic Dysfunction in Patients with Multiple Sclerosis

### 2. Abstract - Background (Sayfa 2, Satır 7-8)
- **Mevcut:** However, its diagnostic utility in MS remains underexplored. This study aimed to investigate the feasibility of automated MS diagnosis via machine learning...
- **Öneri:** However, its utility as an adjunctive marker in MS remains underexplored. This study aimed to investigate the feasibility of automated classification between MS patients and healthy controls via machine learning...

### 3. Abstract - Conclusions (Sayfa 3, Satır 3-5)
- **Mevcut:** ...highlighting their potential as noninvasive screening tools. ... confirm their generalizability and clinical utility.
- **Öneri:** ...highlighting their potential as noninvasive adjunctive tools for assessing autonomic dysfunction. ... confirm their generalizability and clinical applicability.

### 4. Keywords (Sayfa 3, Satır 12)
- **Mevcut:** diagnostic support
- **Öneri:** adjunctive assessment

### 5. Introduction (Sayfa 5, Satır 14-15)
- **Mevcut:** ...its role in identifying subclinical optic nerve involvement in MS diagnosis is not yet well established.
- **Öneri:** ...its role in identifying subclinical optic nerve involvement as an adjunctive marker in MS is not yet well established.

### 6. Introduction (Sayfa 5, Satır 17-18)
- **Mevcut:** ...we aimed to increase diagnostic accuracy in RRMS patients without ON by developing an ML-based analysis system...
- **Öneri:** ...we aimed to improve the classification performance between RRMS patients without ON and healthy controls by developing an ML-based analysis system...

### 7. Methods - Image Processing (Sayfa 9, Satır 10)
- **Mevcut:** ...automated MS diagnostic systems.
- **Öneri:** ...automated MS classification systems.

### 8. Methods - Feature Extraction (Sayfa 9, Satır 13)
- **Mevcut:** ...for MS diagnosis.
- **Öneri:** ...for distinguishing MS patients from healthy controls.

### 9. Methods - Feature Extraction (Sayfa 10, Satır 8)
- **Mevcut:** ...automated diagnosis system.
- **Öneri:** ...automated classification system.

### 10. Methods - Architecture (Sayfa 10, Satır 11-12)
- **Mevcut:** ...was preferred for MS diagnosis, and the model architecture was optimized to meet the requirements of clinical diagnostic applications.
- **Öneri:** ...was preferred for MS classification, and the model architecture was optimized to meet the requirements of clinical exploratory applications.

### 11. Results - ROC Curve (Sayfa 18, Satır 10)
- **Mevcut:** ...excellent for clinical diagnostic applications...
- **Öneri:** ...excellent for clinical classification applications...

### 12. Discussion (Sayfa 22, Satır 4)
- **Mevcut:** ...automated multiple sclerosis (MS) detection system...
- **Öneri:** ...automated multiple sclerosis (MS) classification system...

### 13. Discussion (Sayfa 22, Satır 18-19)
- **Mevcut:** From a screening perspective, maintaining high sensitivity is prioritized to avoid missed diagnoses, while false positives may be addressed through follow-up diagnostic evaluation.
- **Öneri:** From an exploratory perspective, maintaining high sensitivity is prioritized to identify potential autonomic dysfunction, while false positives may be addressed through conventional clinical evaluation.

### 14. Discussion (Sayfa 23, Satır 9)
- **Mevcut:** ...diagnostic sensitivity and specificity of PLR alone remain uncertain.
- **Öneri:** ...classification sensitivity and specificity of PLR alone remain uncertain.

### 15. Discussion (Sayfa 23, Satır 12)
- **Mevcut:** Most ML studies in MS diagnosis utilize...
- **Öneri:** Most ML studies in MS classification utilize...

### 16. Discussion (Sayfa 23, Satır 15)
- **Mevcut:** ...early screening pathways...
- **Öneri:** ...early assessment pathways...

### 17. Limitations (Sayfa 24, Satır 17)
- **Mevcut:** ...limits the model’s diagnostic specificity and reduces its clinical applicability in real-world differential diagnosis.
- **Öneri:** ...limits the model’s specificity and reduces its clinical applicability in real-world differential diagnosis.

### 18. Limitations (Sayfa 25, Satır 6)
- **Mevcut:** ...added diagnostic value...
- **Öneri:** ...added classification value...

### 19. Conclusion (Sayfa 25, Satır 11)
- **Mevcut:** ...early screening applications...
- **Öneri:** ...early adjunctive assessment applications...

---
**Doktorlara Not:** Yukarıdaki değişiklikler, hakemin "diagnostic" ve "screening" kelimelerinin kullanımına yönelik eleştirisini tam olarak karşılamaktadır. Bu değişiklikler makalenin bilimsel değerini düşürmez, aksine hakemlerin beklediği "mütevazı ve kanıta dayalı" akademik dili sağlar.
