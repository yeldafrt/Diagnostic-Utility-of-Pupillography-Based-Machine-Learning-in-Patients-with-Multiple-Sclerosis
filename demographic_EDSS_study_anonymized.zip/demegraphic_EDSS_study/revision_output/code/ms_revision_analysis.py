"""
MS Pupillography - Major Revision Analysis
EDSS Correlation + Disease Duration Subgroup Analysis
Frontiers-compliant figures (300 DPI, JPEG, RGB)
"""

import cv2
import numpy as np
import os
import json
import openpyxl
from scipy import stats
from scipy.stats import spearmanr, pearsonr, mannwhitneyu, kruskal
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 1. PATIENT MATCHING (File-size verified mapping)
# ============================================================

actual_mapping = {
    "1_ms": "1_ms",
    "2_ms": "2_ms",
    "3_ms": "3_ms",
    "4_ms": "4_ms",
    "5_ms": "5_ms",
    "6_ms": "6_ms",
    "7_ms": "7_ms",
    "8_ms": "8_ms",
    "9_ms": "9_ms",
    "10_ms": "10_ms",
    "11_ms": "11_ms",
    "12_ms": "12_ms",
    "13_ms": "13_ms",
    "14_ms": "14_ms",
    "15_ms": "15_ms",
    "16_ms": "16_ms",
    "17_ms": "17_ms",
    "18_ms": "18_ms",
    "19_ms": "19_ms",
    "20_ms": "20_ms",
    "21_ms": "21_ms",
    "22_ms": "22_ms",
    "23_ms": "23_ms",
    "24_ms": "24_ms",
    "25_ms": "25_ms",
}



# ============================================================
# 2. FEATURE EXTRACTION (Same as model)
# ============================================================

def extract_features(image_path):
    """Extract 22 features from pupillography image (same as model)"""
    try:
        img = cv2.imread(image_path)
        if img is None:
            return None
        img_resized = cv2.resize(img, (400, 200))
        gray = cv2.cvtColor(img_resized, cv2.COLOR_BGR2GRAY)
        features = []
        
        # Basic statistics (5)
        features.extend([
            np.mean(gray), np.std(gray), np.min(gray),
            np.max(gray), np.max(gray) - np.min(gray)
        ])
        
        # Pupil analysis (6)
        circles = cv2.HoughCircles(
            gray, cv2.HOUGH_GRADIENT, 1, 20,
            param1=50, param2=30, minRadius=10, maxRadius=100
        )
        if circles is not None:
            circles = np.round(circles[0, :]).astype("int")
            x, y, r = circles[0]
            y_min, y_max = max(0, y-r), min(gray.shape[0], y+r)
            x_min, x_max = max(0, x-r), min(gray.shape[1], x+r)
            pupil_region = gray[y_min:y_max, x_min:x_max]
            features.extend([
                1, r / max(gray.shape), x / gray.shape[1],
                y / gray.shape[0], np.mean(pupil_region), np.std(pupil_region)
            ])
        else:
            features.extend([0, 0, 0.5, 0.5, np.mean(gray), np.std(gray)])
        
        # Texture analysis (4)
        sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        gradient_mag = np.sqrt(sobelx**2 + sobely**2)
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        features.extend([
            np.mean(gradient_mag), np.std(gradient_mag),
            np.var(laplacian), np.mean(np.abs(laplacian))
        ])
        
        # Histogram features (3)
        hist = cv2.calcHist([gray], [0], None, [64], [0, 256])
        hist_norm = hist.flatten() / (hist.sum() + 1e-8)
        features.extend([
            -np.sum(hist_norm * np.log(hist_norm + 1e-8)),
            np.sum(hist_norm ** 2),
            np.argmax(hist_norm)
        ])
        
        # Regional analysis (4)
        h, w = gray.shape
        for quad in [gray[:h//2, :w//2], gray[:h//2, w//2:],
                     gray[h//2:, :w//2], gray[h//2:, w//2:]]:
            features.append(np.mean(quad))
        
        return features
    except Exception as e:
        print(f"Error: {image_path}: {e}")
        return None

FEATURE_NAMES = [
    'mean_intensity', 'std_intensity', 'min_intensity', 'max_intensity', 'intensity_range',
    'pupil_detected', 'pupil_radius', 'pupil_x_norm', 'pupil_y_norm',
    'pupil_mean_intensity', 'pupil_std_intensity',
    'gradient_mean', 'gradient_std', 'laplacian_var', 'laplacian_mean',
    'hist_entropy', 'hist_uniformity', 'hist_peak',
    'quadrant_0_mean', 'quadrant_1_mean', 'quadrant_2_mean', 'quadrant_3_mean'
]

# ============================================================
# 3. LOAD CLINICAL DATA FROM EXCEL
# ============================================================

def load_clinical_data(excel_path):
    """Load clinical data and match with image folders"""
    wb = openpyxl.load_workbook(excel_path)
    ws = wb['Sayfa1']
    
    ms_excel = {}
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        values = [cell.value for cell in row]
        if values[0] is None:
            continue
        fill = row[0].fill
        color = str(fill.start_color.rgb) if fill and fill.start_color and fill.start_color.rgb else ""
        if 'FFFF' not in color.upper():
            name = values[0].strip().lower()
            ms_excel[name] = {
                'name': values[0],
                'age': values[1],
                'gender': values[2],  # 1=female, 2=male
                'edss': values[21],
                'diagnosis_year': values[18],
                'disease_duration': (2025 - int(values[18])) if values[18] else None,
                # Pupil diameter measurements
                'pup_0': values[4], 'pup_2': values[5], 'pup_4': values[6],
                'pup_6': values[7], 'pup_8': values[8], 'pup_10': values[9],
                'pup_12': values[10], 'pup_14': values[11], 'pup_16': values[12],
                'pup_18': values[13], 'pup_20': values[14],
            }
    
    # Match with image folders
    matched = {}
    for folder, patient_name in actual_mapping.items():
        if patient_name in ms_excel:
            matched[folder] = ms_excel[patient_name]
        else:
            print(f"WARNING: {patient_name} not found in Excel!")
    
    return matched

# ============================================================
# 4. EXTRACT FEATURES FOR ALL MS PATIENTS
# ============================================================

def extract_patient_features(image_base_path, matched_data):
    """Extract mean features per patient (average across 11 timepoints)"""
    patient_features = {}
    
    for folder in sorted(matched_data.keys(), key=lambda x: int(x.split('_')[0])):
        folder_path = os.path.join(image_base_path, folder)
        if not os.path.exists(folder_path):
            print(f"Folder not found: {folder_path}")
            continue
        
        all_features = []
        for img_name in ["0.jpg", "2.jpg", "4.jpg", "6.jpg", "8.jpg",
                         "10.jpg", "12.jpg", "14.jpg", "16.jpg", "18.jpg", "20.jpg"]:
            img_path = os.path.join(folder_path, img_name)
            if os.path.exists(img_path):
                feats = extract_features(img_path)
                if feats is not None:
                    all_features.append(feats)
        
        if all_features:
            mean_features = np.mean(all_features, axis=0)
            patient_features[folder] = {
                'mean_features': mean_features,
                'all_features': np.array(all_features),
                'n_images': len(all_features),
                'clinical': matched_data[folder]
            }
            print(f"  {folder}: {len(all_features)} images processed")
    
    return patient_features

# ============================================================
# 5. EDSS CORRELATION ANALYSIS
# ============================================================

def edss_correlation_analysis(patient_features):
    """Correlate extracted features with EDSS scores"""
    print("\n" + "="*80)
    print("EDSS CORRELATION ANALYSIS")
    print("="*80)
    
    # Prepare data
    edss_values = []
    feature_matrix = []
    patient_names = []
    
    for folder, data in sorted(patient_features.items(), key=lambda x: int(x[0].split('_')[0])):
        edss = data['clinical']['edss']
        if edss is not None:
            edss_values.append(float(edss))
            feature_matrix.append(data['mean_features'])
            patient_names.append(data['clinical']['name'])
    
    edss_values = np.array(edss_values)
    feature_matrix = np.array(feature_matrix)
    
    print(f"\nPatients with EDSS data: {len(edss_values)}")
    print(f"EDSS range: {edss_values.min():.1f} - {edss_values.max():.1f}")
    print(f"EDSS mean ± SD: {edss_values.mean():.2f} ± {edss_values.std():.2f}")
    print(f"EDSS median (IQR): {np.median(edss_values):.1f} ({np.percentile(edss_values, 25):.1f}-{np.percentile(edss_values, 75):.1f})")
    
    # Spearman correlation for each feature
    results = []
    print(f"\n{'Feature':30s} {'Spearman rho':>12s} {'p-value':>10s} {'Sig':>5s}")
    print("-" * 60)
    
    for i, fname in enumerate(FEATURE_NAMES):
        rho, p = spearmanr(feature_matrix[:, i], edss_values)
        sig = "***" if p < 0.001 else "**" if p < 0.01 else "*" if p < 0.05 else ""
        results.append({
            'feature': fname, 'rho': rho, 'p_value': p, 'significant': p < 0.05
        })
        print(f"{fname:30s} {rho:>12.4f} {p:>10.4f} {sig:>5s}")
    
    # Also compute Pearson for continuous features
    print("\n--- Pearson Correlations (top features) ---")
    for i, fname in enumerate(FEATURE_NAMES):
        if fname == 'pupil_detected' or fname == 'hist_peak':
            continue
        r, p = pearsonr(feature_matrix[:, i], edss_values)
        if p < 0.1:
            sig = "***" if p < 0.001 else "**" if p < 0.01 else "*" if p < 0.05 else "~"
            print(f"  {fname:30s} r={r:>8.4f}, p={p:.4f} {sig}")
    
    return {
        'edss_values': edss_values,
        'feature_matrix': feature_matrix,
        'patient_names': patient_names,
        'correlation_results': results
    }

# ============================================================
# 6. DISEASE DURATION SUBGROUP ANALYSIS
# ============================================================

def disease_duration_analysis(patient_features):
    """Compare early vs late MS patients"""
    print("\n" + "="*80)
    print("DISEASE DURATION SUBGROUP ANALYSIS")
    print("="*80)
    
    early_features = []  # < 5 years
    late_features = []   # >= 5 years
    early_edss = []
    late_edss = []
    early_patients = []
    late_patients = []
    
    for folder, data in sorted(patient_features.items(), key=lambda x: int(x[0].split('_')[0])):
        duration = data['clinical']['disease_duration']
        edss = data['clinical']['edss']
        if duration is not None:
            if duration < 5:
                early_features.append(data['mean_features'])
                early_edss.append(float(edss) if edss is not None else np.nan)
                early_patients.append(data['clinical']['name'])
            else:
                late_features.append(data['mean_features'])
                late_edss.append(float(edss) if edss is not None else np.nan)
                late_patients.append(data['clinical']['name'])
    
    early_features = np.array(early_features)
    late_features = np.array(late_features)
    early_edss = np.array(early_edss)
    late_edss = np.array(late_edss)
    
    print(f"\nEarly MS (<5 years): n={len(early_features)}")
    print(f"  Patients: {', '.join(early_patients)}")
    print(f"  EDSS mean ± SD: {np.nanmean(early_edss):.2f} ± {np.nanstd(early_edss):.2f}")
    
    print(f"\nLate MS (≥5 years): n={len(late_features)}")
    print(f"  Patients: {', '.join(late_patients)}")
    print(f"  EDSS mean ± SD: {np.nanmean(late_edss):.2f} ± {np.nanstd(late_edss):.2f}")
    
    # Mann-Whitney U test for each feature
    print(f"\n{'Feature':30s} {'Early Mean':>12s} {'Late Mean':>12s} {'U-stat':>10s} {'p-value':>10s} {'Sig':>5s}")
    print("-" * 85)
    
    duration_results = []
    for i, fname in enumerate(FEATURE_NAMES):
        u_stat, p = mannwhitneyu(early_features[:, i], late_features[:, i], alternative='two-sided')
        sig = "***" if p < 0.001 else "**" if p < 0.01 else "*" if p < 0.05 else ""
        duration_results.append({
            'feature': fname,
            'early_mean': np.mean(early_features[:, i]),
            'early_std': np.std(early_features[:, i]),
            'late_mean': np.mean(late_features[:, i]),
            'late_std': np.std(late_features[:, i]),
            'u_stat': u_stat, 'p_value': p, 'significant': p < 0.05
        })
        print(f"{fname:30s} {np.mean(early_features[:, i]):>12.4f} {np.mean(late_features[:, i]):>12.4f} {u_stat:>10.1f} {p:>10.4f} {sig:>5s}")
    
    # EDSS comparison between groups
    u_edss, p_edss = mannwhitneyu(early_edss[~np.isnan(early_edss)], 
                                   late_edss[~np.isnan(late_edss)], 
                                   alternative='two-sided')
    print(f"\nEDSS comparison: U={u_edss:.1f}, p={p_edss:.4f}")
    
    return {
        'early_features': early_features,
        'late_features': late_features,
        'early_edss': early_edss,
        'late_edss': late_edss,
        'early_patients': early_patients,
        'late_patients': late_patients,
        'duration_results': duration_results,
        'edss_comparison': {'u_stat': u_edss, 'p_value': p_edss}
    }

# ============================================================
# 7. MAIN EXECUTION
# ============================================================

if __name__ == "__main__":
    print("="*80)
    print("MS PUPILLOGRAPHY - MAJOR REVISION ANALYSIS")
    print("="*80)
    
    # Paths
    excel_path = "/home/ubuntu/upload/pasted_file_KMusCB_mspupillografi-1.xlsx"
    image_base = "/home/ubuntu/veri_kontrol/pupillografi_hasta_veri/pupillografi_hasta_veri/ms_grubu"
    output_dir = "/home/ubuntu/revision_output"
    os.makedirs(output_dir, exist_ok=True)
    
    # Load clinical data
    print("\n--- Loading Clinical Data ---")
    matched_data = load_clinical_data(excel_path)
    print(f"Matched patients: {len(matched_data)}")
    
    # Extract features
    print("\n--- Extracting Features ---")
    patient_features = extract_patient_features(image_base, matched_data)
    print(f"Patients with features: {len(patient_features)}")
    
    # EDSS Correlation
    edss_results = edss_correlation_analysis(patient_features)
    
    # Disease Duration Subgroup
    duration_results = disease_duration_analysis(patient_features)
    
    # Save results as JSON
    results_summary = {
        'n_patients': len(patient_features),
        'edss_stats': {
            'n': len(edss_results['edss_values']),
            'mean': float(np.mean(edss_results['edss_values'])),
            'std': float(np.std(edss_results['edss_values'])),
            'median': float(np.median(edss_results['edss_values'])),
            'min': float(np.min(edss_results['edss_values'])),
            'max': float(np.max(edss_results['edss_values'])),
        },
        'edss_correlations': [
            {'feature': r['feature'], 'rho': float(r['rho']), 'p': float(r['p_value']), 'sig': bool(r['significant'])}
            for r in edss_results['correlation_results']
        ],
        'duration_subgroups': {
            'early_n': len(duration_results['early_patients']),
            'late_n': len(duration_results['late_patients']),
            'early_edss_mean': float(np.nanmean(duration_results['early_edss'])),
            'late_edss_mean': float(np.nanmean(duration_results['late_edss'])),
            'edss_comparison_p': float(duration_results['edss_comparison']['p_value']),
        },
        'duration_feature_comparisons': [
            {'feature': r['feature'], 'early_mean': float(r['early_mean']), 'late_mean': float(r['late_mean']),
             'p': float(r['p_value']), 'sig': bool(r['significant'])}
            for r in duration_results['duration_results']
        ],
        'patient_mapping': {folder: data['clinical']['name'] 
                           for folder, data in patient_features.items()},
    }
    
    with open(os.path.join(output_dir, 'analysis_results.json'), 'w', encoding='utf-8') as f:
        json.dump(results_summary, f, indent=2, ensure_ascii=False)
    
    # Save detailed per-patient data
    patient_detail = []
    for folder, data in sorted(patient_features.items(), key=lambda x: int(x[0].split('_')[0])):
        clinical = data['clinical']
        row = {
            'folder': folder,
            'name': clinical['name'],
            'age': clinical['age'],
            'gender': 'F' if clinical['gender'] == 1 else 'M',
            'edss': clinical['edss'],
            'disease_duration': clinical['disease_duration'],
            'n_images': data['n_images'],
        }
        for j, fname in enumerate(FEATURE_NAMES):
            row[fname] = float(data['mean_features'][j])
        patient_detail.append(row)
    
    with open(os.path.join(output_dir, 'patient_features_detail.json'), 'w', encoding='utf-8') as f:
        json.dump(patient_detail, f, indent=2, ensure_ascii=False)
    
    # Save numpy arrays for figure generation
    np.save(os.path.join(output_dir, 'edss_values.npy'), edss_results['edss_values'])
    np.save(os.path.join(output_dir, 'feature_matrix.npy'), edss_results['feature_matrix'])
    np.save(os.path.join(output_dir, 'early_features.npy'), duration_results['early_features'])
    np.save(os.path.join(output_dir, 'late_features.npy'), duration_results['late_features'])
    np.save(os.path.join(output_dir, 'early_edss.npy'), duration_results['early_edss'])
    np.save(os.path.join(output_dir, 'late_edss.npy'), duration_results['late_edss'])
    
    print("\n" + "="*80)
    print("ALL RESULTS SAVED TO:", output_dir)
    print("="*80)
