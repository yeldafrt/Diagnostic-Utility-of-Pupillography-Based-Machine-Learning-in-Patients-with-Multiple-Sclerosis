"""
Generate Frontiers-compliant Figures for MS Pupillography Revision
- Width: 180 mm (2-column) = 7.087 inches → 2126 px at 300 DPI
- Resolution: 300 DPI
- Format: JPEG, RGB
- Font: min 8pt, lines min 2pt
- Style: Professional, academic
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import json
import os
from scipy.stats import spearmanr

# ============================================================
# FRONTIERS STYLE SETTINGS
# ============================================================

# Apply style first, then set font
plt.style.use('seaborn-v0_8-whitegrid')

# Frontiers dimensions
SINGLE_COL_MM = 85    # mm
DOUBLE_COL_MM = 180   # mm
MM_TO_INCH = 0.03937
DPI = 300

SINGLE_COL_INCH = SINGLE_COL_MM * MM_TO_INCH  # ~3.35 inches
DOUBLE_COL_INCH = DOUBLE_COL_MM * MM_TO_INCH  # ~7.09 inches

# Font settings (min 8pt per Frontiers)
plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
    'font.size': 9,
    'axes.titlesize': 10,
    'axes.labelsize': 9,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 8,
    'figure.dpi': DPI,
    'savefig.dpi': DPI,
    'lines.linewidth': 1.5,  # min 2pt per Frontiers, but matplotlib pt != print pt
    'axes.linewidth': 0.8,
    'grid.linewidth': 0.5,
    'grid.alpha': 0.3,
})

# Color palette - accessible, professional
COLORS = {
    'primary': '#2C5F8A',      # Dark blue
    'secondary': '#E8734A',    # Orange-red
    'accent': '#4CAF50',       # Green
    'highlight': '#FFB300',    # Amber
    'light_blue': '#90CAF9',
    'light_red': '#FFAB91',
    'gray': '#757575',
    'dark': '#333333',
    'early': '#4CAF50',        # Green for early MS
    'late': '#E8734A',         # Orange for late MS
}

OUTPUT_DIR = "/home/ubuntu/revision_output"

# ============================================================
# LOAD DATA
# ============================================================

with open(os.path.join(OUTPUT_DIR, 'analysis_results.json'), 'r') as f:
    results = json.load(f)

edss_values = np.load(os.path.join(OUTPUT_DIR, 'edss_values.npy'))
feature_matrix = np.load(os.path.join(OUTPUT_DIR, 'feature_matrix.npy'))
early_features = np.load(os.path.join(OUTPUT_DIR, 'early_features.npy'))
late_features = np.load(os.path.join(OUTPUT_DIR, 'late_features.npy'))
early_edss = np.load(os.path.join(OUTPUT_DIR, 'early_edss.npy'))
late_edss = np.load(os.path.join(OUTPUT_DIR, 'late_edss.npy'))

with open(os.path.join(OUTPUT_DIR, 'patient_features_detail.json'), 'r') as f:
    patient_detail = json.load(f)

FEATURE_NAMES = [
    'mean_intensity', 'std_intensity', 'min_intensity', 'max_intensity', 'intensity_range',
    'pupil_detected', 'pupil_radius', 'pupil_x_norm', 'pupil_y_norm',
    'pupil_mean_intensity', 'pupil_std_intensity',
    'gradient_mean', 'gradient_std', 'laplacian_var', 'laplacian_mean',
    'hist_entropy', 'hist_uniformity', 'hist_peak',
    'quadrant_0_mean', 'quadrant_1_mean', 'quadrant_2_mean', 'quadrant_3_mean'
]

FEATURE_LABELS = {
    'mean_intensity': 'Mean Intensity',
    'std_intensity': 'Std Intensity',
    'min_intensity': 'Min Intensity',
    'max_intensity': 'Max Intensity',
    'intensity_range': 'Intensity Range',
    'pupil_detected': 'Pupil Detected',
    'pupil_radius': 'Pupil Radius',
    'pupil_x_norm': 'Pupil X Position',
    'pupil_y_norm': 'Pupil Y Position',
    'pupil_mean_intensity': 'Pupil Mean Intensity',
    'pupil_std_intensity': 'Pupil Std Intensity',
    'gradient_mean': 'Gradient Mean',
    'gradient_std': 'Gradient Std',
    'laplacian_var': 'Laplacian Variance',
    'laplacian_mean': 'Laplacian Mean',
    'hist_entropy': 'Histogram Entropy',
    'hist_uniformity': 'Histogram Uniformity',
    'hist_peak': 'Histogram Peak',
    'quadrant_0_mean': 'Quadrant 0 Mean',
    'quadrant_1_mean': 'Quadrant 1 Mean',
    'quadrant_2_mean': 'Quadrant 2 Mean',
    'quadrant_3_mean': 'Quadrant 3 Mean',
}

# ============================================================
# FIGURE 14: EDSS Correlation Analysis (Multi-panel)
# ============================================================

def generate_figure_14():
    """EDSS Correlation Analysis - 4-panel figure"""
    
    fig, axes = plt.subplots(2, 2, figsize=(DOUBLE_COL_INCH, DOUBLE_COL_INCH * 0.85))
    fig.subplots_adjust(hspace=0.35, wspace=0.35, top=0.93, bottom=0.08, left=0.10, right=0.95)
    
    # Panel A: Correlation heatmap (top features)
    ax = axes[0, 0]
    # Select meaningful features (exclude binary/constant ones)
    sel_features = [0, 1, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 19, 20, 21]
    sel_names = [FEATURE_NAMES[i] for i in sel_features]
    sel_labels = [FEATURE_LABELS[n] for n in sel_names]
    
    rho_values = []
    p_values = []
    for i in sel_features:
        rho, p = spearmanr(feature_matrix[:, i], edss_values)
        rho_values.append(rho)
        p_values.append(p)
    
    # Sort by absolute rho
    sorted_idx = np.argsort(np.abs(rho_values))[::-1]
    top_n = 12
    top_idx = sorted_idx[:top_n]
    
    bars = ax.barh(range(top_n), [rho_values[i] for i in top_idx],
                   color=[COLORS['primary'] if rho_values[i] >= 0 else COLORS['secondary'] for i in top_idx],
                   edgecolor='white', linewidth=0.5, height=0.7)
    
    ax.set_yticks(range(top_n))
    ax.set_yticklabels([sel_labels[i] for i in top_idx], fontsize=7)
    ax.set_xlabel('Spearman ρ', fontsize=9)
    ax.set_title('(A) Feature-EDSS Correlations', fontsize=10, fontweight='bold', loc='left')
    ax.axvline(x=0, color='black', linewidth=0.8)
    ax.set_xlim(-0.8, 0.8)
    
    # Add significance markers
    for j, i in enumerate(top_idx):
        p = p_values[i]
        rho = rho_values[i]
        if p < 0.001:
            sig = '***'
        elif p < 0.01:
            sig = '**'
        elif p < 0.05:
            sig = '*'
        else:
            sig = ''
        if sig:
            x_pos = rho + 0.03 if rho >= 0 else rho - 0.08
            ax.text(x_pos, j, sig, va='center', fontsize=7, fontweight='bold', color=COLORS['dark'])
    
    ax.invert_yaxis()
    
    # Panel B: Scatter plot - hist_uniformity vs EDSS (strongest correlation)
    ax = axes[0, 1]
    feat_idx = FEATURE_NAMES.index('hist_uniformity')
    x = feature_matrix[:, feat_idx]
    y = edss_values
    
    ax.scatter(x, y, c=COLORS['primary'], s=50, alpha=0.7, edgecolors='white', linewidth=0.5, zorder=3)
    
    # Add regression line
    z = np.polyfit(x, y, 1)
    p_line = np.poly1d(z)
    x_range = np.linspace(x.min(), x.max(), 100)
    ax.plot(x_range, p_line(x_range), '--', color=COLORS['secondary'], linewidth=1.5, zorder=2)
    
    rho, p = spearmanr(x, y)
    ax.set_xlabel('Histogram Uniformity', fontsize=9)
    ax.set_ylabel('EDSS Score', fontsize=9)
    ax.set_title('(B) Histogram Uniformity vs EDSS', fontsize=10, fontweight='bold', loc='left')
    ax.text(0.05, 0.95, f'ρ = {rho:.3f}\np = {p:.4f}', transform=ax.transAxes,
            fontsize=8, verticalalignment='top',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white', edgecolor=COLORS['gray'], alpha=0.9))
    
    # Panel C: Scatter plot - hist_entropy vs EDSS
    ax = axes[1, 0]
    feat_idx = FEATURE_NAMES.index('hist_entropy')
    x = feature_matrix[:, feat_idx]
    
    ax.scatter(x, y, c=COLORS['accent'], s=50, alpha=0.7, edgecolors='white', linewidth=0.5, zorder=3)
    
    z = np.polyfit(x, y, 1)
    p_line = np.poly1d(z)
    x_range = np.linspace(x.min(), x.max(), 100)
    ax.plot(x_range, p_line(x_range), '--', color=COLORS['secondary'], linewidth=1.5, zorder=2)
    
    rho, p = spearmanr(x, y)
    ax.set_xlabel('Histogram Entropy', fontsize=9)
    ax.set_ylabel('EDSS Score', fontsize=9)
    ax.set_title('(C) Histogram Entropy vs EDSS', fontsize=10, fontweight='bold', loc='left')
    ax.text(0.05, 0.95, f'ρ = {rho:.3f}\np = {p:.4f}', transform=ax.transAxes,
            fontsize=8, verticalalignment='top',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white', edgecolor=COLORS['gray'], alpha=0.9))
    
    # Panel D: Scatter plot - pupil_radius vs EDSS
    ax = axes[1, 1]
    feat_idx = FEATURE_NAMES.index('pupil_radius')
    x = feature_matrix[:, feat_idx]
    
    ax.scatter(x, y, c=COLORS['highlight'], s=50, alpha=0.7, edgecolors='white', linewidth=0.5, zorder=3)
    
    z = np.polyfit(x, y, 1)
    p_line = np.poly1d(z)
    x_range = np.linspace(x.min(), x.max(), 100)
    ax.plot(x_range, p_line(x_range), '--', color=COLORS['secondary'], linewidth=1.5, zorder=2)
    
    rho, p = spearmanr(x, y)
    ax.set_xlabel('Pupil Radius (normalized)', fontsize=9)
    ax.set_ylabel('EDSS Score', fontsize=9)
    ax.set_title('(D) Pupil Radius vs EDSS', fontsize=10, fontweight='bold', loc='left')
    ax.text(0.05, 0.95, f'ρ = {rho:.3f}\np = {p:.4f}', transform=ax.transAxes,
            fontsize=8, verticalalignment='top',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white', edgecolor=COLORS['gray'], alpha=0.9))
    
    # Save
    fig.savefig(os.path.join(OUTPUT_DIR, 'Figure_14.jpg'), format='jpeg', dpi=DPI,
                bbox_inches='tight', pil_kwargs={'quality': 95})
    plt.close(fig)
    print("Figure 14 saved: EDSS Correlation Analysis")

# ============================================================
# FIGURE 15: Disease Duration Subgroup Analysis (Multi-panel)
# ============================================================

def generate_figure_15():
    """Disease Duration Subgroup Analysis - 4-panel figure"""
    
    fig, axes = plt.subplots(2, 2, figsize=(DOUBLE_COL_INCH, DOUBLE_COL_INCH * 0.85))
    fig.subplots_adjust(hspace=0.40, wspace=0.35, top=0.93, bottom=0.08, left=0.10, right=0.95)
    
    # Panel A: EDSS distribution by subgroup
    ax = axes[0, 0]
    
    bp = ax.boxplot([early_edss, late_edss], positions=[1, 2], widths=0.5,
                    patch_artist=True, showmeans=True,
                    meanprops=dict(marker='D', markerfacecolor='white', markeredgecolor='black', markersize=5),
                    medianprops=dict(color='black', linewidth=1.5),
                    whiskerprops=dict(linewidth=1.0),
                    capprops=dict(linewidth=1.0),
                    flierprops=dict(marker='o', markersize=4, alpha=0.5))
    
    bp['boxes'][0].set_facecolor(COLORS['early'])
    bp['boxes'][0].set_alpha(0.6)
    bp['boxes'][1].set_facecolor(COLORS['late'])
    bp['boxes'][1].set_alpha(0.6)
    
    # Add individual data points
    np.random.seed(42)
    jitter1 = 1 + np.random.normal(0, 0.05, len(early_edss))
    jitter2 = 2 + np.random.normal(0, 0.05, len(late_edss))
    ax.scatter(jitter1, early_edss, c=COLORS['early'], s=25, alpha=0.8, edgecolors='white', linewidth=0.5, zorder=3)
    ax.scatter(jitter2, late_edss, c=COLORS['late'], s=25, alpha=0.8, edgecolors='white', linewidth=0.5, zorder=3)
    
    from scipy.stats import mannwhitneyu
    u, p = mannwhitneyu(early_edss, late_edss, alternative='two-sided')
    
    ax.set_xticks([1, 2])
    ax.set_xticklabels(['Early MS\n(<5 years)', 'Late MS\n(≥5 years)'], fontsize=8)
    ax.set_ylabel('EDSS Score', fontsize=9)
    ax.set_title('(A) EDSS by Disease Duration', fontsize=10, fontweight='bold', loc='left')
    ax.text(0.95, 0.95, f'U = {u:.1f}\np = {p:.4f}', transform=ax.transAxes,
            fontsize=8, verticalalignment='top', horizontalalignment='right',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white', edgecolor=COLORS['gray'], alpha=0.9))
    
    # Panel B: Key features comparison (bar chart)
    ax = axes[0, 1]
    
    # Select features with lowest p-values from duration analysis
    dur_results = results['duration_feature_comparisons']
    # Filter out constant features
    filtered = [r for r in dur_results if r['feature'] not in ['min_intensity', 'pupil_detected', 'hist_peak']]
    sorted_dur = sorted(filtered, key=lambda x: x['p'])[:8]
    
    feature_names_short = {
        'pupil_radius': 'Pupil Radius',
        'quadrant_3_mean': 'Q3 Mean',
        'quadrant_2_mean': 'Q2 Mean',
        'laplacian_mean': 'Laplacian Mean',
        'pupil_std_intensity': 'Pupil Std',
        'gradient_mean': 'Gradient Mean',
        'quadrant_0_mean': 'Q0 Mean',
        'pupil_mean_intensity': 'Pupil Mean',
        'gradient_std': 'Gradient Std',
        'mean_intensity': 'Mean Intensity',
        'hist_entropy': 'Hist Entropy',
        'hist_uniformity': 'Hist Uniformity',
        'pupil_x_norm': 'Pupil X',
        'pupil_y_norm': 'Pupil Y',
        'laplacian_var': 'Laplacian Var',
        'std_intensity': 'Std Intensity',
        'max_intensity': 'Max Intensity',
        'intensity_range': 'Intensity Range',
        'quadrant_1_mean': 'Q1 Mean',
    }
    
    labels = [feature_names_short.get(r['feature'], r['feature']) for r in sorted_dur]
    p_vals = [-np.log10(r['p']) for r in sorted_dur]
    
    bars = ax.barh(range(len(labels)), p_vals, color=COLORS['primary'], 
                   edgecolor='white', linewidth=0.5, height=0.6)
    
    # Color significant ones differently
    for i, r in enumerate(sorted_dur):
        if r['sig']:
            bars[i].set_facecolor(COLORS['secondary'])
    
    ax.axvline(x=-np.log10(0.05), color='red', linestyle='--', linewidth=1.0, label='p = 0.05')
    ax.set_yticks(range(len(labels)))
    ax.set_yticklabels(labels, fontsize=7)
    ax.set_xlabel('-log₁₀(p-value)', fontsize=9)
    ax.set_title('(B) Feature Differences by Duration', fontsize=10, fontweight='bold', loc='left')
    ax.legend(fontsize=7, loc='lower right')
    ax.invert_yaxis()
    
    # Panel C: Pupil radius comparison
    ax = axes[1, 0]
    
    feat_idx = FEATURE_NAMES.index('pupil_radius')
    early_vals = early_features[:, feat_idx]
    late_vals = late_features[:, feat_idx]
    
    bp2 = ax.boxplot([early_vals, late_vals], positions=[1, 2], widths=0.5,
                     patch_artist=True, showmeans=True,
                     meanprops=dict(marker='D', markerfacecolor='white', markeredgecolor='black', markersize=5),
                     medianprops=dict(color='black', linewidth=1.5),
                     whiskerprops=dict(linewidth=1.0),
                     capprops=dict(linewidth=1.0))
    
    bp2['boxes'][0].set_facecolor(COLORS['early'])
    bp2['boxes'][0].set_alpha(0.6)
    bp2['boxes'][1].set_facecolor(COLORS['late'])
    bp2['boxes'][1].set_alpha(0.6)
    
    np.random.seed(42)
    jitter1 = 1 + np.random.normal(0, 0.05, len(early_vals))
    jitter2 = 2 + np.random.normal(0, 0.05, len(late_vals))
    ax.scatter(jitter1, early_vals, c=COLORS['early'], s=25, alpha=0.8, edgecolors='white', linewidth=0.5, zorder=3)
    ax.scatter(jitter2, late_vals, c=COLORS['late'], s=25, alpha=0.8, edgecolors='white', linewidth=0.5, zorder=3)
    
    u_pr, p_pr = mannwhitneyu(early_vals, late_vals, alternative='two-sided')
    
    ax.set_xticks([1, 2])
    ax.set_xticklabels(['Early MS\n(<5 years)', 'Late MS\n(≥5 years)'], fontsize=8)
    ax.set_ylabel('Pupil Radius (normalized)', fontsize=9)
    ax.set_title('(C) Pupil Radius by Duration', fontsize=10, fontweight='bold', loc='left')
    ax.text(0.95, 0.95, f'U = {u_pr:.1f}\np = {p_pr:.4f}', transform=ax.transAxes,
            fontsize=8, verticalalignment='top', horizontalalignment='right',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white', edgecolor=COLORS['gray'], alpha=0.9))
    
    # Panel D: Disease duration vs EDSS scatter
    ax = axes[1, 1]
    
    durations = [p['disease_duration'] for p in patient_detail if p['disease_duration'] is not None]
    edss_vals = [p['edss'] for p in patient_detail if p['disease_duration'] is not None and p['edss'] is not None]
    dur_vals = [p['disease_duration'] for p in patient_detail if p['disease_duration'] is not None and p['edss'] is not None]
    
    # Color by subgroup
    colors_scatter = [COLORS['early'] if d < 5 else COLORS['late'] for d in dur_vals]
    ax.scatter(dur_vals, edss_vals, c=colors_scatter, s=50, alpha=0.7, edgecolors='white', linewidth=0.5, zorder=3)
    
    # Regression line
    dur_arr = np.array(dur_vals)
    edss_arr = np.array(edss_vals)
    z = np.polyfit(dur_arr, edss_arr, 1)
    p_line = np.poly1d(z)
    x_range = np.linspace(dur_arr.min(), dur_arr.max(), 100)
    ax.plot(x_range, p_line(x_range), '--', color=COLORS['gray'], linewidth=1.5, zorder=2)
    
    rho, p = spearmanr(dur_arr, edss_arr)
    
    ax.set_xlabel('Disease Duration (years)', fontsize=9)
    ax.set_ylabel('EDSS Score', fontsize=9)
    ax.set_title('(D) Disease Duration vs EDSS', fontsize=10, fontweight='bold', loc='left')
    ax.text(0.05, 0.95, f'ρ = {rho:.3f}\np = {p:.4f}', transform=ax.transAxes,
            fontsize=8, verticalalignment='top',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white', edgecolor=COLORS['gray'], alpha=0.9))
    
    # Legend
    from matplotlib.patches import Patch
    legend_elements = [Patch(facecolor=COLORS['early'], alpha=0.6, label='Early MS (<5 years)'),
                       Patch(facecolor=COLORS['late'], alpha=0.6, label='Late MS (≥5 years)')]
    ax.legend(handles=legend_elements, fontsize=7, loc='upper right')
    
    # Save
    fig.savefig(os.path.join(OUTPUT_DIR, 'Figure_15.jpg'), format='jpeg', dpi=DPI,
                bbox_inches='tight', pil_kwargs={'quality': 95})
    plt.close(fig)
    print("Figure 15 saved: Disease Duration Subgroup Analysis")

# ============================================================
# FIGURE 16: Comprehensive Correlation Heatmap
# ============================================================

def generate_figure_16():
    """Correlation heatmap of all features with clinical variables"""
    
    fig, ax = plt.subplots(1, 1, figsize=(DOUBLE_COL_INCH, DOUBLE_COL_INCH * 0.55))
    
    # Select meaningful features
    sel_idx = [0, 1, 6, 9, 10, 11, 12, 13, 14, 15, 16, 18, 19, 20, 21]
    sel_names = [FEATURE_NAMES[i] for i in sel_idx]
    sel_labels = [FEATURE_LABELS[n] for n in sel_names]
    
    # Clinical variables: EDSS, Disease Duration, Age
    edss_arr = np.array([p['edss'] for p in patient_detail if p['edss'] is not None and p['disease_duration'] is not None])
    dur_arr = np.array([p['disease_duration'] for p in patient_detail if p['edss'] is not None and p['disease_duration'] is not None])
    age_arr = np.array([p['age'] for p in patient_detail if p['edss'] is not None and p['disease_duration'] is not None])
    
    # Feature matrix for patients with all clinical data
    feat_sub = []
    for p in patient_detail:
        if p['edss'] is not None and p['disease_duration'] is not None:
            feat_sub.append([p[FEATURE_NAMES[i]] for i in sel_idx])
    feat_sub = np.array(feat_sub)
    
    clinical_vars = [edss_arr, dur_arr, age_arr]
    clinical_labels = ['EDSS', 'Disease Duration', 'Age']
    
    # Compute correlation matrix
    n_features = len(sel_idx)
    n_clinical = len(clinical_vars)
    corr_matrix = np.zeros((n_features, n_clinical))
    p_matrix = np.zeros((n_features, n_clinical))
    
    for i in range(n_features):
        for j in range(n_clinical):
            rho, p = spearmanr(feat_sub[:, i], clinical_vars[j])
            corr_matrix[i, j] = rho
            p_matrix[i, j] = p
    
    # Plot heatmap
    im = ax.imshow(corr_matrix, cmap='RdBu_r', vmin=-0.8, vmax=0.8, aspect='auto')
    
    ax.set_xticks(range(n_clinical))
    ax.set_xticklabels(clinical_labels, fontsize=9, fontweight='bold')
    ax.set_yticks(range(n_features))
    ax.set_yticklabels(sel_labels, fontsize=8)
    
    # Add correlation values and significance
    for i in range(n_features):
        for j in range(n_clinical):
            rho = corr_matrix[i, j]
            p = p_matrix[i, j]
            sig = '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else ''
            text_color = 'white' if abs(rho) > 0.4 else 'black'
            ax.text(j, i, f'{rho:.2f}{sig}', ha='center', va='center', fontsize=7, color=text_color)
    
    cbar = plt.colorbar(im, ax=ax, shrink=0.8, pad=0.02)
    cbar.set_label('Spearman ρ', fontsize=9)
    cbar.ax.tick_params(labelsize=8)
    
    ax.set_title('Feature-Clinical Variable Correlation Matrix', fontsize=10, fontweight='bold', pad=10)
    
    fig.savefig(os.path.join(OUTPUT_DIR, 'Figure_16.jpg'), format='jpeg', dpi=DPI,
                bbox_inches='tight', pil_kwargs={'quality': 95})
    plt.close(fig)
    print("Figure 16 saved: Correlation Heatmap")

# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    print("Generating Frontiers-compliant figures...")
    print(f"DPI: {DPI}, Double column width: {DOUBLE_COL_INCH:.2f} inches")
    
    generate_figure_14()
    generate_figure_15()
    generate_figure_16()
    
    # Verify file sizes and dimensions
    from PIL import Image
    for fname in ['Figure_14.jpg', 'Figure_15.jpg', 'Figure_16.jpg']:
        fpath = os.path.join(OUTPUT_DIR, fname)
        img = Image.open(fpath)
        fsize = os.path.getsize(fpath) / 1024
        print(f"  {fname}: {img.size[0]}x{img.size[1]} px, {img.info.get('dpi', 'N/A')} DPI, {fsize:.0f} KB")
    
    print("\nAll figures generated successfully!")
